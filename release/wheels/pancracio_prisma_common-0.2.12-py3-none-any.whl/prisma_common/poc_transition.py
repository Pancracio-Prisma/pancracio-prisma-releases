"""Strict Core deployment transition record for an already enrolled instance.

Core changes are only hints until the caller has verified the protected Core
commit and the live Policy release. This module never grants GitHub access.
"""

from __future__ import annotations

import json
from pathlib import Path
import re
from typing import Any

from .intake import SetupInputError


_LOGIN = re.compile(r"[A-Za-z0-9](?:[A-Za-z0-9-]{0,37}[A-Za-z0-9])?\Z")
_ACTOR = re.compile(r"[A-Za-z][A-Za-z0-9_-]{2,63}\Z")
_SHA = re.compile(r"[0-9a-f]{40}\Z")


def read_poc_transition(core_root: Path, *, tenant_slug: str,
                        verified_core_commit: str,
                        verified_contents: str | None = None) -> dict[str, Any] | None:
    """Parse a Core transition only after its exact commit has been verified."""
    if not _SHA.fullmatch(verified_core_commit):
        raise SetupInputError("verified Core commit is required")
    path = core_root / "registry" / "deployment-transition.json"
    if verified_contents is None:
        if path.is_symlink():
            raise SetupInputError("Core deployment transition path is unsafe")
        if not path.exists():
            return None
        if not path.is_file() or path.stat().st_size > 100_000:
            raise SetupInputError("Core deployment transition is unavailable")
    try:
        contents = (path.read_text(encoding="utf-8") if verified_contents is None
                    else verified_contents)
        if len(contents.encode("utf-8")) > 100_000:
            raise SetupInputError("Core deployment transition is unavailable")
        data = json.loads(contents)
    except (OSError, ValueError) as exc:
        raise SetupInputError("Core deployment transition is invalid") from exc
    if (not isinstance(data, dict)
            or set(data) != {"schema_version", "tenant_slug", "mode", "accounts"}
            or data["schema_version"] != 1
            or data["tenant_slug"] != tenant_slug
            or data["mode"] not in {"poc", "migrating", "production"}
            or not isinstance(data["accounts"], dict)
            or any(not isinstance(actor, str) or not _ACTOR.fullmatch(actor)
                   or not isinstance(login, str) or not _LOGIN.fullmatch(login)
                   for actor, login in data["accounts"].items())):
        raise SetupInputError("Core deployment transition is invalid")
    if data["mode"] != "poc" and not data["accounts"]:
        raise SetupInputError("POC exit needs assigned GitHub accounts")
    return data


def actor_transition(data: dict[str, Any], *, actor_id: str,
                     verified_release_commit: str, verified_core_commit: str) -> dict[str, str]:
    """Return one Actor's pending step only for the published Core commit."""
    if (not _SHA.fullmatch(verified_release_commit)
            or verified_release_commit != verified_core_commit):
        raise SetupInputError("Core transition is not the active Policy release")
    if data["mode"] == "poc":
        return {"status": "POC"}
    login = data["accounts"].get(actor_id)
    if not login:
        raise SetupInputError("Actor has no assigned GitHub account")
    return {"status": "GITHUB_MIGRATION_REQUIRED", "github_login": login}
