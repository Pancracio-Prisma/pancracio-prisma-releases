"""Offline, non-secret handoff from the technician to a Prisma user."""

from __future__ import annotations

import hmac
import hashlib
from pathlib import Path
import re
import base64
import binascii
from typing import Any

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

from .intake import SetupInputError, load_json
from .oauth_profile import validate_desktop_oauth_data
from .trusted_binding import canonical_bytes, public_key_fingerprint, verify_signed_binding


def verify_bundle(directory: Path, *, expected_fingerprint: str) -> dict[str, Any]:
    if not re.fullmatch(r"[0-9a-f]{64}", expected_fingerprint):
        raise SetupInputError("invalid trusted key fingerprint")
    if directory.is_symlink() or not directory.is_dir():
        raise SetupInputError("bundle directory is unavailable")
    expected_files = {"trust-public-key.raw", "binding.json", "desktop_oauth.json",
                      "bundle-manifest.json"}
    if {entry.name for entry in directory.iterdir()} != expected_files:
        raise SetupInputError("bundle contents are unexpected")
    for name in expected_files:
        entry = directory / name
        if entry.is_symlink() or not entry.is_file():
            raise SetupInputError("bundle contains an unsafe file")
    key_path = directory / "trust-public-key.raw"
    if key_path.is_symlink() or not key_path.is_file() or key_path.stat().st_size != 32:
        raise SetupInputError("bundle public key is unavailable")
    key = key_path.read_bytes()
    if not hmac.compare_digest(public_key_fingerprint(key), expected_fingerprint):
        raise SetupInputError("bundle key fingerprint differs from trusted value")
    manifest = load_json(directory / "bundle-manifest.json")
    if (not isinstance(manifest, dict) or set(manifest) != {"payload", "signature"}
            or not isinstance(manifest["payload"], dict)
            or set(manifest["payload"]) != {"schema_version", "instance_id",
                                          "binding_sha256", "desktop_oauth_sha256"}
            or manifest["payload"]["schema_version"] != 1
            or not isinstance(manifest["signature"], str)):
        raise SetupInputError("invalid bundle manifest")
    try:
        signature = base64.b64decode(manifest["signature"], validate=True)
        Ed25519PublicKey.from_public_bytes(key).verify(signature, canonical_bytes(manifest["payload"]))
    except (ValueError, binascii.Error, InvalidSignature) as exc:
        raise SetupInputError("bundle manifest signature is invalid") from exc
    for name, field in (("binding.json", "binding_sha256"),
                        ("desktop_oauth.json", "desktop_oauth_sha256")):
        expected = manifest["payload"][field]
        actual = hashlib.sha256((directory / name).read_bytes()).hexdigest()
        if not isinstance(expected, str) or not hmac.compare_digest(actual, expected):
            raise SetupInputError("bundle file differs from signed manifest")
    binding_path = directory / "binding.json"
    envelope = load_json(binding_path)
    if not isinstance(envelope, dict) or not isinstance(envelope.get("payload"), dict):
        raise SetupInputError("invalid bundle binding")
    instance = envelope["payload"].get("instance_id")
    if not isinstance(instance, str):
        raise SetupInputError("invalid bundle instance")
    if manifest["payload"]["instance_id"] != instance:
        raise SetupInputError("bundle instance differs from signed manifest")
    payload = verify_signed_binding(binding_path, pinned_public_key=key,
                                    expected_instance_id=instance)
    oauth = load_json(directory / "desktop_oauth.json")
    validate_desktop_oauth_data(oauth, payload["resources"]["google_cloud"])
    return {"status": "BUNDLE_VERIFIED_NOT_INSTALLED", "tenant_slug": payload["tenant_slug"],
            "instance_id": instance, "authority_granted": False}
