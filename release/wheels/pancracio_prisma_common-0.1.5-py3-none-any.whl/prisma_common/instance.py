"""Deterministic, per-instance local names. No file or service is created here."""

from __future__ import annotations

import os
from pathlib import Path
import subprocess
import sys
from typing import Any

from .intake import SetupInputError


def instance_id(intake: dict[str, Any]) -> str:
    """Use an explicit ID for multiple instances of one tenant on a computer."""
    return intake["deployment"].get("instance_id") or intake["tenant"]["slug"]


def layouts(intake: dict[str, Any]) -> dict[str, Any]:
    identity = instance_id(intake)
    return {
        "schema_version": 1,
        "instance_id": identity,
        "status": "RESERVED_NAMES_ONLY",
        "macos": {
            "workspace": f"~/Pancracio Prisma/instances/{identity}/workspace",
            "runtime": f"~/Library/Application Support/Pancracio Prisma/instances/{identity}/runtime",
            "state": f"~/Library/Application Support/Pancracio Prisma/instances/{identity}/state",
            "logs": f"~/Library/Logs/Pancracio Prisma/instances/{identity}",
            "launch_agent_label": f"com.pancracio.prisma.contextsync.{identity}",
            "launch_agent_file": f"~/Library/LaunchAgents/com.pancracio.prisma.contextsync.{identity}.plist",
        },
        "windows": {
            "workspace": rf"%USERPROFILE%\Pancracio Prisma\instances\{identity}\workspace",
            "runtime": rf"%LOCALAPPDATA%\Pancracio Prisma\instances\{identity}\runtime",
            "state": rf"%LOCALAPPDATA%\Pancracio Prisma\instances\{identity}\state",
            "logs": rf"%LOCALAPPDATA%\Pancracio Prisma\instances\{identity}\logs",
            "task_name": rf"\PancracioPrisma\{identity}\ContextSync",
        },
        "credential_namespaces": {
            "google_oidc": f"pancracio-prisma/{identity}/google-oidc",
            "gateway": f"pancracio-prisma/{identity}/gateway",
        },
        "codex_config_location": "inside_this_instance_workspace_only",
        "context_subscription": "derived_from_unique_runtime_id_after_authorized_enrollment",
    }


def _registered_service(intake: dict[str, Any], os_name: str) -> bool | None:
    """Detect an occupied service name; a failed query cannot prove absence."""
    if (os_name == "macos" and sys.platform != "darwin") or (os_name == "windows" and os.name != "nt"):
        return None
    layout = layouts(intake)[os_name]
    if os_name == "macos":
        command = ["launchctl", "print", f"gui/{os.getuid()}/{layout['launch_agent_label']}"]
    else:
        command = ["schtasks", "/Query", "/TN", layout["task_name"]]
    try:
        result = subprocess.run(command, capture_output=True, timeout=10, check=False)
    except (OSError, subprocess.TimeoutExpired):
        return None
    return True if result.returncode == 0 else None


def local_preflight(intake: dict[str, Any], *, home: Path | None = None,
                    local_appdata: Path | None = None,
                    platform: str | None = None,
                    service_registered: bool | None = None) -> dict[str, Any]:
    """Check local namespace availability without reading installed Panky files."""
    os_name = platform or ("windows" if os.name == "nt" else "macos" if sys.platform == "darwin" else "unsupported")
    if os_name not in {"macos", "windows"}:
        raise SetupInputError("local preflight supports macOS and Windows only")
    base_home = home or Path.home()
    if os_name == "windows":
        base_appdata = local_appdata or (Path(os.environ["LOCALAPPDATA"]) if "LOCALAPPDATA" in os.environ else None)
        if base_appdata is None:
            raise SetupInputError("LOCALAPPDATA is unavailable")
        roots = [base_home / "Pancracio Prisma" / "instances" / instance_id(intake),
                 base_appdata / "Pancracio Prisma" / "instances" / instance_id(intake)]
    else:
        roots = [base_home / "Pancracio Prisma" / "instances" / instance_id(intake),
                 base_home / "Library" / "Application Support" / "Pancracio Prisma" / "instances" / instance_id(intake),
                 base_home / "Library" / "Logs" / "Pancracio Prisma" / "instances" / instance_id(intake)]
    blocked = False
    for root in roots:
        if root.exists() or root.is_symlink():
            blocked = True
        for ancestor in root.parents:
            if ancestor.is_symlink():
                blocked = True
                break
    if os_name == "macos":
        agent = base_home / "Library" / "LaunchAgents" / layouts(intake)["macos"]["launch_agent_file"].split("/")[-1]
        blocked = blocked or agent.exists() or agent.is_symlink()
    registered = service_registered if service_registered is not None else _registered_service(intake, os_name)
    status = ("LOCAL_PATH_COLLISION" if blocked else "SERVICE_NAME_COLLISION" if registered is True
              else "LOCAL_PATHS_AVAILABLE_SERVICE_UNVERIFIED")
    return {"status": status,
            "platform": os_name, "instance_id": instance_id(intake),
            "service_registration_checked": registered is True,
            "authority_granted": False, "runtime_installed": False}
