"""Locate a per-instance trust pin outside the editable Workspace."""

from __future__ import annotations

import os
from pathlib import Path
import re
import sys
from typing import Any

from .intake import SetupInputError
from .trusted_binding import verify_signed_binding


_INSTANCE = re.compile(r"[a-z][a-z0-9-]{2,30}\Z")


def runtime_directory(workspace: Path, *, home: Path | None = None,
                      local_appdata: Path | None = None,
                      platform: str | None = None) -> tuple[str, Path]:
    """Resolve only the namespace assigned to this canonical Workspace."""
    os_name = platform or ("windows" if os.name == "nt" else "macos" if sys.platform == "darwin" else "unsupported")
    if os_name not in {"macos", "windows"}:
        raise SetupInputError("unsupported Prisma runtime platform")
    target = Path(workspace)
    identity = target.parent.name if target.name == "workspace" else ""
    if not _INSTANCE.fullmatch(identity):
        raise SetupInputError("workspace is not a Prisma instance")
    base_home = home or Path.home()
    expected = base_home / "Pancracio Prisma" / "instances" / identity / "workspace"
    if target.absolute() != expected.absolute():
        raise SetupInputError("workspace is outside its Prisma instance")
    for part in (target, *target.parents):
        if part.is_symlink():
            raise SetupInputError("workspace path contains a symlink")
    if os_name == "macos":
        runtime = (base_home / "Library" / "Application Support" /
                   "Pancracio Prisma" / "instances" / identity / "runtime")
    else:
        appdata = local_appdata or (Path(os.environ["LOCALAPPDATA"]) if "LOCALAPPDATA" in os.environ else None)
        if appdata is None:
            raise SetupInputError("LOCALAPPDATA is unavailable")
        runtime = appdata / "Pancracio Prisma" / "instances" / identity / "runtime"
    for part in (runtime, *runtime.parents):
        if part.is_symlink():
            raise SetupInputError("runtime path contains a symlink")
    return identity, runtime


def load_installed_binding(workspace: Path, *, home: Path | None = None,
                           local_appdata: Path | None = None,
                           platform: str | None = None) -> dict[str, Any]:
    """Require a canonical Prisma path and an installer-pinned public key."""
    identity, runtime = runtime_directory(workspace, home=home,
                                          local_appdata=local_appdata, platform=platform)
    key_path = runtime / "trust-public-key.raw"
    binding_path = runtime / "binding.json"
    if key_path.is_symlink() or not key_path.is_file() or key_path.stat().st_size != 32:
        raise SetupInputError("installer trust pin is unavailable")
    return verify_signed_binding(binding_path, pinned_public_key=key_path.read_bytes(),
                                 expected_instance_id=identity)
