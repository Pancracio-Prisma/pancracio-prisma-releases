"""Verify an offline Prisma release against an independently trusted publisher key."""

from __future__ import annotations

import base64
import binascii
import hashlib
import hmac
from pathlib import Path
import re
from typing import Any

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

from .intake import SetupInputError, load_json
from .trusted_binding import canonical_bytes, public_key_fingerprint


_VERSION = re.compile(r"[0-9]+\.[0-9]+\.[0-9]+\Z")
_WHEEL = re.compile(r"[A-Za-z0-9][A-Za-z0-9_.+-]{5,199}\.whl\Z")


def verify_release(directory: Path, *, expected_fingerprint: str) -> dict[str, Any]:
    """Read an exact, signed wheel set; this does not install or grant authority."""
    if not re.fullmatch(r"[0-9a-f]{64}", expected_fingerprint):
        raise SetupInputError("invalid publisher fingerprint")
    if directory.is_symlink() or not directory.is_dir():
        raise SetupInputError("release directory is unavailable")
    if {entry.name for entry in directory.iterdir()} != {
        "release.json", "publisher-public-key.raw", "wheels"
    }:
        raise SetupInputError("release contents are unexpected")
    key_path = directory / "publisher-public-key.raw"
    manifest_path = directory / "release.json"
    wheels_path = directory / "wheels"
    if (key_path.is_symlink() or manifest_path.is_symlink() or wheels_path.is_symlink()
            or not key_path.is_file() or key_path.stat().st_size != 32
            or not manifest_path.is_file() or manifest_path.stat().st_size > 64 * 1024
            or not wheels_path.is_dir()):
        raise SetupInputError("release files are unavailable")
    key = key_path.read_bytes()
    if not hmac.compare_digest(public_key_fingerprint(key), expected_fingerprint):
        raise SetupInputError("publisher key differs from trusted fingerprint")
    envelope = load_json(manifest_path)
    if (not isinstance(envelope, dict) or set(envelope) != {"payload", "signature"}
            or not isinstance(envelope["payload"], dict)
            or set(envelope["payload"]) != {"schema_version", "version", "wheels"}
            or envelope["payload"]["schema_version"] != 1
            or not isinstance(envelope["signature"], str)):
        raise SetupInputError("release manifest is invalid")
    payload = envelope["payload"]
    version = payload["version"]
    wheels = payload["wheels"]
    if (not isinstance(version, str) or not _VERSION.fullmatch(version)
            or not isinstance(wheels, dict) or not wheels
            or len(wheels) > 100 or not all(isinstance(name, str) and _WHEEL.fullmatch(name)
                                            and isinstance(digest, str)
                                            and re.fullmatch(r"[0-9a-f]{64}", digest)
                                            for name, digest in wheels.items())):
        raise SetupInputError("release wheel manifest is invalid")
    if not any(name.startswith(f"pancracio_prisma_user-{version}-") for name in wheels):
        raise SetupInputError("release does not contain the matching user wheel")
    if {entry.name for entry in wheels_path.iterdir()} != set(wheels):
        raise SetupInputError("release wheel set differs from manifest")
    try:
        signature = base64.b64decode(envelope["signature"], validate=True)
        Ed25519PublicKey.from_public_bytes(key).verify(signature, canonical_bytes(payload))
    except (ValueError, binascii.Error, InvalidSignature) as exc:
        raise SetupInputError("publisher signature is invalid") from exc
    for name, expected in wheels.items():
        path = wheels_path / name
        if path.is_symlink() or not path.is_file() or path.stat().st_size > 100 * 1024 * 1024:
            raise SetupInputError("release wheel is unavailable")
        with path.open("rb") as stream:
            digest = hashlib.file_digest(stream, "sha256").hexdigest()
        if not hmac.compare_digest(digest, expected):
            raise SetupInputError("release wheel differs from signed manifest")
    return {"status": "RELEASE_VERIFIED_NOT_INSTALLED", "version": version,
            "fingerprint_sha256": expected_fingerprint, "wheel_count": len(wheels)}
