# Pancracio Prisma: contrato de instalación de usuario para Codex

Codex es el agente de setup hasta que Panky Prisma demuestre identidad,
autoridad y salud. La guía humana es `docs/END_USER_INSTALL.md`. No pidas al
usuario crear GCP, Core, repositorios organizacionales ni políticas: eso
pertenece a la instalación técnica ya verificada.

1. Pide al usuario el bundle firmado de su organización, el release firmado
   que le entregaron y las huellas de cliente y publicador por un canal
   independiente. Muestra el identificador y las rutas reservadas para
   **esta instancia**; el bundle las determina, no una carpeta elegida por
   el usuario.
   Pregunta si quiere Personal local o un repositorio privado propio. El
   Gateway organizacional ya viene fijado en el bundle por Tech Install;
   no preguntes si desea omitirlo ni qué modalidad de hosting usa. No
   preguntes datos que ya están en el bundle; no solicites tokens o
   contraseñas en el chat.
2. Comprueba Python 3.12, Git, GitHub CLI (`gh`) autenticado y el transporte
   GitHub de repositorios privados. `gh` debe poder leer los paquetes firmados
   públicos de `Pancracio-Prisma/pancracio-prisma-releases`; verifica el canal
   en el alta sin pedir acceso al código privado del producto.
   Pide al usuario qué cuenta GitHub autorizada debe usar, configura Git/SSH
   en su perfil sin tocar otra cuenta y confirma acceso de lectura al
   Workspace y Core enlazados antes de clonar. El login GitHub no sustituye
   la identidad Google del Actor.
   Antes de instalar código, compara la huella SHA-256 de cada clave pública
   del paquete con la huella del operador y del publicador recibida por un
   canal independiente. En un entorno temporal **fuera** de cualquier
   instalación existente, instala solo los wheels de `release/wheels` con
   `pip --no-index --find-links`, seleccionando
   `pancracio-prisma-user==<versión del release>`; usa ese ejecutable temporal para verificar
   firmas y contenidos con `panky-prisma verify-bundle` y `verify-release`.
   Ejecuta
   el preflight local y rechaza una ruta, servicio, llavero o ID de instancia
   ocupado. Nunca sustituyas el comando global `panky` ni otro Pancracio.
3. Ejecuta `enroll-bundle` y `upgrade` desde el wheel de usuario para crear el
   runtime propio de esta instancia. A partir del `upgrade` usa el ejecutable
   del entorno propio de la instancia, no el temporal. Usa únicamente el Workspace y los
   repositorios que el bundle enlaza; un enlace editable, el login de GitHub o
   una carpeta local no autorizan materialización. Si el usuario eligió un
   Personal remoto, crea solo su repositorio privado vacío en la cuenta que
   él seleccionó y registra su propietario exacto; confirma la acción antes
   de crear ese recurso.
4. Comprueba que el endpoint firmado del Gateway responde y que su política
   organizacional está activa. Ejecuta bootstrap con `--gateway-oidc` y el
   Actor del bundle; no uses un token heredado ni `--skip-gateway` como salida
   de una falla de conexión. Si falta el catálogo o la identidad no coincide,
   detén la instalación sin READY. El humano completa Google OIDC y cualquier
   permiso nativo. No elijas cuentas, ingreses credenciales ni apruebes
   consentimientos por él.
5. Bootstrap verifica el Actor contra Core protegido y, en modo 2.1, pide al
   Gateway su catálogo de Seats y nodos. Materializa por Git/SSH solo los
   repos de ese catálogo dentro del vault de Obsidian y registra Context Sync
   filtrado por repo bajo el nombre de la instancia. Comprueba `doctor`,
   `context scope`, mapa de notas y backlinks, el worker y una señal real.
   Rechaza un nodo fuera de alcance; una señal no concede acceso.
6. Completa el onboarding conversacional una pregunta a la vez. Guarda solo
   hechos durables en el destino autorizado y confirma su recibo. Cierra cada
   turno sustantivo con `memory-checkpoint`, aun si no hay una nota que guardar;
   no infieras
   que un estado conversacional COMPLETE significa que Personal se guardó.
   Declara READY únicamente cuando identidad, contexto, worker, sincronización
   y comprobaciones de aislamiento estén sanos. El Gateway y el catálogo
   organizacional deben quedar READY para esta instancia Panky 2.1.

Para versiones posteriores, cuando el usuario diga «actualiza Panky», ejecuta
`panky-prisma upgrade --workspace <workspace>` desde el runtime de esa
instancia. El comando busca el último release aprobado para macOS o Windows
en el repositorio central Pancracio Prisma, lo descarga temporalmente y verifica la
firma contra la clave del publicador fijada en la primera instalación. Usa
`--check` si solo se pide consultar. Si no hay release accesible o la firma
falla, conserva la versión activa y explica el bloqueo; no uses el release de
otro cliente ni un `panky` global de otra instalación.

Si el proceso se interrumpe, inspecciona el recibo y usa recuperación. No
borres la carpeta ni repitas bootstrap desde cero. Para actualizaciones usa el
release firmado y el ciclo gobernado por instancia: el instalador pausa y
reanuda su worker, reconcilia los contextos, repara el mapa de Obsidian y
comprueba Doctor antes de declarar READY. Si hay `RECOVERY_REQUIRED`, reintenta
o avanza a un release firmado más nuevo sin tocar Personal. La baja también afecta solo esa instancia y exige
un recibo de que sus datos y servicios propios quedaron identificados.
