"""Reject accidental domain contents and gitlinks in the parent workspace."""

from __future__ import annotations

from pathlib import Path
import subprocess


def check(root: Path) -> None:
    root = root.resolve()
    result = subprocess.run(["git", "-C", str(root), "ls-files", "--stage", "--", "domains/"],
                            capture_output=True, text=True, check=True)
    if result.stdout.strip():
        raise RuntimeError("parent Git tracks a domain file or gitlink")
    ignored = subprocess.run(["git", "-C", str(root), "check-ignore", "-q", "domains/core/repo.yaml"])
    if ignored.returncode != 0:
        raise RuntimeError("domains/ is not ignored by parent Git")
    core = root / "domains" / "core"
    if core.exists() and not (core / ".git").is_dir():
        raise RuntimeError("Core is not an independent Git repository")


if __name__ == "__main__":
    workspace = Path(__file__).resolve().parents[2]
    check(workspace)
    print("parent/domain Git boundary valid")
