"""Pancracio CLI: verified identity, runtime composition and read-only diagnostics."""

from __future__ import annotations

import argparse
import getpass
import json
from pathlib import Path
import sys

from . import __version__
from .actor_knowledge import ActorKnowledgeError
from .authority import AuthorityDenied, RepositoryAuthority
from .composition import CompositionError, inspect_runtime, reconcile_codex_gateway
from .gateway import GatewayError, diagnose
from .identity import IdentityError, authenticate_bootstrap, authenticate_runtime
from .registry import CoreRegistry, RegistryError
from .context_sync import SyncError, freshness
from .sync_transport import TransportError, enroll_transport, decommission_transport, reconcile_transport, set_sync_state
from .sync_worker import WorkerError, install_lifecycle, lifecycle_status, lifecycle_stop, lifecycle_restart, uninstall_lifecycle
from .git_closure import ClosureBlocked, begin as begin_work, close as close_work
from .node_store14 import NodeStoreBlocked
from .publication14 import PublicationBlocked
from .personal_store14 import PersonalStoreBlocked
from .context_resolution14 import ResolutionBlocked
from .context_manifest14 import GraphManifestError
from .context_catalog20 import ContextCatalogError
from .context_topology import TopologyError
from .materialization14 import MaterializationError
from .onboarding14 import OnboardingBlocked
from .personal_topology14 import PersonalTopologyBlocked
from .release_lifecycle import UpgradeBlocked, upgrade, recover
from .obsidian_map import ObsidianMapError
from .conversation_memory import MemoryBlocked


def _actor_mode(choice: str | None) -> str:
    if choice:
        return choice
    if not sys.stdin.isatty():
        raise CompositionError("choose Actor Knowledge persistence: --actor-knowledge local|private")
    print("Actor Knowledge persistence: 1) Local only  2) New private GitHub repository")
    answer = input("Choose 1 or 2: ").strip()
    if answer not in {"1", "2"}:
        raise CompositionError("Actor Knowledge persistence choice is required")
    return "local" if answer == "1" else "private"


def _github_owner(explicit: str | None) -> str | None:
    if explicit:
        return explicit
    raise CompositionError(
        "private Actor Knowledge requires --github-owner after the setup agent creates "
        "and verifies the repository in the browser"
    )


def _gateway_token(*, prompt: bool, skip: bool) -> str | None:
    if skip:
        print("Knowledge Gateway: skipped after Actor choice")
        return None
    if not prompt:
        raise CompositionError(
            "ask the Actor whether to configure Knowledge Gateway, then use "
            "--gateway-token-prompt or --skip-gateway"
        )
    if not sys.stdin.isatty():
        raise CompositionError("--gateway-token-prompt requires an interactive terminal")
    # Keep the question visible even when a terminal wrapper hides getpass output.
    # The empty getpass prompt still masks the secret itself.
    print("Paste Knowledge Gateway token: ", end="", flush=True)
    token = getpass.getpass("").strip() or None
    if token is None:
        raise CompositionError("Knowledge Gateway token is required after the Actor chose to configure it")
    confirmation = input("Token received. Continue with Google authentication? [y/N]: ").strip().lower()
    if confirmation not in {"y", "yes"}:
        raise CompositionError("Knowledge Gateway token was not confirmed")
    return token


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="panky-prisma", description="Pancracio Prisma runtime CLI")
    commands = parser.add_subparsers(dest="command", required=True)
    commands.add_parser("version")
    update = commands.add_parser("upgrade", help="verify and apply an approved Panky product release")
    update.add_argument("--workspace", type=Path, default=Path.cwd())
    update_mode = update.add_mutually_exclusive_group()
    update_mode.add_argument("--check", action="store_true", help="report an approved update without installing it")
    update_mode.add_argument("--recover", action="store_true", help="resume a stopped governed update")
    bootstrap = commands.add_parser("bootstrap", help="Google login then compose authorized runtime")
    bootstrap.add_argument("--workspace", type=Path)
    bootstrap.add_argument("--actor-knowledge", choices=["local", "private"])
    bootstrap.add_argument("--github-owner")
    bootstrap.add_argument("--actor-repository-name")
    gateway = bootstrap.add_mutually_exclusive_group()
    gateway.add_argument(
        "--gateway-token-prompt",
        action="store_true",
        help="prompt securely for a token after the Actor chose to configure Gateway",
    )
    gateway.add_argument(
        "--skip-gateway",
        action="store_true",
        help="continue after the Actor explicitly chose not to configure Gateway",
    )
    gateway.add_argument(
        "--gateway-oidc", action="store_true",
        help="use Google OIDC and the active Gateway context catalog",
    )
    for name in ("status", "doctor"):
        diagnostic = commands.add_parser(name)
        diagnostic.add_argument("--workspace", type=Path, default=Path.cwd())
        diagnostic.add_argument("--skip-gateway", action="store_true", help="check local context without probing optional Gateway")
    graph_repair = commands.add_parser("obsidian-repair", help="repair orphaned Obsidian map links under current authority")
    graph_repair.add_argument("--workspace", type=Path, default=Path.cwd())
    graph_repair.add_argument("--apply", action="store_true")
    graph_repair.add_argument("--scope", choices=["all", "organization", "personal"], default="all")
    for name in ("sync", "reconcile"):
        command = commands.add_parser(name, help="safely reconcile authorized Git providers")
        command.add_argument("--workspace", type=Path, default=Path.cwd())
    enrollment = commands.add_parser("sync-enroll", help="authorize keyless Context Event transport and install worker")
    enrollment.add_argument("--workspace", type=Path, default=Path.cwd())
    retirement = commands.add_parser("sync-decommission", help="stop this runtime worker and revoke its owned subscription")
    retirement.add_argument("--workspace", type=Path, default=Path.cwd())
    worker = commands.add_parser("sync-worker", help="manage this runtime's background worker")
    worker.add_argument("action", choices=["install", "status", "stop", "restart", "unregister"])
    worker.add_argument("--workspace", type=Path, default=Path.cwd())
    registry = commands.add_parser("registry")
    registry.add_argument("action", choices=["validate"])
    registry.add_argument("--workspace", type=Path, default=Path.cwd())
    identity = commands.add_parser("identity")
    identity.add_argument("action", choices=["verify"])
    identity.add_argument("--workspace", type=Path, default=Path.cwd())
    policy = commands.add_parser("policy")
    policy.add_argument("action", choices=["check"])
    policy.add_argument("--repository", required=True, choices=["workspace", "core", "organization_canonical", "actor_knowledge"])
    policy.add_argument("--operation", required=True, choices=["read", "write", "commit", "push"])
    policy.add_argument("--path", default="")
    policy.add_argument("--target-actor")
    policy.add_argument("--workspace", type=Path, default=Path.cwd())
    work_begin = commands.add_parser("work-begin", help="record the baseline before a bounded durable edit")
    work_begin.add_argument("--workspace", type=Path, default=Path.cwd())
    work_begin.add_argument("--repository", required=True, choices=["workspace", "core", "organization_canonical", "actor_knowledge"])
    work_close = commands.add_parser("work-close", help="safely commit and publish a completed durable work unit")
    work_close.add_argument("--workspace", type=Path, default=Path.cwd())
    work_close.add_argument("--unit", required=True)
    work_close.add_argument("--path", action="append", required=True)
    work_close.add_argument("--message", required=True)
    context = commands.add_parser("context", help="resolve the 1.4 authorized graph for a task")
    context.add_argument("action", choices=["resolve", "attention", "scope", "materialize"])
    context.add_argument("--workspace", type=Path, default=Path.cwd())
    context.add_argument("--query")
    context.add_argument("--node")
    context.add_argument("--personal", action="store_true")
    node = commands.add_parser("node", help="governed 1.4 Context Node operation")
    node.add_argument("action", choices=["knowledge", "state", "assign", "update-work", "contribute", "reconcile", "publish"])
    node.add_argument("--workspace", type=Path, default=Path.cwd())
    node.add_argument("--node", required=True)
    node.add_argument("--title")
    node.add_argument("--text")
    node.add_argument("--kind", choices=["progress", "blocker", "handoff", "completed"], default="progress")
    node.add_argument("--audience", choices=["management", "delivery", "shared"])
    node.add_argument("--assignee-seat")
    node.add_argument("--due")
    node.add_argument("--context")
    node.add_argument("--work-item-id")
    node.add_argument("--status", choices=["OPEN", "IN_PROGRESS", "BLOCKED", "DONE"])
    node.add_argument("--evidence")
    node.add_argument("--effect")
    node.add_argument("--contribution-id")
    personal = commands.add_parser("personal-add", help="persist Actor-owned Personal/General knowledge")
    personal.add_argument("--workspace", type=Path, default=Path.cwd())
    personal.add_argument("--title", required=True)
    personal.add_argument("--text", required=True)
    personal.add_argument("--node")
    memory = commands.add_parser("memory-checkpoint", help="persist bounded durable context at turn close")
    memory.add_argument("--workspace", type=Path, default=Path.cwd())
    memory.add_argument("--session-id")
    memory_hook = commands.add_parser("memory-hook", help="handle a local Codex memory lifecycle event")
    memory_hook.add_argument("--workspace", type=Path, default=Path.cwd())
    route = commands.add_parser("route-check", help="validate a proposed durable destination against protected 1.4 policy")
    route.add_argument("--workspace", type=Path, default=Path.cwd())
    onboarding = commands.add_parser("onboarding", help="short contextual first-use routing")
    onboarding.add_argument("action", choices=["next", "turn"])
    onboarding.add_argument("--workspace", type=Path, default=Path.cwd())
    personal_node = commands.add_parser("personal-subdomain", help="govern Actor-owned Personal subdomain creation")
    personal_node.add_argument("action", choices=["propose", "create"])
    personal_node.add_argument("--workspace", type=Path, default=Path.cwd())
    personal_node.add_argument("--name", required=True)
    personal_node.add_argument("--distinct-durable-sources", type=int, required=True)
    personal_node.add_argument("--retrieval-reason", required=True)
    personal_node.add_argument("--lifecycle-reason", required=True)
    personal_node.add_argument("--actor-confirmed", action="store_true")
    args = parser.parse_args(argv)
    if args.command == "version":
        print(f"panky-prisma {__version__} — Architecture 1.4")
        return 0
    if args.command == "memory-hook":
        from .memory_turn_gate import handle_hook
        print(json.dumps(handle_hook(args.workspace, json.load(sys.stdin)), sort_keys=True))
        return 0
    try:
        if args.command == "obsidian-repair":
            from .obsidian_repair import repair
            print(json.dumps(repair(args.workspace, apply=args.apply, scope=args.scope), sort_keys=True))
            return 0
        if args.command == "upgrade":
            result = recover(args.workspace) if args.recover else upgrade(args.workspace, check_only=args.check)
            print(json.dumps(result, sort_keys=True))
            return 0
        if args.command in {"context", "node", "personal-add", "personal-subdomain", "route-check", "onboarding", "memory-checkpoint"}:
            from .node_store14 import NodeStore
            from .publication14 import generate_publication, publish_additive
            from .context_resolution14 import resolve_active_context
            from .attention14 import derive_attention
            workspace = args.workspace.resolve(strict=True)
            diagnostics = inspect_runtime(workspace, probe_gateway=False)
            if diagnostics.get("schema_version") != 3:
                raise CompositionError("1.4 Context Graph runtime required")
            # inspect_runtime adds status-only fields for humans. Authority
            # operations must receive the exact protected schema-3 manifest.
            from .composition import _read_yaml
            manifest = _read_yaml(workspace / ".panky/context-manifest.yaml")
            if manifest is None:
                raise CompositionError("Context Graph Manifest unavailable")
            trusted = CoreRegistry.load(workspace / "domains/core")
            actor = authenticate_runtime(trusted, workspace)
            commit = manifest["core_commit"]
            if args.command == "memory-checkpoint":
                from .conversation_memory import checkpoint
                result = checkpoint(workspace, actor, trusted, manifest, commit, json.load(sys.stdin))
                if args.session_id:
                    from .memory_turn_gate import record_checkpoint
                    record_checkpoint(workspace, args.session_id, result)
                print(json.dumps(result, ensure_ascii=False, sort_keys=True))
                return 0 if result["state"] not in {"BLOCKED", "PARTIAL"} else 3
            if args.command == "personal-subdomain":
                from .personal_topology14 import create_personal_subdomain
                if args.action == "propose":
                    ready = (args.distinct_durable_sources >= 3 and bool(args.retrieval_reason.strip())
                             and bool(args.lifecycle_reason.strip()))
                    print(json.dumps({"candidate": args.name, "ready_for_actor_review": ready,
                                      "owner_actor_id": actor.actor_id}, sort_keys=True))
                    return 0 if ready else 3
                node_id, result_commit = create_personal_subdomain(workspace, actor, trusted, args.name,
                    distinct_durable_sources=args.distinct_durable_sources,
                    retrieval_reason=args.retrieval_reason, lifecycle_reason=args.lifecycle_reason,
                    actor_confirmed=args.actor_confirmed)
                print(json.dumps({"node_id": node_id, "commit": result_commit}, sort_keys=True))
                return 0
            if args.command == "onboarding":
                from .onboarding14 import start_turn, advance_turn, commit_onboarding, OnboardingUnit
                from .routing14 import RoutingGate, RoutingProposal
                from .personal_topology14 import read_personal_topology
                from .composition import _read_yaml, _write_yaml_atomic
                state_path = workspace / ".panky/onboarding.yaml"
                state = _read_yaml(state_path)
                if state is None:
                    raise OnboardingBlocked("onboarding state unavailable")
                if args.action == "next":
                    state = start_turn(actor, trusted, state)
                    _write_yaml_atomic(state_path, state)
                    print(json.dumps({"status": state["status"], "question": state.get("question")}, ensure_ascii=False))
                    return 0
                if state.get("actor_id") != actor.actor_id or state.get("status") != "IN_PROGRESS":
                    raise OnboardingBlocked("start or resume onboarding before recording an answer")
                payload = json.load(sys.stdin)
                if not isinstance(payload, dict) or set(payload) - {"answer", "covered_topics", "actor_done", "units", "ambiguity"}:
                    raise OnboardingBlocked("invalid conversational turn")
                covered = payload.get("covered_topics", [])
                raw_units = payload.get("units", [])
                if (not isinstance(covered, list) or not all(isinstance(v, str) for v in covered)
                        or not isinstance(raw_units, list) or len(raw_units) > 20):
                    raise OnboardingBlocked("invalid bounded turn topics or units")
                ambiguity = payload.get("ambiguity")
                clarification = None
                if ambiguity is not None:
                    if not isinstance(ambiguity, dict) or set(ambiguity) != {"proposal", "question"}:
                        raise OnboardingBlocked("invalid ambiguity request")
                    graph = read_personal_topology(workspace, actor)
                    nodes = frozenset(node_id for node_id, row in graph["nodes"].items()
                                      if node_id != f"personal:{actor.actor_id}" and row["lifecycle"] == "ACTIVE")
                    proposed = RoutingProposal(**ambiguity["proposal"])
                    if RoutingGate(trusted, personal_nodes=nodes).decide(actor, proposed).status != "CLARIFY":
                        raise OnboardingBlocked("clarification requires a genuinely unresolved route")
                    clarification = ambiguity["question"]
                units = []
                for item in raw_units:
                    if not isinstance(item, dict) or not isinstance(item.get("proposal"), dict):
                        raise OnboardingBlocked("onboarding unit/proposal invalid")
                    proposal = RoutingProposal(**item["proposal"])
                    units.append(OnboardingUnit(item["title"], item["text"], proposal,
                                                item.get("approved_for_persistence", False), item.get("state_kind", "progress")))
                next_state = advance_turn(actor, trusted, state, answer=payload.get("answer"),
                                          covered_topics=frozenset(covered),
                                          actor_done=payload.get("actor_done", False),
                                          clarification=clarification)
                receipt = commit_onboarding(workspace, actor, trusted, manifest, commit, tuple(units))
                _write_yaml_atomic(state_path, next_state)
                print(json.dumps({"organizational": [item.__dict__ for item in receipt.organizational],
                                  "personal": [item.__dict__ for item in receipt.personal],
                                  "ephemeral_count": receipt.ephemeral_count,
                                  "status": next_state["status"], "question": next_state["question"]},
                                 ensure_ascii=False, sort_keys=True))
                return 0
            if args.command == "route-check":
                from .routing14 import RoutingGate, RoutingProposal
                from .personal_topology14 import read_personal_topology
                proposal = json.load(sys.stdin)
                if (not isinstance(proposal, dict) or set(proposal) - set(RoutingProposal.__dataclass_fields__)
                        or not {"durable", "owner", "node_id", "surface"}.issubset(proposal)):
                    raise CompositionError("routing proposal contains unsupported fields")
                personal_graph = read_personal_topology(workspace, actor)
                personal_nodes = frozenset(node_id for node_id, row in personal_graph['nodes'].items()
                                           if node_id != f'personal:{actor.actor_id}' and row['lifecycle'] == 'ACTIVE')
                decision = RoutingGate(trusted, personal_nodes=personal_nodes).decide(actor, RoutingProposal(**proposal))
                print(json.dumps(decision.__dict__, sort_keys=True))
                return 0 if decision.status in {"PERSIST", "EPHEMERAL", "RECONCILIATION_REQUIRED"} else 3
            if args.command == "context":
                if args.action == "materialize":
                    if not args.node:
                        raise CompositionError("context materialize requires --node")
                    from .composition14 import materialize_node14
                    candidate = materialize_node14(workspace, actor, trusted, manifest, args.node)
                    print(json.dumps({"node_id": args.node,
                                      "materialized_bindings": sorted(candidate["materialized_bindings"])}, sort_keys=True))
                elif args.action == "scope":
                    print(json.dumps({"actor_id": actor.actor_id, "anchors": manifest["anchors"],
                                      "authorized_nodes": manifest["authorized_nodes"],
                                      "materialized_bindings": list(manifest["materialized_bindings"])}, sort_keys=True))
                elif args.action == "attention":
                    result = derive_attention(workspace, actor, trusted, manifest, expected_core_commit=commit)
                    print(json.dumps({"items": [item.__dict__ for item in result.items],
                                      "partial": result.partial,
                                      "materialized_nodes_checked": result.materialized_nodes_checked}, sort_keys=True))
                else:
                    if not args.query:
                        raise CompositionError("context resolve requires --query")
                    result = resolve_active_context(workspace, args.query, actor, trusted, manifest,
                                                    expected_core_commit=commit, include_personal=args.personal)
                    print(json.dumps({"node_ids": result.node_ids, "sources": [item.__dict__ for item in result.sources],
                                      "personal_requested": args.personal,
                                      "personal_included": result.personal_included,
                                      "personal_status": result.personal_status,
                                      "status": result.status}, sort_keys=True))
                return 0
            if args.command == "personal-add":
                from .personal_store14 import add_personal_to_node
                result = add_personal_to_node(workspace, actor, trusted,
                                              args.node or f'personal:{actor.actor_id}:general',
                                              args.title, args.text, mode=manifest["personal"]["mode"])
                print(json.dumps(result.__dict__, sort_keys=True))
                return 0
            store = NodeStore(workspace, actor, trusted, manifest, commit)
            if args.action == "knowledge":
                result = store.add_knowledge(args.node, args.title or "", args.text or "", audience=args.audience)
            elif args.action == "state":
                result = store.add_state(args.node, args.text or "", kind=args.kind)
            elif args.action == "assign":
                result = store.assign_work(args.node, args.title or "", assignee_seat=args.assignee_seat,
                                           due=args.due, context=args.context)
            elif args.action == "update-work":
                if not args.status:
                    raise CompositionError("update-work requires --status")
                result = store.update_work(args.node, args.work_item_id or "", args.status, outcome=args.text)
            elif args.action == "contribute":
                result = store.propose_contribution(args.node, args.text or "", args.evidence or "", args.effect or "")
            elif args.action == "reconcile":
                result = store.reconcile_contribution(args.node, args.contribution_id or "",
                    verified_text=args.text or "", verified_evidence=args.evidence or "", audience=args.audience or "management")
            else:
                from .node_authority import NodeAuthority
                binding = NodeAuthority(trusted).binding(args.node, "Published")
                edge = trusted.publication_edges["edges"][args.node]
                source = NodeAuthority(trusted).bindings[edge["publication"]["source_store_id"]]
                candidate = generate_publication(workspace / source.local_path, trusted, args.node)
                result = publish_additive(candidate, workspace / binding.local_path, trusted, actor)
            print(json.dumps(result if isinstance(result, str) else
                             [item.__dict__ for item in result] if isinstance(result, tuple) else result.__dict__, sort_keys=True))
            return 0
        if args.command in {"status", "doctor"}:
            data = inspect_runtime(args.workspace.resolve(), probe_gateway=not args.skip_gateway)
            print(f"Actor: {data['actor_id']} ({data['role']})")
            print(f"Runtime: {data['runtime_id']}")
            print("Architecture: 1.4")
            print(f"Product CLI: {__version__}; manifest schema: {data['schema_version']}; topology schema: {data['topology_schema_version']}")
            print(f"Authorized nodes: {len(data['authorized_nodes'])}")
            print(f"Materialized bindings: {len(data['materialized_bindings'])}")
            print(f"Anchors: {', '.join(data['anchors']) or 'none'}")
            print(f"Personal topology: {data.get('personal_topology_state')} ({data.get('personal_topology_nodes')} nodes)")
            print(f"Contextual onboarding: {data.get('onboarding_state')}")
            gateway_detail = "NOT_CHECKED" if args.skip_gateway else diagnose(args.workspace.resolve() / ".panky")
            print(f"Gateway: {gateway_detail}")
            print(f"Sync: {data['sync']['state']}")
            print(f"Sync worker: {lifecycle_status(args.workspace.resolve())}")
            if args.command == "doctor":
                repository_health = freshness(args.workspace.resolve())
                for repo_id, result in sorted(repository_health.items()):
                    print(f"Freshness {repo_id}: {result.result}")
                from .obsidian_map import audit_mounted_graph, audit_personal_graph
                graph = audit_mounted_graph(args.workspace.resolve())
                graph[f"actor-private:{data['actor_id']}"] = audit_personal_graph(
                    args.workspace.resolve(), data["actor_id"])
                for repo_id, report in sorted(graph.items()):
                    print(f"Obsidian graph {repo_id}: {report.status} "
                          f"({report.notes} notes, {report.orphans} orphaned)")
                if any(report.status != "READY" for report in graph.values()):
                    return 3
            return 0
        if args.command in {"sync", "reconcile"}:
            workspace = args.workspace.resolve()
            results = freshness(workspace)
            from prisma_common.repository_profile import repository_profile
            core_repository_id = repository_profile(workspace).core_id
            if args.command == "reconcile" and results.get(core_repository_id) and \
                    results[core_repository_id].result == "TOPOLOGY_RECONCILIATION_REQUIRED":
                from .composition14 import reconcile_graph_runtime14
                reconcile_graph_runtime14(workspace)
                results = freshness(workspace)
            for repo_id, result in sorted(results.items()):
                print(f"{repo_id}: {result.result} ({result.before})")
            if args.command == "reconcile":
                reconcile_codex_gateway(workspace)
                core_result = results.get(core_repository_id)
                if core_result is None or core_result.result not in {"CURRENT", "NO_CHANGE"}:
                    print("Sync worker: DEGRADED (Core freshness requires reconciliation)")
                else:
                    try:
                        if (workspace / ".panky" / "sync" / "transport.yaml").is_file():
                            reconcile_transport(workspace)
                        else:
                            enroll_transport(workspace)
                        print(f"Sync worker: {install_lifecycle(workspace)}")
                        set_sync_state(workspace, "READY")
                    except (WorkerError, TransportError):
                        set_sync_state(workspace, "DEGRADED")
                        raise
            return 0 if all(result.result in {"CURRENT", "NO_CHANGE", "DIRTY"} for result in results.values()) else 4
        if args.command == "sync-enroll":
            workspace = args.workspace.resolve()
            inspect_runtime(workspace)
            enroll_transport(workspace)
            try:
                label = install_lifecycle(workspace)
            except WorkerError:
                set_sync_state(workspace, "DEGRADED")
                raise
            print(f"Context Sync worker installed: {label}")
            return 0
        if args.command == "sync-decommission":
            workspace = args.workspace.resolve()
            # Decommission must remain possible after Core or the graph manifest
            # becomes stale. The transport broker verifies fresh Google proof
            # and the subscription's runtime owner before deleting it.
            if lifecycle_status(workspace) not in {"STOPPED", "NOT_ENROLLED"}:
                lifecycle_stop(workspace)
            decommission_transport(workspace)
            uninstall_lifecycle(workspace)
            print("Context Sync transport decommissioned for this runtime")
            return 0
        if args.command == "sync-worker":
            workspace = args.workspace.resolve()
            inspect_runtime(workspace)
            if args.action == "install":
                try:
                    label = install_lifecycle(workspace)
                    set_sync_state(workspace, "READY")
                except WorkerError:
                    set_sync_state(workspace, "DEGRADED")
                    raise
                print(f"Sync worker installed: {label}")
            elif args.action == "stop":
                lifecycle_stop(workspace)
                print("Sync worker stopped")
            elif args.action == "restart":
                lifecycle_restart(workspace)
                print("Sync worker restarted")
            elif args.action == "unregister":
                uninstall_lifecycle(workspace)
                print("Sync worker registration removed; subscription preserved")
            else:
                print(f"Sync worker: {lifecycle_status(workspace)}")
            return 0
        if args.command == "work-begin":
            print(f"Work unit: {begin_work(args.workspace, args.repository)}")
            return 0
        from .composition import _default_workspace
        workspace_path = args.workspace or _default_workspace()
        if args.command == "bootstrap":
            from .composition14 import prepare_customer_repositories
            core = prepare_customer_repositories(workspace_path)
            args.workspace = workspace_path
        else:
            core = CoreRegistry.load(workspace_path / "domains" / "core")
        if args.command == "registry":
            print("customer Core Registry verified")
            return 0
        bootstrap_options = None
        if args.command == "bootstrap":
            mode = _actor_mode(args.actor_knowledge)
            if mode == "private" and not args.actor_repository_name:
                raise CompositionError(
                    "private Actor Knowledge requires --actor-repository-name after the setup "
                    "agent creates and verifies the repository in the browser"
                )
            owner = _github_owner(args.github_owner) if mode == "private" else None
            token = (None if args.gateway_oidc else _gateway_token(
                prompt=args.gateway_token_prompt,
                skip=args.skip_gateway,
            ))
            bootstrap_options = (mode, owner, token)
        bootstrap_authentication = authenticate_bootstrap(core) if args.command == "bootstrap" else None
        actor = (bootstrap_authentication.actor if bootstrap_authentication is not None
                 else authenticate_runtime(core, args.workspace.resolve()))
        if args.command == "work-close":
            workspace = args.workspace.resolve()
            inspect_runtime(workspace, probe_gateway=False)
            trusted = CoreRegistry.load(workspace / "domains" / "core")
            print(f"Persisted: {close_work(workspace, args.unit, actor, trusted, args.path, args.message)}")
            return 0
        if args.command == "bootstrap":
            assert bootstrap_options is not None
            mode, owner, token = bootstrap_options
            from .composition14 import compose_runtime14
            manifest = compose_runtime14(actor, core, workspace=args.workspace,
                                         actor_mode=mode, gateway_token=token,
                                         approved_owner=owner,
                                         actor_repository_name=args.actor_repository_name,
                                         google_id_token=(bootstrap_authentication.id_token
                                                          if args.gateway_oidc else None))
            runtime_workspace = manifest.parent.parent
            if args.gateway_oidc and not (runtime_workspace / ".panky/sync/transport.yaml").is_file():
                assert bootstrap_authentication is not None
                enroll_transport(runtime_workspace, actor=actor,
                                 refresh_token=bootstrap_authentication.refresh_token)
            if args.gateway_oidc:
                from .personal_topology14 import initialize_personal_topology
                initialize_personal_topology(runtime_workspace, actor,
                                             CoreRegistry.load(runtime_workspace / "domains/core"))
            runtime = inspect_runtime(runtime_workspace)
            if runtime["sync"]["state"] == "DEGRADED":
                print("Context Sync remains DEGRADED; use explicit sync-worker repair after diagnosis")
            else:
                if not (runtime_workspace / ".panky" / "sync" / "transport.yaml").is_file():
                    assert bootstrap_authentication is not None
                    enroll_transport(
                        runtime_workspace,
                        actor=actor,
                        refresh_token=bootstrap_authentication.refresh_token,
                    )
                try:
                    install_lifecycle(runtime_workspace)
                except WorkerError:
                    set_sync_state(runtime_workspace, "DEGRADED")
                    raise
            print(f"Pancracio runtime composed: {actor.actor_id} ({actor.role})")
            print(f"Authorized Context View manifest: {manifest}")
            return 0
        if args.command == "identity":
            print(f"Google authenticated Actor: {actor.actor_id} ({actor.role})")
            return 0
        decision = RepositoryAuthority(core).decide(actor, args.repository, args.operation,
                                                      path=args.path, target_actor_id=args.target_actor)
        print(f"{'ALLOW' if decision.allowed else 'DENY'}: {decision.reason}")
        return 0 if decision.allowed else 3
    except (RegistryError, IdentityError, CompositionError, AuthorityDenied, ClosureBlocked,
            ActorKnowledgeError, GatewayError, SyncError, TransportError, WorkerError, NodeStoreBlocked,
            PublicationBlocked, PersonalStoreBlocked, ResolutionBlocked, GraphManifestError, TopologyError,
            MaterializationError, OnboardingBlocked, PersonalTopologyBlocked, UpgradeBlocked,
            ContextCatalogError, ObsidianMapError, MemoryBlocked,
            TypeError, KeyError, OSError) as exc:
        print(f"Pancracio error: {exc}", file=sys.stderr)
        return 3


if __name__ == "__main__":
    raise SystemExit(main())
