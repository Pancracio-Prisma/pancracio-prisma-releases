"""Pancracio 1.4 graph-derived runtime composition and inspection."""

from __future__ import annotations

from pathlib import Path
from typing import Any
import os
import shutil
import stat
import time
import yaml

from .actor_knowledge import initialize_actor_knowledge
from .authority import RepositoryAuthority
from .composition import (_bind_owner, _clone, _compose_codex, _default_workspace,
                          _git, _read_yaml, _safe_fast_forward, _verify_obsidian,
                          _verify_repo, _write_yaml_atomic)
from prisma_common.repository_profile import repository_profile
from .context_manifest14 import derive_graph_manifest, validate_graph_manifest
from .gateway import probe, store_token
from .identity import VerifiedActor
from .materialization14 import _local, _verify_binding, materialize_authorized, MaterializationError
from .node_authority import NodeAuthority
from .registry import CoreRegistry


class Composition14Error(ValueError):
    pass


def prepare_customer_repositories(workspace: Path) -> CoreRegistry:
    """Clone only the signed customer remotes before Actor bootstrap."""
    workspace = workspace.expanduser().resolve()
    remotes = repository_profile(workspace)
    if not workspace.exists():
        _clone(remotes.workspace_remote, workspace)
    _verify_repo(workspace, remotes.workspace_remote)
    _safe_fast_forward(workspace)
    from prisma_common.installed_binding import load_installed_binding
    initial_workspace_commit = load_installed_binding(workspace)["resources"]["github"]["workspace_expected_commit"]
    _git(workspace, "merge-base", "--is-ancestor", initial_workspace_commit,
         "refs/remotes/origin/main")
    _marker14(workspace)
    core_root = workspace / "domains" / "core"
    workspace_origin = _git(workspace, "remote", "get-url", "origin")
    core_remote = (remotes.core_remote.replace("git@github.com:", "https://github.com/")
                   if workspace_origin.startswith("https://") else remotes.core_remote)
    if not core_root.exists():
        _clone(core_remote, core_root)
    _verify_repo(core_root, remotes.core_remote)
    _safe_fast_forward(core_root)
    return CoreRegistry.load(core_root)


def _retire_generated_checkout(path: Path, store_id: str) -> None:
    """Remove a disposable old publication, including Windows read-only Git files.

    A failed attempt may have removed some files already. Retrying from the
    protected old manifest must be safe without a surviving marker.
    """
    def clear_readonly(operation, failed_path, error):
        if not isinstance(error, PermissionError) or Path(failed_path).is_symlink():
            raise error
        mode = os.stat(failed_path, follow_symlinks=False).st_mode
        os.chmod(failed_path, mode | stat.S_IWUSR)
        operation(failed_path)

    for attempt in range(20):
        try:
            shutil.rmtree(path, onexc=clear_readonly)
            return
        except FileNotFoundError:
            return
        except PermissionError as exc:
            if attempt == 19:
                raise Composition14Error(
                    f"retired publication is still locked: {store_id}") from exc
            time.sleep(0.5)


def _marker14(workspace: Path) -> None:
    marker = yaml.safe_load((workspace / "panky.yaml").read_text(encoding="utf-8"))
    compatibility = marker.get("compatibility", {}) if isinstance(marker, dict) else {}
    if (marker.get("architecture_version") != "1.4"
            or compatibility.get("context_manifest_schema_version") != 3
            or compatibility.get("context_graph_schema_version") != 1):
        raise Composition14Error("Workspace 1.4 compatibility marker required")


def compose_runtime14(actor: VerifiedActor, release_registry: CoreRegistry, *,
                      workspace: Path | None = None, actor_mode: str,
                      gateway_token: str | None = None, approved_owner: str | None = None,
                      actor_repository_name: str | None = None,
                      google_id_token: str | None = None,
                      fixture: bool = False) -> Path:
    if google_id_token is not None and gateway_token is not None:
        raise Composition14Error("choose one Gateway authentication method")
    workspace = (workspace or _default_workspace()).expanduser().resolve()
    if not fixture:
        registry = prepare_customer_repositories(workspace)
    _marker14(workspace)
    core_root = workspace / "domains" / "core"
    if not fixture:
        core_commit = _git(core_root, "rev-parse", "refs/remotes/origin/main")
    else:
        registry = release_registry
        core_commit = _git(core_root, "rev-parse", "HEAD") if (core_root / ".git").is_dir() else "0" * 40
    graph = NodeAuthority(registry).graph
    graph.actor_principals(actor, registry)
    runtime_root = workspace / ".panky"
    existing = _read_yaml(runtime_root / "context-manifest.yaml")
    if existing is not None and existing.get("schema_version") != 3:
        raise Composition14Error("old runtime state requires governed reconstruction")
    runtime_id = _bind_owner(runtime_root, actor)
    catalog = None
    if google_id_token is not None:
        from .context_catalog20 import fetch_catalog
        catalog = fetch_catalog(runtime_root, google_id_token=google_id_token)
    personal = initialize_actor_knowledge(workspace / "domains", actor, RepositoryAuthority(registry),
                                          actor_mode, approved_owner=approved_owner,
                                          repository_name=actor_repository_name,
                                          template_remote=repository_profile(workspace).actor_template_remote,
                                          organization_owner=repository_profile(workspace).owner)
    if existing is not None and (existing["actor_id"] != actor.actor_id
                                 or existing["google_subject_sha256"] != __import__("hashlib").sha256(actor.google_subject.encode()).hexdigest()
                                 or existing["personal"]["remote"] != personal.remote):
        raise Composition14Error("existing 1.4 runtime ownership or Personal persistence differs")
    if gateway_token is not None:
        store_token(runtime_root, gateway_token)
    if catalog is not None:
        mode_path = runtime_root / "gateway-auth-mode"
        if mode_path.is_symlink():
            raise Composition14Error("Gateway authentication mode path is unsafe")
        if mode_path.exists() and mode_path.read_text(encoding="utf-8").strip() != "oidc":
            raise Composition14Error("existing Gateway authentication mode differs")
        mode_path.write_text("oidc\n", encoding="utf-8")
    gateway_status = "CONFIGURED_REACHABLE" if catalog is not None else probe(runtime_root)
    _verify_obsidian(workspace)
    _compose_codex(workspace, runtime_root, gateway_status)
    manifest_args = dict(runtime_id=runtime_id, personal_mode=personal.mode,
                         personal_remote=personal.remote, gateway_status=gateway_status,
                         sync_state="READY" if (runtime_root / "sync/transport.yaml").is_file()
                         else "NOT_ENROLLED", core_commit=core_commit)
    if catalog is None:
        manifest = derive_graph_manifest(actor, registry, **manifest_args)
    else:
        from .context_catalog20 import manifest_from_catalog
        manifest = manifest_from_catalog(catalog, actor, registry, **manifest_args)
    materialize_authorized(workspace, manifest, actor, registry,
                           expected_core_commit=core_commit, clone=not fixture, catalog=catalog)
    target = runtime_root / "context-manifest.yaml"
    _write_yaml_atomic(target, manifest)
    onboarding_state = runtime_root / "onboarding.yaml"
    if onboarding_state.exists():
        previous = _read_yaml(onboarding_state)
        if previous is None or previous.get("actor_id") != actor.actor_id:
            raise Composition14Error("onboarding state belongs to another Actor")
    else:
        _write_yaml_atomic(onboarding_state, {"schema_version": 1, "actor_id": actor.actor_id,
                                             "status": "PENDING"})
    if not fixture:
        from .personal_topology14 import initialize_personal_topology
        initialize_personal_topology(workspace, actor, registry)
    return target


def inspect_runtime14(workspace: Path, *, probe_gateway: bool = True) -> dict[str, Any]:
    workspace = workspace.resolve(strict=True)
    _marker14(workspace)
    manifest = _read_yaml(workspace / ".panky/context-manifest.yaml")
    owner = _read_yaml(workspace / ".panky/owner.yaml")
    if manifest is None or owner is None:
        raise Composition14Error("1.4 runtime is not composed")
    validate_graph_manifest(manifest)
    if any(manifest.get(k) != owner.get(k) for k in ("actor_id", "runtime_id", "google_subject_sha256")):
        raise Composition14Error("runtime owner/manifest mismatch")
    core_root = workspace / "domains/core"
    registry = CoreRegistry.load(core_root)
    trusted_commit = _git(core_root, "rev-parse", "refs/remotes/origin/main")
    if manifest["core_commit"] != trusted_commit:
        raise Composition14Error("TOPOLOGY_UNAVAILABLE: Core policy changed; graph reconciliation required")
    record = registry.actors.get(manifest["actor_id"])
    if record is None or record["status"] != "active" or record["roles"] != [manifest["role"]]:
        raise Composition14Error("AUTHORITY_UNRESOLVED: Actor/Registry mismatch")
    pseudo = VerifiedActor(manifest["actor_id"], manifest["role"], "inspection-only",
                           record["identities"]["google_oidc"]["email"])
    mode_path = workspace / ".panky/gateway-auth-mode"
    if mode_path.is_symlink():
        raise Composition14Error("Gateway authentication mode path is unsafe")
    oidc_mode = mode_path.exists() and mode_path.read_text(encoding="utf-8").strip() == "oidc"
    if oidc_mode:
        from .context_catalog20 import fetch_catalog, verify_catalog_manifest
        catalog = fetch_catalog(workspace / ".panky")
        verify_catalog_manifest(manifest, catalog, pseudo, registry,
                                expected_core_commit=trusted_commit, check_subject=False)
    else:
        expected = derive_graph_manifest(pseudo, registry, runtime_id=manifest["runtime_id"],
                                         personal_mode=manifest["personal"]["mode"],
                                         personal_remote=manifest["personal"]["remote"],
                                         gateway_status=manifest["gateway"]["status"],
                                         sync_state=manifest["sync"]["state"], core_commit=trusted_commit,
                                         requested_nodes=frozenset(row["node_id"] for row in manifest["materialized_bindings"].values()))
        for key in ("schema_version", "architecture_version", "role", "anchors", "authorized_nodes",
                    "materialized_bindings", "personal", "topology_schema_version"):
            if manifest[key] != expected[key]:
                raise Composition14Error("manifest expands or differs from protected Core graph")
    authority = NodeAuthority(registry)
    for store_id, binding in authority.bindings.items():
        path = _local(workspace, binding.local_path)
        if store_id in manifest["materialized_bindings"]:
            _verify_binding(path, binding)
        elif path.exists():
            raise Composition14Error("unauthorized backing bytes remain in Workspace")
    actor_root = workspace / "domains/actor"
    if actor_root.is_symlink() or not (actor_root / ".git").is_dir():
        raise Composition14Error("Personal backing unavailable")
    from .personal_topology14 import read_personal_topology, PersonalTopologyBlocked
    try:
        personal_graph = read_personal_topology(workspace, pseudo)
        manifest["personal_topology_nodes"] = len(personal_graph["nodes"])
        manifest["personal_topology_state"] = "READY"
    except PersonalTopologyBlocked:
        manifest["personal_topology_nodes"] = 0
        manifest["personal_topology_state"] = "PENDING_OR_INVALID"
    onboarding = _read_yaml(workspace / ".panky/onboarding.yaml")
    manifest["onboarding_state"] = onboarding.get("status") if onboarding and onboarding.get("actor_id") == manifest["actor_id"] else "PENDING"
    if probe_gateway:
        manifest["gateway"]["status"] = probe(workspace / ".panky")
    manifest["unmounted_domains"] = []
    return manifest


def reconcile_graph_runtime14(workspace: Path) -> dict[str, Any]:
    """Re-derive after a protected Core update and retire clean stale mounts.

    A Context Event never calls this function. The caller must run the
    authenticated reconcile operation after the fixed Core backing is current.
    Unpublished local work or unverifiable remote state blocks retirement.
    """
    from .identity import authenticate_runtime

    workspace = workspace.resolve(strict=True)
    _marker14(workspace)
    mode_path = workspace / ".panky/gateway-auth-mode"
    if mode_path.is_symlink():
        raise Composition14Error("Gateway authentication mode path is unsafe")
    if mode_path.is_file() and mode_path.read_text(encoding="utf-8").strip() == "oidc":
        return _reconcile_oidc_runtime(workspace)
    old = _read_yaml(workspace / ".panky/context-manifest.yaml")
    owner = _read_yaml(workspace / ".panky/owner.yaml")
    if old is None or owner is None:
        raise Composition14Error("1.4 runtime enrollment unavailable")
    validate_graph_manifest(old)
    if any(old.get(k) != owner.get(k) for k in ("actor_id", "runtime_id", "google_subject_sha256")):
        raise Composition14Error("runtime owner/manifest mismatch")
    core_root = workspace / "domains/core"
    registry = CoreRegistry.load(core_root)
    actor = authenticate_runtime(registry, workspace, allow_stale_context=True)
    if actor.actor_id != owner["actor_id"] or __import__("hashlib").sha256(actor.google_subject.encode()).hexdigest() != owner["google_subject_sha256"]:
        raise Composition14Error("fresh Google Actor differs from runtime owner")
    core_commit = _git(workspace / "domains/core", "rev-parse", "refs/remotes/origin/main")
    old_registry = CoreRegistry.load_at_trusted_commit(core_root, old["core_commit"])
    from .context_manifest14 import verify_graph_manifest
    verify_graph_manifest(old, actor, old_registry, expected_core_commit=old["core_commit"])
    # Retain only already mounted nodes that remain discoverable. Newly eager
    # descendants are selected by protected materialization policy.
    authority = NodeAuthority(registry)
    old_nodes = frozenset(row["node_id"] for row in old["materialized_bindings"].values())
    allowed = frozenset(node for node in old_nodes
                        if authority.graph.decide_actor(actor, registry, node, "discover").allowed)
    candidate = derive_graph_manifest(actor, registry, runtime_id=old["runtime_id"],
                                      personal_mode=old["personal"]["mode"],
                                      personal_remote=old["personal"]["remote"],
                                      gateway_status=old["gateway"]["status"],
                                      sync_state=old["sync"]["state"], core_commit=core_commit,
                                      requested_nodes=allowed)
    retired = {store_id for store_id, row in old["materialized_bindings"].items()
               if candidate["materialized_bindings"].get(store_id) != row}
    old_authority = NodeAuthority(old_registry)
    # Preflight every retirement before deleting any. Published clean Git and
    # exact remote readback provide recovery; dirty/diverged work is preserved.
    retire_paths: list[Path] = []
    for store_id in sorted(retired):
        binding = old_authority.bindings[store_id]
        path = _local(workspace, binding.local_path)
        if not path.exists():
            continue
        _verify_binding(path, binding)
        if _git(path, "status", "--porcelain"):
            raise Composition14Error("STALE_BYTES_REQUIRE_GOVERNED_DEMATERIALIZATION: local work exists")
        _git(path, "fetch", "origin", "main")
        head = _git(path, "rev-parse", "HEAD")
        remote = _git(path, "rev-parse", "refs/remotes/origin/main")
        published = _git(path, "ls-remote", "origin", "refs/heads/main").split()
        if head != remote or not published or published[0] != head:
            raise Composition14Error("STALE_BYTES_REQUIRE_GOVERNED_DEMATERIALIZATION: remote readback differs")
        retire_paths.append(path)
    new_authority = NodeAuthority(registry)
    for store_id, binding in new_authority.bindings.items():
        path = _local(workspace, binding.local_path)
        if (store_id not in candidate["materialized_bindings"] and path.exists()
                and path not in retire_paths):
            raise Composition14Error("unauthorized backing bytes require separate governed cleanup")
    for path in retire_paths:
        shutil.rmtree(path)
    materialize_authorized(workspace, candidate, actor, registry,
                           expected_core_commit=core_commit, clone=True)
    _write_yaml_atomic(workspace / ".panky/context-manifest.yaml", candidate)
    return candidate


def _reconcile_oidc_runtime(workspace: Path) -> dict[str, Any]:
    """Replace only organizational mounts from the current Gateway scope.

    The Actor's Personal repository and its Obsidian configuration are never
    candidates for retirement. An incomplete reconciliation leaves the old
    manifest, so reads fail closed until a later retry succeeds.
    """
    from .context_catalog20 import fetch_catalog, manifest_from_catalog
    from .context_manifest14 import validate_graph_manifest
    from .identity import authenticate_runtime

    state = workspace / ".panky"
    old = _read_yaml(state / "context-manifest.yaml")
    owner = _read_yaml(state / "owner.yaml")
    if old is None or owner is None:
        raise Composition14Error("Panky runtime enrollment unavailable")
    validate_graph_manifest(old)
    if any(old.get(key) != owner.get(key) for key in
           ("actor_id", "runtime_id", "google_subject_sha256")):
        raise Composition14Error("runtime owner/manifest mismatch")
    core_root = workspace / "domains/core"
    registry = CoreRegistry.load(core_root)
    if registry.actors.get(owner["actor_id"], {}).get("status") != "active":
        return _retire_disabled_oidc_runtime(workspace, old, owner, registry)
    actor = authenticate_runtime(registry, workspace, allow_stale_context=True)
    if (actor.actor_id != owner["actor_id"] or
            __import__("hashlib").sha256(actor.google_subject.encode()).hexdigest()
            != owner["google_subject_sha256"]):
        raise Composition14Error("fresh Google Actor differs from runtime owner")
    core_commit = _git(core_root, "rev-parse", "refs/remotes/origin/main")
    catalog = fetch_catalog(state)
    candidate = manifest_from_catalog(
        catalog, actor, registry, runtime_id=old["runtime_id"],
        personal_mode=old["personal"]["mode"],
        personal_remote=old["personal"]["remote"],
        gateway_status=old["gateway"]["status"],
        sync_state=old["sync"]["state"], core_commit=core_commit,
    )
    old_registry = CoreRegistry.load_at_trusted_commit(core_root, old["core_commit"])
    old_authority = NodeAuthority(old_registry)
    new_authority = NodeAuthority(registry)
    retire_paths: list[Path] = []
    for store_id, row in old["materialized_bindings"].items():
        binding = old_authority.bindings.get(store_id)
        if (binding is None or row != {
                "node_id": binding.node_id, "path": binding.local_path,
                "repository": binding.repository, "generation": binding.generation,
                "state": "MATERIALIZED"}):
            raise Composition14Error("old organizational mount differs from protected Core")
        if candidate["materialized_bindings"].get(store_id) == row:
            continue
        path = _local(workspace, binding.local_path)
        if not path.exists():
            continue
        if path.is_symlink() or not path.resolve().is_relative_to(workspace):
            raise Composition14Error("organizational mount path is unsafe")
        if binding.mode == "generated":
            # Retired publication checkouts are disposable projections. A
            # malformed Git root must not strand an upgrade after Core has
            # removed the publication node, but the marker must still prove
            # which generated node owns these bytes before we retire them.
            marker_path = path / "publication.yaml"
            if not path.is_dir() or not path.is_relative_to(workspace / "domains/publications"):
                raise Composition14Error("retired publication path is invalid")
            if marker_path.is_symlink():
                raise Composition14Error("retired publication marker is unsafe")
            if marker_path.exists():
                marker = yaml.safe_load(marker_path.read_text(encoding="utf-8"))
                if (not isinstance(marker, dict)
                        or marker.get("target_node_id") != binding.node_id
                        or marker.get("generation") != binding.generation):
                    raise Composition14Error("retired publication marker differs from Core")
        else:
            _verify_binding(path, binding)
        retire_paths.append(path)
    # A preexisting destination outside the retired set is never overwritten.
    for store_id, row in candidate["materialized_bindings"].items():
        binding = new_authority.bindings[store_id]
        path = _local(workspace, binding.local_path)
        if path.exists() and path not in retire_paths:
            _verify_binding(path, binding)
    for path in retire_paths:
        old_binding = next(binding for binding in old_authority.bindings.values()
                           if _local(workspace, binding.local_path) == path)
        if old_binding.mode == "generated":
            _retire_generated_checkout(path, old_binding.store_id)
        else:
            shutil.rmtree(path)
    materialize_authorized(workspace, candidate, actor, registry,
                           expected_core_commit=core_commit, clone=True, catalog=catalog)
    _write_yaml_atomic(state / "context-manifest.yaml", candidate)
    return candidate


def _retire_disabled_oidc_runtime(workspace: Path, old: dict[str, Any],
                                  owner: dict[str, Any], registry: CoreRegistry) -> dict[str, Any]:
    """Remove only verified organizational mounts after an explicit revocation.

    A transient Gateway failure, a different Google identity, or a stale local
    marker cannot become authority to erase the Actor's Personal vault.
    """
    import hashlib
    from .context_catalog20 import fetch_catalog
    from .context_manifest14 import verify_graph_manifest
    from .identity import load_desktop_client_config, validate_google_id_token
    from .sync_transport import _fresh_google_id_token, decommission_transport

    state = workspace / ".panky"
    core_root = workspace / "domains/core"
    previous = CoreRegistry.load_at_trusted_commit(core_root, old["core_commit"])
    record = previous.actors.get(owner["actor_id"])
    if not record or len(record.get("roles", [])) != 1:
        raise Composition14Error("previous Actor identity is unavailable")
    claims = validate_google_id_token(
        _fresh_google_id_token(workspace, allow_disabled=True),
        load_desktop_client_config(workspace)["installed"]["client_id"],
    )
    if (hashlib.sha256(claims["sub"].encode()).hexdigest() != owner["google_subject_sha256"]
            or claims["email"].casefold() != record["identities"]["google_oidc"]["email"].casefold()):
        raise Composition14Error("Google proof differs from enrolled Actor")
    if fetch_catalog(state) != {"status": "denied", "reason": "actor_disabled"}:
        raise Composition14Error("explicit Actor revocation is not confirmed by Gateway")
    authority = NodeAuthority(previous)
    retire_paths: list[Path] = []
    for store_id, row in old["materialized_bindings"].items():
        binding = authority.bindings.get(store_id)
        if (binding is None or row != {
                "node_id": binding.node_id, "path": binding.local_path,
                "repository": binding.repository, "generation": binding.generation,
                "state": "MATERIALIZED"}):
            raise Composition14Error("organizational mount differs from previous Core")
        path = _local(workspace, binding.local_path)
        if (not path.is_relative_to(workspace / "domains")
                or path.is_relative_to(workspace / "domains/actor")
                or path.is_symlink()):
            raise Composition14Error("organizational retirement path is unsafe")
        if path.exists():
            if not path.is_dir():
                raise Composition14Error("organizational retirement path is not a directory")
            retire_paths.append(path)
    if (state / "sync/transport.yaml").is_file():
        decommission_transport(workspace)
    for path in retire_paths:
        shutil.rmtree(path)
    receipt = {"status": "REVOKED", "actor_id": owner["actor_id"],
               "retired_backings": sorted(old["materialized_bindings"])}
    _write_yaml_atomic(state / "offboarding.yaml", receipt)
    from .sync_worker import uninstall_lifecycle
    uninstall_lifecycle(workspace)
    return receipt


def materialize_node14(workspace: Path, actor: VerifiedActor, registry: CoreRegistry,
                       manifest: dict[str, Any], node_id: str) -> dict[str, Any]:
    """Lazily clone one already-authorized readable node from Core policy."""
    from .context_manifest14 import verify_graph_manifest

    workspace = workspace.resolve(strict=True)
    trusted_commit = _git(workspace / "domains/core", "rev-parse", "refs/remotes/origin/main")
    verify_graph_manifest(manifest, actor, registry, expected_core_commit=trusted_commit)
    selected = {row["node_id"] for row in manifest["materialized_bindings"].values()}
    selected.add(node_id)
    candidate = derive_graph_manifest(actor, registry, runtime_id=manifest["runtime_id"],
                                      personal_mode=manifest["personal"]["mode"],
                                      personal_remote=manifest["personal"]["remote"],
                                      gateway_status=manifest["gateway"]["status"],
                                      sync_state=manifest["sync"]["state"],
                                      core_commit=trusted_commit, requested_nodes=frozenset(selected))
    materialize_authorized(workspace, candidate, actor, registry,
                           expected_core_commit=trusted_commit, clone=True)
    _write_yaml_atomic(workspace / ".panky/context-manifest.yaml", candidate)
    return candidate
