"""Platform-specific subprocess settings shared by background operations."""

from __future__ import annotations

import subprocess
import sys


def background_creationflags() -> int:
    """Prevent console windows for child processes started by Windows workers."""
    if sys.platform == "win32":
        return getattr(subprocess, "CREATE_NO_WINDOW", 0)
    return 0
