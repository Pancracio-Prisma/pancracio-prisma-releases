"""Actor-owned Personal/General persistence with bounded Git closure."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path, PureWindowsPath
import re
from uuid import uuid4

from .git_closure import begin as begin_work, close as close_work
from .identity import VerifiedActor
from .registry import CoreRegistry
from .personal_topology14 import read_personal_topology


class PersonalStoreBlocked(ValueError):
    pass


@dataclass(frozen=True)
class PersonalWrite:
    path: str
    commit: str
    mode: str


def add_personal_general(workspace: Path, actor: VerifiedActor, registry: CoreRegistry,
                         title: str, text: str, *, mode: str) -> PersonalWrite:
    return add_personal_to_node(workspace, actor, registry, f'personal:{actor.actor_id}:general',
                                title, text, mode=mode)


def add_personal_to_node(workspace: Path, actor: VerifiedActor, registry: CoreRegistry,
                         node_id: str, title: str, text: str, *, mode: str) -> PersonalWrite:
    if not title.strip() or not text.strip() or mode not in {'local', 'private'}:
        raise PersonalStoreBlocked('durable Personal title, body and storage mode required')
    root = workspace / 'domains/actor'
    if root.is_symlink() or not (root / '.git').is_dir():
        raise PersonalStoreBlocked('Actor-private backing unavailable')
    topology = read_personal_topology(workspace, actor)
    node = topology['nodes'].get(node_id)
    if node is None or node['lifecycle'] != 'ACTIVE' or node_id == f'personal:{actor.actor_id}':
        raise PersonalStoreBlocked('active Actor-owned Personal child node required')
    storage = node.get('storage_path')
    if not isinstance(storage, str) or storage.startswith(('/', '\\')) or '\\' in storage or PureWindowsPath(storage).is_absolute() or any(
            part in {'', '.', '..'} for part in storage.split('/')):
        if node_id != f'personal:{actor.actor_id}:general':
            raise PersonalStoreBlocked('Personal node storage is unsafe')
    prefix = 'General' if node_id == f'personal:{actor.actor_id}:general' else storage
    slug = re.sub(r'[^a-z0-9]+', '-', title.casefold()).strip('-')[:50] or 'personal'
    relative = f'{prefix}/{slug}-{uuid4().hex[:10]}.md'
    unit = begin_work(workspace, 'actor_knowledge')
    destination = root / relative
    if destination.is_symlink() or not destination.resolve().is_relative_to(root.resolve()):
        raise PersonalStoreBlocked('Personal destination escapes Actor backing')
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(f'# {title.strip()}\n\n{text.strip()}\n', encoding='utf-8')
    commit = close_work(workspace, unit, actor, registry, [relative],
                        f'Record private Personal context for {actor.actor_id}')
    return PersonalWrite(relative, commit, mode)
