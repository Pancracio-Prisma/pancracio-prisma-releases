"""Turn-level governed persistence of conversational durable units.

The agent proposes the semantics. This module validates the route, checks for
exactly repeated knowledge, performs bounded writes, and returns receipts.
It never stores a raw transcript or infers memory from ambient chat.
"""

from __future__ import annotations

from dataclasses import asdict
from pathlib import Path
from typing import Any

from .context_manifest14 import verify_graph_manifest
from .context_resolution14 import _tracked_clean
from .git_closure import ClosureBlocked
from .identity import VerifiedActor
from .node_store14 import NodeStore, NodeStoreBlocked
from .personal_store14 import PersonalStoreBlocked, add_personal_to_node
from .personal_topology14 import read_personal_topology
from .registry import CoreRegistry
from .routing14 import RoutingGate, RoutingProposal


class MemoryBlocked(ValueError):
    pass


def _exact_knowledge_exists(root: Path, prefix: str, title: str, text: str) -> bool:
    wanted = f"# {title.strip()}\n\n{text.strip()}"
    for path in _tracked_clean(root, prefix):
        if path.name == "Panky Context Map.md":
            continue
        content = path.read_text(encoding="utf-8", errors="replace")
        if content.startswith("---\n"):
            _, separator, content = content.partition("\n---\n\n")
            if not separator:
                continue
        if content.strip() == wanted:
            return True
    return False


def checkpoint(workspace: Path, actor: VerifiedActor, registry: CoreRegistry,
               manifest: dict[str, Any], expected_core_commit: str,
               payload: dict[str, Any]) -> dict[str, Any]:
    """Close one substantive turn with durable receipts or an explicit no-op."""
    if not isinstance(payload, dict) or set(payload) - {"units", "no_durable_reason"}:
        raise MemoryBlocked("memory checkpoint payload has unsupported fields")
    raw_units = payload.get("units")
    if not isinstance(raw_units, list) or len(raw_units) > 12:
        raise MemoryBlocked("memory checkpoint needs at most twelve proposed units")
    if not raw_units:
        reason = payload.get("no_durable_reason")
        if not isinstance(reason, str) or not reason.strip() or len(reason) > 240:
            raise MemoryBlocked("empty checkpoint needs a reason")
        return {"state": "NO_DURABLE_UNITS", "reason": reason.strip(),
                "personal": [], "organizational": [], "already_present": 0}
    if payload.get("no_durable_reason") is not None:
        raise MemoryBlocked("durable units and no-durable reason cannot be combined")

    verify_graph_manifest(manifest, actor, registry,
                          expected_core_commit=expected_core_commit)
    graph = read_personal_topology(workspace, actor)
    personal_nodes = frozenset(node_id for node_id, row in graph["nodes"].items()
                               if node_id != f"personal:{actor.actor_id}" and row["lifecycle"] == "ACTIVE")
    gate = RoutingGate(registry, personal_nodes=personal_nodes)
    planned = []
    for raw in raw_units:
        if not isinstance(raw, dict) or set(raw) - {
                "title", "text", "proposal", "audience", "state_kind", "approved_for_persistence"}:
            raise MemoryBlocked("memory unit has unsupported fields")
        title, content = raw.get("title"), raw.get("text")
        if (not isinstance(title, str) or not title.strip() or len(title) > 160
                or not isinstance(content, str) or not content.strip() or len(content) > 4000):
            raise MemoryBlocked("durable memory needs a title and concise content")
        if not isinstance(raw.get("proposal"), dict):
            raise MemoryBlocked("durable memory needs a routing proposal")
        try:
            proposal = RoutingProposal(**raw["proposal"])
        except TypeError as exc:
            raise MemoryBlocked("invalid memory routing proposal") from exc
        if not proposal.durable:
            raise MemoryBlocked("ephemeral speech belongs in no-durable reasoning")
        decision = gate.decide(actor, proposal)
        if decision.status != "PERSIST":
            raise MemoryBlocked(f"memory routing unresolved: {decision.status}: {decision.reason}")
        if proposal.crosses_personal_organization and raw.get("approved_for_persistence") is not True:
            raise MemoryBlocked("cross-boundary memory requires specific confirmation")
        if not isinstance(raw.get("approved_for_persistence", False), bool):
            raise MemoryBlocked("specific confirmation flag must be boolean")
        if proposal.owner == "personal" and decision.surface != "Knowledge":
            raise MemoryBlocked("Personal conversational memory uses Knowledge")
        if proposal.owner == "organization" and decision.surface not in {"Knowledge", "State"}:
            raise MemoryBlocked("use governed Work or Contribution commands for this surface")
        if raw.get("audience") is not None and raw["audience"] not in {"management", "delivery", "shared"}:
            raise MemoryBlocked("unknown organizational audience")
        if raw.get("state_kind", "progress") not in {"progress", "blocker", "handoff", "completed"}:
            raise MemoryBlocked("unknown State kind")
        planned.append((raw, proposal, decision))

    store = (NodeStore(workspace, actor, registry, manifest, expected_core_commit)
             if any(proposal.owner == "organization" for _, proposal, _ in planned) else None)
    personal, organizational = [], []
    already_present = 0
    seen = set()
    for raw, proposal, decision in planned:
        title, content = raw["title"].strip(), raw["text"].strip()
        key = (decision.node_id, decision.surface, title, content)
        if key in seen:
            already_present += 1
            continue
        seen.add(key)
        try:
            if proposal.owner == "personal":
                root = workspace / "domains/actor"
                if _exact_knowledge_exists(root, "*.md", title, content):
                    already_present += 1
                    continue
                receipt = add_personal_to_node(workspace, actor, registry, decision.node_id,
                                               title, content, mode=manifest["personal"]["mode"])
                personal.append(asdict(receipt))
            elif decision.surface == "Knowledge":
                assert store is not None
                _, root = store._binding_root(decision.node_id, "Knowledge", "write")
                if _exact_knowledge_exists(root, "Knowledge/*.md", title, content):
                    already_present += 1
                    continue
                receipt = store.add_knowledge(decision.node_id, title, content,
                                              source="verified conversation",
                                              audience=raw.get("audience"))
                organizational.append(asdict(receipt))
            else:
                assert store is not None
                receipt = store.add_state(decision.node_id, content,
                                          source="verified conversation",
                                          kind=raw.get("state_kind", "progress"))
                organizational.append(asdict(receipt))
        except (NodeStoreBlocked, PersonalStoreBlocked, ClosureBlocked,
                MemoryBlocked, OSError, ValueError) as exc:
            return {"state": "PARTIAL" if personal or organizational else "BLOCKED",
                    "error": str(exc), "personal": personal, "organizational": organizational,
                    "already_present": already_present}
    return {"state": "COMMITTED" if personal or organizational else "ALREADY_SAVED",
            "personal": personal, "organizational": organizational,
            "already_present": already_present}
