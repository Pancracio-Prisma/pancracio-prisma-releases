"""Google OIDC proof and fail-closed Actor resolution."""

from __future__ import annotations

from dataclasses import dataclass, field
import os
from pathlib import Path
from typing import Any

from google.auth.transport.requests import Request
from google.oauth2 import id_token
from google_auth_oauthlib.flow import InstalledAppFlow

from .registry import CoreRegistry

SCOPES = ("openid", "email", "profile")
GOOGLE_SCOPE_EQUIVALENTS = {
    "openid", "email", "profile",
    "https://www.googleapis.com/auth/userinfo.email",
    "https://www.googleapis.com/auth/userinfo.profile",
}


class IdentityError(ValueError):
    pass


@dataclass(frozen=True)
class VerifiedActor:
    actor_id: str
    role: str
    google_subject: str
    email: str


@dataclass(frozen=True)
class BootstrapAuthentication:
    """One interactive proof that also carries the sync grant until composition."""

    actor: VerifiedActor
    refresh_token: str = field(repr=False)
    id_token: str = field(repr=False)


def validate_google_id_token(token: str, client_id: str) -> dict[str, Any]:
    if not token or not client_id:
        raise IdentityError("Google ID token and client ID are required")
    try:
        # Google can issue an ID token one second ahead of this workstation's
        # clock. A bounded skew prevents valid fresh proofs from failing at
        # random without relaxing signature, issuer, or audience validation.
        claims = id_token.verify_oauth2_token(token, Request(), client_id,
                                              clock_skew_in_seconds=5)
    except Exception as exc:
        raise IdentityError("Google ID token verification failed") from exc
    if claims.get("iss") not in {"https://accounts.google.com", "accounts.google.com"}:
        raise IdentityError("invalid Google issuer")
    if claims.get("aud") != client_id:
        raise IdentityError("wrong Google audience")
    if claims.get("email_verified") is not True:
        raise IdentityError("Google email is not verified")
    if not isinstance(claims.get("sub"), str) or not claims["sub"]:
        raise IdentityError("Google subject missing")
    if not isinstance(claims.get("email"), str) or not claims["email"]:
        raise IdentityError("Google email missing")
    return claims


def resolve_actor(claims: dict[str, Any], registry: CoreRegistry) -> VerifiedActor:
    # Only a verified token's claims may be passed here. The public CLI never accepts
    # Actor, role, GitHub, gcloud, Gateway or local configuration as identity input.
    email = claims["email"]
    matches = [(actor_id, actor) for actor_id, actor in registry.actors.items()
               if actor["status"] == "active" and actor["identities"]["google_oidc"]["email"] == email]
    if len(matches) != 1:
        raise IdentityError("authenticated Google identity is not registered")
    actor_id, actor = matches[0]
    if len(actor["roles"]) != 1:
        raise IdentityError("ambiguous Actor roles")
    return VerifiedActor(actor_id, actor["roles"][0], claims["sub"], email)


def validate_issued_scopes(scope_value: str | list[str]) -> None:
    issued_scopes = set(scope_value.split() if isinstance(scope_value, str) else scope_value)
    if (not issued_scopes.issubset(GOOGLE_SCOPE_EQUIVALENTS)
            or "openid" not in issued_scopes
            or not issued_scopes.intersection({"email", "https://www.googleapis.com/auth/userinfo.email"})
            or not issued_scopes.intersection({"profile", "https://www.googleapis.com/auth/userinfo.profile"})):
        raise IdentityError("Google OAuth scopes differ from minimal approved scopes")


def load_desktop_client_config(workspace: Path) -> dict[str, Any]:
    """Use only an instance client ID and project matching its signed binding."""
    try:
        from prisma_common.oauth_profile import load_desktop_oauth
        return load_desktop_oauth(workspace)
    except (OSError, ValueError, KeyError, TypeError) as exc:
        raise IdentityError("verified instance desktop OAuth metadata is unavailable") from exc


def authenticate_desktop(registry: CoreRegistry, *, open_browser: bool = True) -> VerifiedActor:
    # OAuth tokens stay in memory. No refresh token or ID token is written by Foundation.
    try:
        flow = InstalledAppFlow.from_client_config(load_desktop_client_config(registry.root.parent.parent), scopes=list(SCOPES))
        # Google expands email/profile to their userinfo aliases in the issued
        # scope. OAuthLib treats this harmless alias expansion as a Warning.
        # Accept only the documented equivalents, then restore process state.
        previous_relax = os.environ.get("OAUTHLIB_RELAX_TOKEN_SCOPE")
        os.environ["OAUTHLIB_RELAX_TOKEN_SCOPE"] = "1"
        try:
            flow.run_local_server(host="127.0.0.1", port=0, open_browser=open_browser,
                                  access_type="online",
                                  authorization_prompt_message="" if open_browser else None)
        finally:
            if previous_relax is None:
                os.environ.pop("OAUTHLIB_RELAX_TOKEN_SCOPE", None)
            else:
                os.environ["OAUTHLIB_RELAX_TOKEN_SCOPE"] = previous_relax
        validate_issued_scopes(flow.oauth2session.token.get("scope", ""))
        token = flow.oauth2session.token["id_token"]
        client_id = flow.client_config["client_id"]
    except Exception as exc:
        raise IdentityError(f"Google desktop OAuth flow failed ({type(exc).__name__})") from exc
    return resolve_actor(validate_google_id_token(token, client_id), registry)


def authenticate_bootstrap(registry: CoreRegistry, *, open_browser: bool = True) -> BootstrapAuthentication:
    """Authenticate once and obtain the offline grant needed by Context Sync."""
    try:
        flow = InstalledAppFlow.from_client_config(load_desktop_client_config(registry.root.parent.parent), scopes=list(SCOPES))
        previous_relax = os.environ.get("OAUTHLIB_RELAX_TOKEN_SCOPE")
        os.environ["OAUTHLIB_RELAX_TOKEN_SCOPE"] = "1"
        try:
            flow.run_local_server(
                host="127.0.0.1",
                port=0,
                open_browser=open_browser,
                access_type="offline",
                prompt="consent",
                authorization_prompt_message="" if open_browser else None,
            )
        finally:
            if previous_relax is None:
                os.environ.pop("OAUTHLIB_RELAX_TOKEN_SCOPE", None)
            else:
                os.environ["OAUTHLIB_RELAX_TOKEN_SCOPE"] = previous_relax
        validate_issued_scopes(flow.oauth2session.token.get("scope", ""))
        actor = resolve_actor(
            validate_google_id_token(flow.oauth2session.token["id_token"], flow.client_config["client_id"]),
            registry,
        )
        refresh_token = flow.credentials.refresh_token
        if not refresh_token:
            raise IdentityError("Google did not issue an offline transport grant")
        return BootstrapAuthentication(actor, refresh_token, flow.oauth2session.token["id_token"])
    except Exception as exc:
        if isinstance(exc, IdentityError):
            raise
        raise IdentityError(f"Google bootstrap OAuth flow failed ({type(exc).__name__})") from exc


def authenticate_runtime(registry: CoreRegistry, workspace: Path, *, allow_stale_context: bool = False) -> VerifiedActor:
    """Refresh a real Google OIDC proof for an enrolled runtime without a browser.

    The local owner/manifest is a binding to check, never an identity source.
    Bootstrap and explicit transport enrollment remain interactive.
    """
    if not (workspace / ".panky" / "owner.yaml").is_file():
        return authenticate_desktop(registry)
    from .composition import inspect_runtime
    from .sync_transport import TransportError, _fresh_google_id_token

    if not allow_stale_context:
        inspect_runtime(workspace, probe_gateway=False)
    try:
        token = _fresh_google_id_token(workspace)
    except TransportError as exc:
        raise IdentityError(
            "enrolled Google proof is unavailable; run panky-prisma sync-enroll to renew it"
        ) from exc
    client_id = load_desktop_client_config(workspace)["installed"]["client_id"]
    trusted = CoreRegistry.load(workspace / "domains" / "core")
    return resolve_actor(validate_google_id_token(token, client_id), trusted)
