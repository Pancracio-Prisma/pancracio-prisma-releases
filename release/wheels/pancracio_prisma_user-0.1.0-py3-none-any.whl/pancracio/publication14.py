"""Deterministic parent-to-child publication under Pancracio 1.4 edge policy."""

from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
from pathlib import Path, PurePosixPath
import subprocess
import tempfile
from typing import Any

import yaml

from .classification import ClassificationError, classify_unit
from .context_topology import topology_from_core
from .materialization14 import _verify_binding
from .node_authority import NodeAuthority
from .projection import ProjectionError, _dependencies, _resolve_dependency, safe_path, SAFE_ASSETS
from .registry import CoreRegistry


class PublicationBlocked(ValueError):
    pass


@dataclass(frozen=True)
class PublicationCandidate:
    target_node_id: str
    generation: int
    files: dict[str, bytes]
    manifest: dict[str, Any]


def _git(root: Path, *args: str, binary: bool = False) -> bytes | str:
    result = subprocess.run(['git', '-C', str(root), *args], capture_output=True, timeout=45)
    if result.returncode:
        raise PublicationBlocked('Git source or backing validation failed')
    return result.stdout if binary else result.stdout.decode().strip()


def generate_publication(parent_root: Path, registry: CoreRegistry, child_node_id: str) -> PublicationCandidate:
    authority = NodeAuthority(registry)
    graph = authority.graph
    edge = registry.publication_edges['edges'].get(child_node_id) if registry.publication_edges else None
    if edge is None or 'publication' not in edge or graph.parent(child_node_id) != edge['parent_id']:
        raise PublicationBlocked('protected publication edge unavailable')
    policy = edge['publication']
    source = authority.bindings.get(policy['source_store_id'])
    target = authority.bindings.get(policy['target_store_id'])
    if (source is None or target is None or source.node_id != edge['parent_id']
            or target.node_id != child_node_id or source.mode != 'authoritative'
            or target.mode != 'generated' or target.generation != policy['generation']):
        raise PublicationBlocked('publication backing policy mismatch')
    parent_root = parent_root.resolve(strict=True)
    _verify_binding(parent_root, source)
    if _git(parent_root, 'status', '--porcelain'):
        raise PublicationBlocked('parent source has local changes')
    commit = _git(parent_root, 'rev-parse', 'HEAD')
    if commit != _git(parent_root, 'rev-parse', 'refs/remotes/origin/main'):
        raise PublicationBlocked('parent source differs from published Git authority')
    tree = _git(parent_root, 'ls-tree', '-rz', '--full-tree', commit, binary=True)
    blobs: dict[str, bytes] = {}
    seen: set[str] = set()
    for row in tree.split(b'\0'):
        if not row:
            continue
        metadata, name_bytes = row.split(b'\t', 1)
        mode, kind, oid = metadata.decode('ascii').split()
        if mode not in {'100644', '100755'} or kind != 'blob':
            raise PublicationBlocked('unsupported Git tree entry')
        name = name_bytes.decode('utf-8')
        safe_path(name)
        if name.casefold() in seen:
            raise PublicationBlocked('case-colliding path')
        seen.add(name.casefold())
        blobs[name] = _git(parent_root, 'cat-file', 'blob', oid, binary=True)
    audiences = set(policy['audiences'])
    allowed_types = set(policy['allowed_scope_types'])
    assignments = {(row['type'], row['id']) for row in policy['assignments']}
    with tempfile.TemporaryDirectory(prefix='panky-publication14-') as temp:
        root = Path(temp)
        for name, payload in blobs.items():
            path = root / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(payload)
        eligible: dict[str, bool] = {}
        for name in sorted(blobs):
            if not name.lower().endswith('.md'):
                continue
            try:
                unit = classify_unit(root / name, root)
                eligible[name] = (unit.lifecycle == 'active' and bool(unit.audience & audiences)
                                  and (unit.global_scope or bool(unit.scope & assignments))
                                  and all(kind in allowed_types for kind, _ in unit.scope))
            except ClassificationError:
                eligible[name] = False
        resolved: dict[str, set[str] | None] = {}

        def closure(name: str, stack: frozenset[str] = frozenset()) -> set[str] | None:
            if name in resolved:
                return resolved[name]
            if not eligible.get(name) or name in stack:
                return None
            try:
                text = blobs[name].decode('utf-8')
                result = {name}
                for reference, wiki in _dependencies(text):
                    dependency = _resolve_dependency(name, reference, set(blobs), wiki=wiki)
                    if dependency.endswith('.md'):
                        child = closure(dependency, stack | {name})
                        if child is None:
                            raise PublicationBlocked('forbidden dependency')
                        result.update(child)
                    elif PurePosixPath(dependency).suffix.lower() not in SAFE_ASSETS:
                        raise PublicationBlocked('unsupported attachment')
                    else:
                        # A binary attachment needs explicit audience classification;
                        # this 1.4 edge has no binary policy, so fail closed.
                        raise PublicationBlocked('binary attachment requires governed policy')
                resolved[name] = result
            except (ProjectionError, PublicationBlocked, UnicodeDecodeError, ClassificationError):
                resolved[name] = None
            return resolved[name]

        selected: set[str] = set()
        for name in sorted(eligible):
            if eligible[name]:
                selected.update(closure(name) or ())
    files = {f'published/{name}': blobs[name] for name in sorted(selected)}
    inventory = {name: hashlib.sha256(payload).hexdigest() for name, payload in files.items()}
    policy_sha = hashlib.sha256(json.dumps(edge, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
    manifest = {'schema_version': 1, 'source_node_id': edge['parent_id'],
                'target_node_id': child_node_id, 'generation': target.generation,
                'canonical_commit': commit, 'edge_policy_sha256': policy_sha, 'files': inventory}
    return PublicationCandidate(child_node_id, target.generation, files, manifest)


def publication_delta(candidate: PublicationCandidate, publication_root: Path) -> tuple[str, set[str]]:
    """Return UNCHANGED/ADDITIVE/ROTATION_REQUIRED and added filenames."""
    marker = publication_root / 'publication.yaml'
    if not marker.is_file():
        raise PublicationBlocked('publication marker missing')
    old = yaml.safe_load(marker.read_text(encoding='utf-8'))
    if old.get('target_node_id') != candidate.target_node_id or old.get('generation') != candidate.generation:
        raise PublicationBlocked('publication marker mismatch')
    previous = old.get('files', {})
    if not isinstance(previous, dict):
        raise PublicationBlocked('publication inventory invalid')
    for name, digest in previous.items():
        if candidate.manifest['files'].get(name) != digest:
            return 'ROTATION_REQUIRED', set()
    additions = set(candidate.files) - set(previous)
    if not additions and old.get('edge_policy_sha256') == candidate.manifest['edge_policy_sha256']:
        return 'UNCHANGED', set()
    return 'ADDITIVE', additions


def stage_rotated_publication(candidate: PublicationCandidate, old_root: Path,
                              new_root: Path, *, new_generation: int,
                              old_access_revoked: bool,
                              target_local_path: str) -> None:
    """Stage a clean generated backing after governed revocation.

    The caller creates a *new* private remote and changes protected Core only
    after this staged tree and its audience have been reviewed. No old Git
    object, remote, or durable child state is copied into the new generation.
    """
    if not old_access_revoked:
        raise PublicationBlocked('old publication access must be revoked before rotation')
    if not target_local_path.startswith('domains/publications/'):
        raise PublicationBlocked('rotated publication destination is invalid')
    safe_path(target_local_path)
    if new_root.exists() or new_root.is_symlink():
        raise PublicationBlocked('new publication generation requires an absent destination')
    if old_root.is_symlink():
        raise PublicationBlocked('old publication Git backing unavailable')
    old_root = old_root.resolve(strict=True)
    if not (old_root / '.git').is_dir():
        raise PublicationBlocked('old publication Git backing unavailable')
    old_marker = yaml.safe_load((old_root / 'publication.yaml').read_text(encoding='utf-8'))
    if (not isinstance(old_marker, dict)
            or old_marker.get('target_node_id') != candidate.target_node_id
            or old_marker.get('generation') != candidate.generation
            or not isinstance(new_generation, int) or isinstance(new_generation, bool)
            or new_generation <= candidate.generation):
        raise PublicationBlocked('publication generation or target mismatch')
    if _git(old_root, 'status', '--porcelain'):
        raise PublicationBlocked('old publication has local changes to preserve')
    if _git(old_root, 'rev-parse', 'HEAD') != _git(old_root, 'rev-parse', 'refs/remotes/origin/main'):
        raise PublicationBlocked('old publication differs from published Git authority')
    expected = candidate.manifest.get('files')
    if (not isinstance(expected, dict) or set(expected) != set(candidate.files)
            or any(hashlib.sha256(payload).hexdigest() != expected.get(name)
                   for name, payload in candidate.files.items())):
        raise PublicationBlocked('publication candidate inventory mismatch')
    marker = {**candidate.manifest, 'generation': new_generation}
    new_root.mkdir(parents=True)
    try:
        for name, payload in sorted(candidate.files.items()):
            try:
                path = safe_path(name)
            except ProjectionError as exc:
                raise PublicationBlocked('unsafe generated publication path') from exc
            if not name.startswith('published/'):
                raise PublicationBlocked('unsafe generated publication path')
            target = new_root.joinpath(*path.parts)
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(payload)
        (new_root / 'publication.yaml').write_text(
            yaml.safe_dump(marker, sort_keys=False, allow_unicode=True), encoding='utf-8')
        subprocess.run(['git', 'init', '-q', '-b', 'main', str(new_root)], check=True,
                       capture_output=True, timeout=45)
        from .obsidian_map import MAP_NAME, render_map
        if candidate.files:
            (new_root / MAP_NAME).write_text(
                render_map(new_root, new_root, extra=tuple(candidate.files),
                               relative_prefix=target_local_path), encoding='utf-8')
    except Exception:
        # No protected binding points here yet. Leave the staged tree for
        # inspection rather than silently removing recovery evidence.
        raise


def publish_additive(candidate: PublicationCandidate, publication_root: Path,
                     registry: CoreRegistry, actor) -> str:
    authority = NodeAuthority(registry)
    binding = authority.binding(candidate.target_node_id, 'Published')
    if not authority.decide(actor, candidate.target_node_id, 'Published', 'publish_down').allowed:
        raise PublicationBlocked('publisher authority absent')
    _verify_binding(publication_root, binding)
    if _git(publication_root, 'status', '--porcelain'):
        raise PublicationBlocked('publication backing has local changes')
    if _git(publication_root, 'rev-parse', 'HEAD') != _git(publication_root, 'rev-parse', 'refs/remotes/origin/main'):
        raise PublicationBlocked('publication backing differs from origin')
    state, added = publication_delta(candidate, publication_root)
    if state == 'ROTATION_REQUIRED':
        raise PublicationBlocked('ROTATION_REQUIRED: old Git history must be retired before changed/removed bytes')
    if state == 'UNCHANGED':
        return _git(publication_root, 'rev-parse', 'HEAD')
    for name in sorted(added):
        path = publication_root / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(candidate.files[name])
    (publication_root / 'publication.yaml').write_text(yaml.safe_dump(candidate.manifest, sort_keys=False, allow_unicode=True))
    paths = ['publication.yaml', *sorted(added)]
    from .obsidian_map import MAP_NAME, render_map
    map_path = publication_root / MAP_NAME
    if map_path.is_symlink():
        raise PublicationBlocked('Obsidian map path is unsafe')
    map_text = render_map(publication_root, publication_root, extra=tuple(added),
                          relative_prefix=binding.local_path)
    if not map_path.is_file() or map_path.read_text(encoding='utf-8') != map_text:
        map_path.write_text(map_text, encoding='utf-8')
        paths.append(MAP_NAME)
    _git(publication_root, 'add', '--', *paths)
    _git(publication_root, 'commit', '--only', '-m', f'Publish governed {candidate.target_node_id} generation {candidate.generation}', '--', *paths)
    commit = _git(publication_root, 'rev-parse', 'HEAD')
    _git(publication_root, 'push', 'origin', 'HEAD:main')
    if _git(publication_root, 'ls-remote', 'origin', 'refs/heads/main').split()[0] != commit:
        raise PublicationBlocked('publication remote readback incomplete')
    return commit
