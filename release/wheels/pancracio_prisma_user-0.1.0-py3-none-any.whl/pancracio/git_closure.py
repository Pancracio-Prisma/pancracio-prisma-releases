"""Close one bounded, verified work unit without absorbing unrelated Git work."""

from __future__ import annotations

import json
from pathlib import Path
import re
import subprocess
import uuid

from .authority import AuthorityDenied, GuardedRepository, RepositoryAuthority
from .identity import VerifiedActor
from .registry import CoreRegistry


class ClosureBlocked(ValueError):
    pass


def _git(root: Path, *args: str, check: bool = True) -> subprocess.CompletedProcess[bytes]:
    result = subprocess.run(["git", "-C", str(root), *args], capture_output=True)
    if check and result.returncode:
        raise ClosureBlocked("Git operation failed; local work preserved")
    return result


def _dirty_paths(root: Path) -> set[str]:
    data = _git(root, "status", "--porcelain=v1", "-z", "--untracked-files=all").stdout
    parts = data.decode("utf-8", "surrogateescape").split("\0")
    dirty: set[str] = set()
    index = 0
    while index < len(parts) and parts[index]:
        entry = parts[index]
        dirty.add(entry[3:])
        if entry[:2] in {"R ", "C ", " R", " C"}:
            index += 1
            if index < len(parts):
                dirty.add(parts[index])
        index += 1
    return dirty


def _repository(workspace: Path, repo_type: str) -> Path:
    roots = {
        "workspace": workspace,
        "core": workspace / "domains" / "core",
        "organization_canonical": workspace / "domains" / "organization",
        "actor_knowledge": workspace / "domains" / "actor",
    }
    if repo_type not in roots:
        raise ClosureBlocked("unknown repository type")
    return roots[repo_type]


def begin(workspace: Path, repo_type: str, *, fixture: bool = False) -> str:
    """Record preexisting dirt before the agent edits a governed repository."""
    workspace = workspace.resolve()
    root = _repository(workspace, repo_type)
    if not fixture:
        from .composition import inspect_runtime
        view = inspect_runtime(workspace, probe_gateway=False)
        if repo_type == "organization_canonical" and "organization_canonical" not in view.get("materialized_bindings", {}):
            raise ClosureBlocked("canonical organization backing is not materialized")
    marker = root / ("panky.yaml" if repo_type == "workspace" else "repo.yaml")
    # Older local Actor Knowledge templates have no marker. Allow a work unit
    # to begin so the marker can be added inside the guarded commit itself.
    marker_missing_for_actor = repo_type == "actor_knowledge" and not marker.exists()
    if ((not marker.is_file() and not marker_missing_for_actor) or
            Path(_git(root, "rev-parse", "--show-toplevel").stdout.decode().strip()).resolve() != root.resolve()):
        raise ClosureBlocked("repository root or marker is invalid")
    head = _git(root, "rev-parse", "HEAD").stdout.decode().strip()
    remote = _git(root, "remote", "get-url", "origin", check=False).returncode == 0
    if not remote and repo_type != "actor_knowledge":
        raise ClosureBlocked("governed versioned repository has no authoritative remote")
    unit_id = uuid.uuid4().hex
    state = {"repository": repo_type, "head": head, "preexisting_dirty": sorted(_dirty_paths(root)), "remote": remote}
    directory = workspace / ".panky" / "work-units"
    directory.mkdir(parents=True, exist_ok=True)
    destination = directory / f"{unit_id}.json"
    destination.write_text(json.dumps(state, sort_keys=True), encoding="utf-8")
    destination.chmod(0o600)
    return unit_id


def close(workspace: Path, unit_id: str, actor: VerifiedActor, registry: CoreRegistry,
          paths: list[str], message: str, *, fixture: bool = False) -> str:
    """Commit only declared, previously clean paths; push when remote-backed."""
    workspace = workspace.resolve()
    if not re.fullmatch(r"[a-f0-9]{32}", unit_id):
        raise ClosureBlocked("invalid work unit ID")
    record = workspace / ".panky" / "work-units" / f"{unit_id}.json"
    try:
        state = json.loads(record.read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        raise ClosureBlocked("work unit baseline is unavailable") from exc
    if not paths or not message.strip() or len(set(paths)) != len(paths):
        raise ClosureBlocked("explicit unique paths and commit message required")
    repo_type = state["repository"]
    root = _repository(workspace, repo_type)
    authority = RepositoryAuthority(registry)
    guard = GuardedRepository(root, authority, fixture=fixture or repo_type == "actor_knowledge")
    if guard.repo_type != repo_type:
        raise ClosureBlocked("repository type changed during work unit")
    if _git(root, "rev-parse", "HEAD").stdout.decode().strip() != state["head"]:
        raise ClosureBlocked("repository HEAD changed during work unit")
    before = set(state["preexisting_dirty"])
    dirty = _dirty_paths(root)
    for path in paths:
        if path in before or path not in dirty:
            raise ClosureBlocked("declared path was preexisting dirty or has no pending change")
        target = root / path
        if not target.is_file() or target.is_symlink() or not target.resolve().is_relative_to(root):
            raise ClosureBlocked("declared path is not a regular file inside repository")
        for operation in ("write", "commit"):
            authority.require(actor, repo_type, operation, path=path,
                              target_actor_id=actor.actor_id)
    if not fixture:
        from .composition import inspect_runtime
        view = inspect_runtime(workspace, probe_gateway=False)
        if view["actor_id"] != actor.actor_id or view["role"] != actor.role:
            raise ClosureBlocked("verified Actor does not own this runtime")
    remote = bool(state["remote"])
    if remote:
        for path in paths:
            authority.require(actor, repo_type, "push", path=path,
                              target_actor_id=actor.actor_id)
        _git(root, "fetch", "origin", "main")
        remote_head = _git(root, "rev-parse", "refs/remotes/origin/main").stdout.decode().strip()
        if remote_head != state["head"]:
            raise ClosureBlocked("authoritative remote advanced; work preserved for reconciliation")
    if repo_type in {"organization_canonical", "actor_knowledge"} and any(path.endswith(".md") for path in paths):
        from .obsidian_map import MAP_NAME, render_map
        map_path = root / MAP_NAME
        if map_path.is_symlink() or MAP_NAME in before:
            raise ClosureBlocked("Obsidian map has preexisting local work")
        map_text = render_map(workspace, root,
                              extra=tuple(path for path in paths if path.endswith(".md")),
                              scope="personal" if repo_type == "actor_knowledge" else "organizational")
        if not map_path.is_file() or map_path.read_text(encoding="utf-8") != map_text:
            map_path.write_text(map_text, encoding="utf-8")
            if MAP_NAME not in paths:
                paths = [*paths, MAP_NAME]
            for operation in (("write", "commit", "push") if remote else ("write", "commit")):
                authority.require(actor, repo_type, operation, path=MAP_NAME,
                                  target_actor_id=actor.actor_id)
    # --only limits the commit to this work unit even when another path was
    # already staged. The index/working tree for unrelated paths is preserved.
    _git(root, "add", "--", *paths)
    for path in paths:
        guard._check_git_entry(path, staged=True)
    _git(root, "commit", "--only", "-m", message, "--", *paths)
    commit = _git(root, "rev-parse", "HEAD").stdout.decode().strip()
    if remote:
        result = _git(root, "push", "origin", "HEAD:main", check=False)
        if result.returncode:
            raise ClosureBlocked(f"local commit {commit} preserved; push needs reconciliation")
        published = _git(root, "ls-remote", "origin", "refs/heads/main").stdout.decode().split()[0]
        if published != commit:
            raise ClosureBlocked(f"local commit {commit} preserved; remote readback inconclusive")
    record.unlink()
    return commit if remote else f"LOCAL_ONLY {commit}"
