"""Bounded Pancracio 1.4 node writes with automatic Git closure."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
import json
import os
import re
import subprocess
import tempfile
from uuid import uuid4

import yaml

from .context_manifest14 import verify_graph_manifest
from .identity import VerifiedActor
from .materialization14 import _verify_binding, _local
from .node_authority import NodeAuthority
from .registry import CoreRegistry


class NodeStoreBlocked(ValueError):
    pass


@dataclass(frozen=True)
class WriteResult:
    node_id: str
    surface: str
    store_id: str
    path: str
    commit: str


def _git(root: Path, *args: str, check: bool = True) -> str:
    result = subprocess.run(["git", "-C", str(root), *args], capture_output=True, text=True, timeout=45)
    if check and result.returncode:
        raise NodeStoreBlocked("Git operation failed; local work preserved")
    return result.stdout.rstrip("\n")


def _stamp() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")


def _title_slug(title: str) -> str:
    slug = re.sub(r"[^a-z0-9]+", "-", title.casefold()).strip("-")[:50]
    return slug or "context"


class NodeStore:
    def __init__(self, workspace: Path, actor: VerifiedActor, registry: CoreRegistry,
                 manifest: dict, expected_core_commit: str):
        mode_path = workspace / ".panky/gateway-auth-mode"
        if mode_path.is_symlink():
            raise NodeStoreBlocked("Gateway authentication mode path is unsafe")
        self.oidc_mode = mode_path.is_file() and mode_path.read_text(encoding="utf-8").strip() == "oidc"
        if self.oidc_mode:
            from .context_catalog20 import fetch_catalog, verify_catalog_manifest
            verify_catalog_manifest(manifest, fetch_catalog(workspace / ".panky"), actor, registry,
                                    expected_core_commit=expected_core_commit)
        else:
            verify_graph_manifest(manifest, actor, registry, expected_core_commit=expected_core_commit)
        self.workspace = workspace.resolve(strict=True)
        self.actor = actor
        self.authority = NodeAuthority(registry)
        self.registry = registry
        self.manifest = manifest
        self.core_commit = expected_core_commit

    def _context_operation(self, surface: str, operation: str) -> tuple[str, str]:
        mapped = {"Knowledge": "update", "State": "update", "Work": "update",
                  "Contributions": "create", "Published": "create"}
        if operation == "read":
            return surface.casefold(), "read"
        if operation == "update_work":
            return "work", "update"
        if operation == "write" and surface == "Work":
            return "work", "assign"
        return surface.casefold(), mapped[surface]

    def _policy(self, node_id: str, surface: str, operation: str, *, preview: bool) -> dict:
        from .context_catalog20 import ContextCatalogError, context_decision
        policy_surface, policy_operation = self._context_operation(surface, operation)
        try:
            result = context_decision(self.workspace / ".panky", node_id=node_id,
                                      surface=policy_surface, operation=policy_operation,
                                      preview=preview)
        except ContextCatalogError as exc:
            raise NodeStoreBlocked(str(exc)) from exc
        if result.get("release") != self.core_commit and result.get("reservation_id"):
            from .context_catalog20 import complete_context_use
            complete_context_use(self.workspace / ".panky", reservation_id=result["reservation_id"],
                                 request_id=result["request_id"], status="released")
        if not result["allowed"] or result.get("release") != self.core_commit:
            raise NodeStoreBlocked("Current Gateway policy denies this context action")
        return result

    def _binding_root(self, node_id: str, surface: str, operation: str):
        if self.oidc_mode:
            binding = self.authority.binding(node_id, surface)
            if binding.mode != "authoritative":
                raise NodeStoreBlocked("Generated context cannot receive organizational writes")
        else:
            decision = self.authority.decide(self.actor, node_id, surface, operation)
            if not decision.allowed or decision.binding is None:
                raise NodeStoreBlocked(decision.reason)
            binding = decision.binding
        mounted = self.manifest["materialized_bindings"].get(binding.store_id)
        if mounted is None or mounted["node_id"] != node_id:
            raise NodeStoreBlocked("NODE_NOT_MATERIALIZED")
        root = _local(self.workspace, binding.local_path)
        _verify_binding(root, binding)
        if self.oidc_mode:
            self._policy(node_id, surface, operation, preview=True)
        return binding, root

    def _publish(self, binding, root: Path, relative: str, payload: bytes,
                 *, operation: str, message: str) -> WriteResult:
        if (not self.oidc_mode and
                not self.authority.decide_path(self.actor, binding.store_id, relative, operation).allowed):
            raise NodeStoreBlocked("node path/surface authority denied")
        target = root / relative
        if target.is_symlink() or not target.resolve().is_relative_to(root.resolve()):
            raise NodeStoreBlocked("node path escapes backing")
        _git(root, "fetch", "origin", "main")
        head = _git(root, "rev-parse", "HEAD")
        remote = _git(root, "rev-parse", "refs/remotes/origin/main")
        dirty = _git(root, "status", "--porcelain=v1", "-z", "--untracked-files=all")
        dirty_paths = {part[3:] for part in dirty.split("\0") if part}
        if relative in dirty_paths:
            raise NodeStoreBlocked("target has preexisting local work")
        from .obsidian_map import MAP_NAME, render_map
        if relative.endswith(".md") and MAP_NAME in dirty_paths:
            raise NodeStoreBlocked("Obsidian map has preexisting local work")
        if head != remote:
            if dirty_paths:
                raise NodeStoreBlocked("remote advanced with local work; preserve and reconcile")
            _git(root, "merge", "--ff-only", "origin/main")
            head = _git(root, "rev-parse", "HEAD")
        authorization = (self._policy(binding.node_id, relative.split("/", 1)[0], operation,
                                      preview=False) if self.oidc_mode else None)
        reservation_id = authorization.get("reservation_id") if authorization else None
        state = {"push_attempted": False}
        try:
            map_text = (render_map(self.workspace, root, extra=(relative,))
                        if relative.endswith(".md") else None)
            result = self._commit_and_push(binding, root, relative, payload, message, state,
                                           map_text=map_text)
        except Exception:
            if reservation_id:
                from .context_catalog20 import complete_context_use
                try:
                    complete_context_use(self.workspace / ".panky", reservation_id=reservation_id,
                                         request_id=authorization["request_id"],
                                         status="uncertain" if state["push_attempted"] else "released")
                except Exception:
                    pass
            raise
        if reservation_id:
            from .context_catalog20 import ContextCatalogError, complete_context_use
            try:
                complete_context_use(self.workspace / ".panky", reservation_id=reservation_id,
                                     request_id=authorization["request_id"], status="committed")
            except ContextCatalogError as exc:
                raise NodeStoreBlocked("Git was published, but limited-use policy completion needs reconciliation") from exc
        return result

    def _commit_and_push(self, binding, root: Path, relative: str, payload: bytes,
                         message: str, state: dict, *, map_text: str | None = None) -> WriteResult:
        target = root / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        with tempfile.NamedTemporaryFile("wb", dir=target.parent, prefix=".panky-node-", delete=False) as handle:
            temp = Path(handle.name)
            handle.write(payload)
        try:
            os.replace(temp, target)
        finally:
            temp.unlink(missing_ok=True)
        paths = [relative]
        if map_text is not None:
            from .obsidian_map import MAP_NAME
            map_path = root / MAP_NAME
            if map_path.is_symlink():
                raise NodeStoreBlocked("Obsidian map path is unsafe")
            if not map_path.is_file() or map_path.read_text(encoding="utf-8") != map_text:
                map_path.write_text(map_text, encoding="utf-8")
                paths.append(MAP_NAME)
        _git(root, "add", "--", *paths)
        if len(paths) > 1 and not _git(root, "ls-files", "--stage", "--", MAP_NAME).startswith("100644 "):
            raise NodeStoreBlocked("Obsidian map Git entry is not a regular file")
        stage = _git(root, "ls-files", "--stage", "--", relative)
        if not stage.startswith("100644 "):
            raise NodeStoreBlocked("node Git entry is not a regular file")
        _git(root, "commit", "--only", "-m", message, "--", *paths)
        commit = _git(root, "rev-parse", "HEAD")
        state["push_attempted"] = True
        _git(root, "push", "origin", "HEAD:main")
        published = _git(root, "ls-remote", "origin", "refs/heads/main").split()
        if not published or published[0] != commit:
            raise NodeStoreBlocked(f"local commit {commit} preserved; remote readback incomplete")
        return WriteResult(binding.node_id, relative.split("/", 1)[0], binding.store_id, relative, commit)

    def add_knowledge(self, node_id: str, title: str, text: str, *, source: str = "verified conversation",
                      audience: str | None = None) -> WriteResult:
        if audience is None:
            audience = "delivery" if self.authority.graph.parent(node_id) is not None else "management"
        if not title.strip() or not text.strip() or audience not in {"management", "delivery", "shared"}:
            raise NodeStoreBlocked("Knowledge title, body and governed audience required")
        if self.authority.graph.parent(node_id) is not None and audience == "management":
            raise NodeStoreBlocked("management-only content cannot enter a child backing shared with its worker")
        binding, root = self._binding_root(node_id, "Knowledge", "write")
        name = f"Knowledge/{_title_slug(title)}-{uuid4().hex[:10]}.md"
        # Frontmatter carries classification needed for deterministic publication.
        front = yaml.safe_dump({"audience": [audience], "scope": {"global": True},
                                "lifecycle": "active", "title": title.strip(),
                                "node_id": node_id, "source_actor_id": self.actor.actor_id,
                                "recorded_at": _stamp(), "source": source},
                               sort_keys=False, allow_unicode=True).strip()
        body = f"---\n{front}\n---\n\n# {title.strip()}\n\n{text.strip()}\n"
        return self._publish(binding, root, name, body.encode(), operation="write",
                             message=f"Record {node_id} contextual knowledge")

    def add_state(self, node_id: str, summary: str, *, source: str = "verified conversation",
                  kind: str = "progress") -> WriteResult:
        if not summary.strip():
            raise NodeStoreBlocked("State update required")
        if kind not in {"progress", "blocker", "handoff", "completed"}:
            raise NodeStoreBlocked("unsupported State kind")
        binding, root = self._binding_root(node_id, "State", "write")
        name = f"State/updates/{uuid4().hex}.yaml"
        payload = {"schema_version": 1, "state_id": Path(name).stem, "node_id": node_id,
                   "recorded_at": _stamp(), "source_actor_id": self.actor.actor_id,
                   "source": source, "kind": kind, "summary": summary.strip()}
        return self._publish(binding, root, name, yaml.safe_dump(payload, sort_keys=False, allow_unicode=True).encode(),
                             operation="write", message=f"Update {node_id} work state")

    def assign_work(self, node_id: str, title: str, *, assignee_seat: str | None = None,
                    due: str | None = None, priority: str | None = None,
                    context: str | None = None) -> WriteResult:
        if not title.strip():
            raise NodeStoreBlocked("Work Item title required")
        binding, root = self._binding_root(node_id, "Work", "write")
        if (not self.oidc_mode and
                not self.authority.graph.decide_actor(self.actor, self.registry, node_id, "assign_work").allowed):
            raise NodeStoreBlocked("assign_work capability required")
        if assignee_seat is not None and assignee_seat not in self.registry.seats:
            raise NodeStoreBlocked("unknown assigned Seat")
        item_id = f"work_{uuid4().hex}"
        payload = {"schema_version": 1, "work_item_id": item_id, "owning_node_id": node_id,
                   "created_by_actor_id": self.actor.actor_id, "assigned_seat_id": assignee_seat,
                   "status": "OPEN", "title": title.strip(), "created_at": _stamp(),
                   "due": due, "priority": priority, "context": context}
        return self._publish(binding, root, f"Work/{item_id}.yaml",
                             yaml.safe_dump(payload, sort_keys=False, allow_unicode=True).encode(),
                             operation="write", message=f"Assign {node_id} work item {item_id}")

    def update_work(self, node_id: str, work_item_id: str, status: str,
                    *, outcome: str | None = None) -> WriteResult:
        if not re.fullmatch(r"work_[a-f0-9]{32}", work_item_id) or status not in {"OPEN", "IN_PROGRESS", "BLOCKED", "DONE"}:
            raise NodeStoreBlocked("invalid Work Item or status")
        operation = "update_work" if self.oidc_mode else "write"
        binding, root = self._binding_root(node_id, "Work", operation)
        if (not self.oidc_mode and
                not self.authority.graph.decide_actor(self.actor, self.registry, node_id, "update_work").allowed):
            raise NodeStoreBlocked("update_work capability required")
        relative = f"Work/{work_item_id}.yaml"
        path = root / relative
        if path.is_symlink() or not path.is_file():
            raise NodeStoreBlocked("Work Item unavailable")
        item = yaml.safe_load(path.read_text(encoding="utf-8"))
        if not isinstance(item, dict) or item.get("work_item_id") != work_item_id or item.get("owning_node_id") != node_id:
            raise NodeStoreBlocked("Work Item ownership mismatch")
        item["status"] = status
        item["updated_at"] = _stamp()
        item["updated_by_actor_id"] = self.actor.actor_id
        if outcome is not None:
            item["outcome"] = outcome.strip()
        return self._publish(binding, root, relative,
                             yaml.safe_dump(item, sort_keys=False, allow_unicode=True).encode(),
                             operation=operation, message=f"Update {work_item_id} status")

    def propose_contribution(self, node_id: str, observation: str, evidence: str,
                             proposed_parent_effect: str) -> WriteResult:
        if not all(x.strip() for x in (observation, evidence, proposed_parent_effect)):
            raise NodeStoreBlocked("Contribution evidence and proposed effect required")
        parent = self.authority.graph.parent(node_id)
        if parent is None:
            raise NodeStoreBlocked("root has no upward reconciliation edge")
        binding, root = self._binding_root(node_id, "Contributions", "write")
        item_id = f"ctr_{uuid4().hex}"
        payload = {"schema_version": 1, "contribution_id": item_id,
                   "source_node_id": node_id, "target_node_id": parent,
                   "originating_actor_id": self.actor.actor_id, "status": "proposed",
                   "created_at": _stamp(), "observation": observation.strip(),
                   "evidence": evidence.strip(), "proposed_parent_effect": proposed_parent_effect.strip()}
        return self._publish(binding, root, f"Contributions/{item_id}.yaml",
                             yaml.safe_dump(payload, sort_keys=False, allow_unicode=True).encode(),
                             operation="write", message=f"Propose {node_id} contribution {item_id}")

    def reconcile_contribution(self, child_node_id: str, contribution_id: str,
                               *, verified_text: str, verified_evidence: str,
                               audience: str = "management") -> tuple[WriteResult, WriteResult]:
        """Promote one child proposal into its direct parent, then record feedback."""
        if not re.fullmatch(r"ctr_[a-f0-9]{32}", contribution_id):
            raise NodeStoreBlocked("invalid Contribution ID")
        if not verified_text.strip() or not verified_evidence.strip():
            raise NodeStoreBlocked("verified parent text and evidence required")
        if audience not in {"management", "delivery", "shared"}:
            raise NodeStoreBlocked("governed publication audience required")
        child_binding, child_root = self._binding_root(child_node_id, "Contributions", "reconcile_up")
        path = child_root / "Contributions" / f"{contribution_id}.yaml"
        if path.is_symlink() or not path.is_file():
            raise NodeStoreBlocked("Contribution source unavailable")
        _git(child_root, "fetch", "origin", "main")
        if (_git(child_root, "rev-parse", "HEAD") != _git(child_root, "rev-parse", "refs/remotes/origin/main")
                or _git(child_root, "status", "--porcelain=v1", "--", path.relative_to(child_root).as_posix())):
            raise NodeStoreBlocked("Contribution is not the current published source")
        proposal = yaml.safe_load(path.read_text(encoding="utf-8"))
        parent = self.authority.graph.parent(child_node_id)
        if (not isinstance(proposal, dict) or proposal.get("status") != "proposed"
                or proposal.get("contribution_id") != contribution_id
                or proposal.get("source_node_id") != child_node_id
                or proposal.get("target_node_id") != parent
                or not proposal.get("evidence")):
            raise NodeStoreBlocked("Contribution does not match pending protected edge")
        if parent is None:
            raise NodeStoreBlocked("root has no parent")
        parent_binding, parent_root = self._binding_root(parent, "Knowledge", "write")
        canonical_path = f"Knowledge/Reconciled/{contribution_id}.md"
        existing = parent_root / canonical_path
        if existing.exists():
            front = existing.read_text(encoding="utf-8")
            if f"contribution_id: {contribution_id}" not in front:
                raise NodeStoreBlocked("canonical reconciliation target conflicts")
            _git(parent_root, "fetch", "origin", "main")
            if (_git(parent_root, "rev-parse", "HEAD") != _git(parent_root, "rev-parse", "refs/remotes/origin/main")
                    or _git(parent_root, "status", "--porcelain=v1", "--", canonical_path)):
                raise NodeStoreBlocked("canonical reconciliation target is not current published state")
            canonical_commit = _git(parent_root, "log", "-1", "--format=%H", "--", canonical_path)
            parent_result = WriteResult(parent, "Knowledge", parent_binding.store_id, canonical_path, canonical_commit)
        else:
            metadata = {"audience": [audience], "scope": {"global": True},
                        "lifecycle": "active", "title": f"Reconciled {contribution_id}",
                        "node_id": parent, "contribution_id": contribution_id,
                        "source_node_id": child_node_id, "reconciled_by_actor_id": self.actor.actor_id,
                        "recorded_at": _stamp()}
            front = yaml.safe_dump(metadata, sort_keys=False, allow_unicode=True).strip()
            body = f"---\n{front}\n---\n\n# Reconciled {contribution_id}\n\n{verified_text.strip()}\n"
            parent_result = self._publish(parent_binding, parent_root, canonical_path, body.encode(),
                                          operation="write", message=f"Reconcile {contribution_id} into {parent}")
        proposal["status"] = "reconciled"
        proposal["reconciled_by_actor_id"] = self.actor.actor_id
        proposal["reconciled_at"] = _stamp()
        proposal["canonical_commit"] = parent_result.commit
        proposal["canonical_path"] = canonical_path
        proposal["feedback"] = verified_evidence.strip()
        child_result = self._publish(child_binding, child_root,
                                     f"Contributions/{contribution_id}.yaml",
                                     yaml.safe_dump(proposal, sort_keys=False, allow_unicode=True).encode(),
                                     operation="reconcile_up",
                                     message=f"Record reconciliation of {contribution_id}")
        return parent_result, child_result
