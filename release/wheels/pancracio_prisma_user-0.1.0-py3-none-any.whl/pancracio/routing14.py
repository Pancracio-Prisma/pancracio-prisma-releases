"""Deterministic durability/authority gate for conversational routing proposals.

The conversational model proposes semantic owner, node and surface. This gate
never grants a node or treats a model classification as identity/policy.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

from .identity import VerifiedActor
from .node_authority import NodeAuthority
from .registry import CoreRegistry


@dataclass(frozen=True)
class RoutingProposal:
    durable: bool
    owner: Literal['personal', 'organization'] | None
    node_id: str | None
    surface: Literal['Knowledge', 'State', 'Work', 'Contributions'] | None
    explicit_user_destination: bool = False
    crosses_personal_organization: bool = False
    assignment_intent: bool = False
    privacy_ambiguous: bool = False


@dataclass(frozen=True)
class RoutingDecision:
    status: Literal['EPHEMERAL', 'PERSIST', 'CLARIFY', 'DENY', 'RECONCILIATION_REQUIRED']
    reason: str
    node_id: str | None = None
    surface: str | None = None


class RoutingGate:
    def __init__(self, registry: CoreRegistry, *, personal_nodes: frozenset[str] = frozenset()):
        self.registry = registry
        self.authority = NodeAuthority(registry)
        self.personal_nodes = personal_nodes

    def decide(self, actor: VerifiedActor, proposal: RoutingProposal) -> RoutingDecision:
        if (not isinstance(proposal.durable, bool)
                or any(not isinstance(value, bool) for value in (
                    proposal.explicit_user_destination, proposal.crosses_personal_organization,
                    proposal.assignment_intent, proposal.privacy_ambiguous))):
            return RoutingDecision('DENY', 'routing proposal has invalid boolean semantics')
        if not proposal.durable:
            return RoutingDecision('EPHEMERAL', 'no durable significance')
        if proposal.owner not in {'personal', 'organization'} or proposal.surface is None:
            return RoutingDecision('CLARIFY', 'semantic owner or surface unresolved')
        if proposal.node_id is not None and not isinstance(proposal.node_id, str):
            return RoutingDecision('DENY', 'node reference must be a stable ID')
        if proposal.surface not in {'Knowledge', 'State', 'Work', 'Contributions'}:
            return RoutingDecision('DENY', 'unknown durable surface')
        if proposal.privacy_ambiguous or (proposal.crosses_personal_organization
                                         and not proposal.explicit_user_destination):
            return RoutingDecision('CLARIFY', 'Personal/organizational reader boundary needs clarification')
        if proposal.owner == 'personal':
            target = proposal.node_id or f'personal:{actor.actor_id}:general'
            allowed = self.personal_nodes or frozenset({f'personal:{actor.actor_id}:general'})
            if target not in allowed or not target.startswith(f'personal:{actor.actor_id}:'):
                return RoutingDecision('DENY', 'Personal target belongs to another Actor or is unresolved')
            if proposal.surface in {'Work', 'Contributions'}:
                return RoutingDecision('DENY', 'organizational surface cannot receive Personal content')
            return RoutingDecision('PERSIST', 'Actor-owned Personal node',
                                   target, proposal.surface)
        if proposal.node_id is None:
            return RoutingDecision('CLARIFY', 'organizational node unresolved')
        if proposal.surface == 'Work' and not proposal.assignment_intent:
            return RoutingDecision('CLARIFY', 'Work Item needs assignment intent')
        if proposal.surface == 'Work' and not self.authority.graph.decide_actor(
                actor, self.registry, proposal.node_id, 'assign_work').allowed:
            return RoutingDecision('DENY', 'assign_work capability required')
        decision = self.authority.decide(actor, proposal.node_id, proposal.surface, 'write')
        if decision.allowed:
            return RoutingDecision('PERSIST', 'authorized organizational surface',
                                   proposal.node_id, proposal.surface)
        # An explicit request for a parent canonical write cannot bypass a
        # worker's child scope. A proposed contribution is the governed route.
        if proposal.explicit_user_destination and proposal.surface == 'Knowledge':
            graph = self.authority.graph
            try:
                authorized_children = [node for node in graph.natural_scope_actor(actor, self.registry)
                                       if proposal.node_id in graph.ancestors(node)
                                       and self.authority.decide(actor, node, 'Contributions', 'write').allowed]
            except Exception:
                authorized_children = []
            if len(authorized_children) == 1:
                return RoutingDecision('RECONCILIATION_REQUIRED',
                                       'target parent write denied; child Contribution is authorized',
                                       authorized_children[0], 'Contributions')
        return RoutingDecision('DENY', decision.reason)
