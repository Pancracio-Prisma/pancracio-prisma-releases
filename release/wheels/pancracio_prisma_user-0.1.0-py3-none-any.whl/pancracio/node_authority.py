"""Pancracio 1.4 node/surface/backing authority over protected Core topology."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import PurePosixPath, PureWindowsPath
from typing import Literal

from .context_topology import TopologyError, topology_from_core
from .authority import _forbidden_versioned_path
from .identity import VerifiedActor
from .registry import CoreRegistry

Surface = Literal["Knowledge", "State", "Work", "Contributions", "Published"]
Operation = Literal["read", "materialize", "write", "reconcile_up", "publish_down"]


@dataclass(frozen=True)
class Binding:
    node_id: str
    store_id: str
    repository: str
    generation: int
    mode: str
    surfaces: frozenset[str]
    local_path: str


@dataclass(frozen=True)
class NodeDecision:
    allowed: bool
    reason: str
    binding: Binding | None = None


class NodeAuthority:
    def __init__(self, registry: CoreRegistry):
        self.registry = registry
        self.graph = topology_from_core(registry)
        if registry.publication_edges is None:
            raise TopologyError("protected publication policy unavailable")
        self.bindings: dict[str, Binding] = {}
        self.by_surface: dict[tuple[str, str], Binding] = {}
        policy = registry.topology_policy
        assert policy is not None
        for node_id, row in policy["nodes"].items():
            for item in row["backing_bindings"]:
                binding = Binding(node_id, item["store_id"], item["repository"], item["generation"],
                                  item["mode"], frozenset(item["surfaces"]), item["local_path"])
                if binding.store_id in self.bindings:
                    raise TopologyError("duplicate protected store ID")
                self.bindings[binding.store_id] = binding
                for surface in binding.surfaces:
                    key = (node_id, surface)
                    if key in self.by_surface:
                        raise TopologyError("ambiguous node surface binding")
                    self.by_surface[key] = binding
        # A Git clone exposes the complete repository history. A single repo
        # cannot back nodes with different scope, even if their working-tree
        # folders would be distinct. Nested mount paths are likewise unsafe.
        repository_nodes: dict[str, str] = {}
        paths: list[PurePosixPath] = []
        reserved = (PurePosixPath("domains/core"), PurePosixPath("domains/actor"))
        for binding in self.bindings.values():
            other_node = repository_nodes.setdefault(binding.repository, binding.node_id)
            if other_node != binding.node_id:
                raise TopologyError("backing repository crosses Context Node scope")
            path = PurePosixPath(binding.local_path)
            if any(path == protected or path.is_relative_to(protected) or protected.is_relative_to(path)
                   for protected in reserved):
                raise TopologyError("backing path overlaps Core or Personal")
            if any(path == previous or path.is_relative_to(previous) or previous.is_relative_to(path)
                   for previous in paths):
                raise TopologyError("backing paths overlap")
            paths.append(path)

    def binding(self, node_id: str, surface: str) -> Binding:
        try:
            return self.by_surface[node_id, surface]
        except KeyError as exc:
            raise TopologyError("node surface has no protected backing") from exc

    def decide(self, actor: VerifiedActor, node_id: str, surface: str, operation: Operation,
               *, generation: int | None = None, store_id: str | None = None) -> NodeDecision:
        if surface not in {"Knowledge", "State", "Work", "Contributions", "Published"}:
            return NodeDecision(False, "unknown surface")
        try:
            binding = self.binding(node_id, surface)
        except TopologyError as exc:
            return NodeDecision(False, str(exc))
        if generation is not None and generation != binding.generation:
            return NodeDecision(False, "backing generation mismatch")
        if store_id is not None and store_id != binding.store_id:
            return NodeDecision(False, "backing store mismatch")
        if operation in {"read", "materialize"}:
            # Physical materialization is the transport required to exercise
            # an already granted read. A target-only read cross-grant must
            # not need a second, broader scope grant just to obtain bytes.
            capability = "read"
        elif operation == "write":
            capability = {"Knowledge": "write_knowledge", "State": "write_state",
                          "Work": "assign_work", "Contributions": "contribute",
                          "Published": "publish_down"}[surface]
            if binding.mode == "generated" and surface != "Published":
                return NodeDecision(False, "generated backing cannot receive authoritative writes")
            if binding.mode == "authoritative" and surface == "Published":
                return NodeDecision(False, "authoritative backing cannot receive generated publication")
        elif operation in {"reconcile_up", "publish_down"}:
            capability = operation
        else:
            return NodeDecision(False, "unknown operation")
        decision = self.graph.decide_actor(actor, self.registry, node_id, capability)
        if not decision.allowed and surface == "Work" and operation == "write":
            decision = self.graph.decide_actor(actor, self.registry, node_id, "update_work")
        if not decision.allowed:
            return NodeDecision(False, decision.reason)
        if operation == "reconcile_up":
            parent_id = self.graph.parent(node_id)
            edge = self.registry.publication_edges["edges"].get(node_id)
            if (parent_id is None or edge is None or "reconciliation" not in edge
                    or edge["parent_id"] != parent_id):
                return NodeDecision(False, "reconciliation edge unavailable")
            parent_decision = self.graph.decide_actor(actor, self.registry, parent_id, "reconcile_up")
            if not parent_decision.allowed:
                return NodeDecision(False, "parent reconciliation authority absent")
        if operation == "publish_down":
            edge = self.registry.publication_edges["edges"].get(node_id)
            if edge is None or "publication" not in edge or edge["publication"]["target_store_id"] != binding.store_id:
                return NodeDecision(False, "publication edge unavailable")
            parent_decision = self.graph.decide_actor(actor, self.registry, edge["parent_id"], "publish_down")
            if not parent_decision.allowed:
                return NodeDecision(False, "parent publication authority absent")
        return NodeDecision(True, "authorized", binding)

    def decide_path(self, actor: VerifiedActor, store_id: str, relative_path: str, operation: Operation) -> NodeDecision:
        binding = self.bindings.get(store_id)
        if binding is None:
            return NodeDecision(False, "unknown backing")
        if (not relative_path or relative_path.startswith(("/", "\\")) or PureWindowsPath(relative_path).is_absolute()
                or "\\" in relative_path or "%" in relative_path
                or any(part in {"", ".", ".."} for part in relative_path.split("/"))
                or _forbidden_versioned_path("graph_node", relative_path)):
            return NodeDecision(False, "unsafe node path")
        path = PurePosixPath(relative_path)
        if any(part.startswith(".") for part in path.parts) or any(ord(c) < 32 for c in relative_path):
            return NodeDecision(False, "local metadata or unsafe path")
        surface = "Published" if path.parts[0] == "published" else path.parts[0]
        if surface not in binding.surfaces:
            return NodeDecision(False, "path is outside bound surface")
        return self.decide(actor, binding.node_id, surface, operation,
                           generation=binding.generation, store_id=store_id)
