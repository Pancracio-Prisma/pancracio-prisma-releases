"""Fail-closed organizational knowledge classification contract.

This module evaluates metadata; it does not publish a Seat projection.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import re
from typing import Any

import yaml


class ClassificationError(ValueError):
    pass


AUDIENCES = frozenset({"management", "shared", "delivery"})
FOLDER_POLICY = ".pancracio-classification.yaml"
SCOPE_ID = re.compile(r"^[a-z][a-z0-9_-]*$")


@dataclass(frozen=True)
class Classification:
    audience: frozenset[str]
    scope: frozenset[tuple[str, str]]
    global_scope: bool
    lifecycle: str
    provenance: str

    @property
    def management_only(self) -> bool:
        return self.audience == {"management"}

    @property
    def potentially_projectable(self) -> bool:
        return (self.lifecycle == "active" and bool(self.audience & {"shared", "delivery"})
                and (self.global_scope or bool(self.scope)))


def _mapping(path: Path) -> dict[str, Any]:
    if path.is_symlink():
        raise ClassificationError("classification source cannot be a symlink")
    try:
        value = yaml.safe_load(path.read_text(encoding="utf-8"))
    except (OSError, yaml.YAMLError) as exc:
        raise ClassificationError("classification metadata cannot be read") from exc
    if not isinstance(value, dict):
        raise ClassificationError("classification metadata must be a mapping")
    return value


def _frontmatter(path: Path) -> dict[str, Any]:
    if path.is_symlink() or not path.is_file() or path.suffix.lower() != ".md":
        raise ClassificationError("knowledge unit is not a regular Markdown file")
    try:
        contents = path.read_text(encoding="utf-8")
    except OSError as exc:
        raise ClassificationError("knowledge unit cannot be read") from exc
    if not contents.startswith("---\n"):
        return {}
    frontmatter, separator, _ = contents[4:].partition("\n---\n")
    if not separator:
        raise ClassificationError("unclosed knowledge frontmatter")
    try:
        value = yaml.safe_load(frontmatter)
    except yaml.YAMLError as exc:
        raise ClassificationError("invalid knowledge frontmatter") from exc
    if value is None:
        return {}
    if not isinstance(value, dict):
        raise ClassificationError("knowledge frontmatter must be a mapping")
    return value


def _audience(value: Any) -> frozenset[str]:
    if isinstance(value, str):
        value = [value]
    if not isinstance(value, list) or not value or any(not isinstance(x, str) for x in value):
        raise ClassificationError("invalid audience; unit remains Management Only")
    audiences = frozenset(value)
    if not audiences <= AUDIENCES:
        raise ClassificationError("unknown audience; unit remains Management Only")
    return audiences


def _scope(value: Any) -> tuple[frozenset[tuple[str, str]], bool]:
    if value is None:
        return frozenset(), False
    if isinstance(value, dict) and value == {"global": True}:
        return frozenset(), True
    if not isinstance(value, list) or not value:
        raise ClassificationError("invalid scope; unit cannot be projected")
    scopes: set[tuple[str, str]] = set()
    for item in value:
        if (not isinstance(item, dict) or set(item) != {"type", "id"}
                or not isinstance(item["type"], str) or not isinstance(item["id"], str)
                or not SCOPE_ID.fullmatch(item["type"]) or not SCOPE_ID.fullmatch(item["id"])):
            raise ClassificationError("invalid scope; unit cannot be projected")
        scopes.add((item["type"], item["id"]))
    return frozenset(scopes), False


def classify_unit(unit: Path, domain_root: Path) -> Classification:
    """Resolve explicit unit > nearest folder policy > Management-only default."""
    root = domain_root.resolve()
    path = unit.resolve()
    if not path.is_relative_to(root) or unit.is_symlink():
        raise ClassificationError("knowledge unit leaves canonical domain")
    metadata = _frontmatter(path)
    policies: list[tuple[str, dict[str, Any]]] = [(path.relative_to(root).as_posix(), metadata)]
    current = path.parent
    while current.is_relative_to(root):
        candidate = current / FOLDER_POLICY
        if candidate.exists() or candidate.is_symlink():
            policies.append((candidate.relative_to(root).as_posix(), _mapping(candidate)))
        if current == root:
            break
        current = current.parent

    def resolve(key: str, default: Any) -> tuple[Any, str]:
        for source, policy in policies:
            if key in policy:
                return policy[key], source
        return default, "domain-default"

    audience_value, audience_source = resolve("audience", ["management"])
    scope_value, _ = resolve("scope", None)
    lifecycle_value, _ = resolve("lifecycle", "unreviewed")
    if lifecycle_value not in {"active", "draft", "historical", "archived", "unreviewed"}:
        raise ClassificationError("invalid lifecycle; unit cannot be projected")
    audience = _audience(audience_value)
    scope, global_scope = _scope(scope_value)
    return Classification(audience, scope, global_scope, lifecycle_value, audience_source)


def require_no_confidentiality_reduction(old: Classification, new: Classification) -> None:
    """Increment 3 has no authority path to apply a broader classification."""
    gained_audience = bool((new.audience - old.audience) & {"shared", "delivery"})
    gained_scope = (new.global_scope and not old.global_scope) or (not old.global_scope and bool(new.scope - old.scope))
    newly_projectable = new.potentially_projectable and not old.potentially_projectable
    if gained_audience or gained_scope or newly_projectable:
        raise ClassificationError("confidentiality reduction requires a future governed Management decision")
