"""Small, transcript-free Codex turn gate for governed memory checkpoints."""

from __future__ import annotations

import hashlib
import json
import os
import tempfile
from pathlib import Path
from typing import Any


def _state_path(workspace: Path, session_id: str) -> Path:
    if not session_id or len(session_id) > 256:
        raise ValueError("invalid memory session id")
    key = hashlib.sha256((str(workspace.resolve()) + "\0" + session_id).encode()).hexdigest()
    return Path(tempfile.gettempdir()) / "panky-memory-turns" / f"{key}.json"


def _read(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    return value if isinstance(value, dict) else {}


def _write(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    fd, name = tempfile.mkstemp(prefix=".memory-", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as stream:
            json.dump(value, stream, sort_keys=True)
        os.chmod(name, 0o600)
        os.replace(name, path)
    finally:
        if os.path.exists(name):
            os.unlink(name)


def record_checkpoint(workspace: Path, session_id: str, result: dict[str, Any]) -> None:
    if result.get("state") not in {"COMMITTED", "ALREADY_SAVED", "NO_DURABLE_UNITS"}:
        return
    path = _state_path(workspace, session_id)
    state = _read(path)
    if state.get("pending"):
        state["closed"] = True
        state["awaiting_continuation"] = False
        state["receipt_state"] = result["state"]
        _write(path, state)


def handle_hook(workspace: Path, event: dict[str, Any]) -> dict[str, Any]:
    session_id = event.get("session_id")
    name = event.get("hook_event_name")
    if not isinstance(session_id, str) or name not in {"UserPromptSubmit", "Stop"}:
        return {}
    path = _state_path(workspace, session_id)
    state = _read(path)
    if name == "UserPromptSubmit":
        if (state.get("awaiting_continuation")
                and str(event.get("prompt", "")).startswith("Panky memory checkpoint missing.")):
            state["awaiting_continuation"] = False
        else:
            state = {"pending": True, "closed": False, "turn_id": event.get("turn_id"),
                     "attempts": 0, "awaiting_continuation": False}
        _write(path, state)
        return {"hookSpecificOutput": {"hookEventName": name, "additionalContext":
                "Before final reply, close this turn with panky memory-checkpoint "
                f"--workspace . --session-id {session_id}. Submit bounded durable units "
                "or an explicit no-durable reason; inspect the receipt."}}
    if not state.get("pending") or state.get("closed"):
        return {}
    if state.get("attempts", 0) >= 2:
        return {"systemMessage": "Panky memory checkpoint was not confirmed for this turn."}
    state["attempts"] = state.get("attempts", 0) + 1
    state["awaiting_continuation"] = True
    _write(path, state)
    return {"decision": "block", "reason":
            "Panky memory checkpoint missing. Resolve durable facts against authorized Obsidian "
            "sources, then call panky memory-checkpoint --workspace . "
            f"--session-id {session_id} with JSON units or a no-durable reason. "
            "Review the receipt before finalizing."}
