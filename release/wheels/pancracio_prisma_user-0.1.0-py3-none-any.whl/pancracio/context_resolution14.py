"""Bounded task-level Context Resolution over authorized/materialized graph."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import re
import subprocess
from typing import Sequence

from .context_manifest14 import verify_graph_manifest
from .context_topology import topology_from_core
from .identity import VerifiedActor
from .node_authority import NodeAuthority
from .registry import CoreRegistry
from .obsidian_map import MAP_NAME


class ResolutionBlocked(ValueError):
    pass


@dataclass(frozen=True)
class ActiveSource:
    node_id: str
    surface: str
    path: str
    source_commit: str


@dataclass(frozen=True)
class ActiveContext:
    node_ids: tuple[str, ...]
    sources: tuple[ActiveSource, ...]
    personal_included: bool
    status: str
    personal_status: str = 'NOT_REQUESTED'


def _head(root: Path) -> str:
    result = subprocess.run(['git', '-C', str(root), 'rev-parse', 'HEAD'], capture_output=True, text=True)
    if result.returncode:
        raise ResolutionBlocked('materialized Git source unavailable')
    return result.stdout.strip()


def _tracked_clean(root: Path, pathspec: str) -> list[Path]:
    """Return only committed files whose working bytes still match HEAD."""
    tracked = subprocess.run(['git', '-C', str(root), 'ls-files', '-z', '--', pathspec],
                             capture_output=True, timeout=30, check=True).stdout.decode().split('\0')
    dirty = set(subprocess.run(['git', '-C', str(root), 'diff', '--name-only', '-z', 'HEAD', '--', pathspec],
                               capture_output=True, timeout=30, check=True).stdout.decode().split('\0'))
    base = root.resolve()
    return [candidate for relative in tracked if relative and relative not in dirty
            if (candidate := root / relative).is_file() and not candidate.is_symlink()
            and candidate.resolve().is_relative_to(base)]


def _alias_candidates(query: str, registry: CoreRegistry, authorized: set[str]) -> list[str]:
    policy = registry.topology_policy
    assert policy is not None
    q = query.casefold()
    matches: list[str] = []
    for node_id, row in policy['nodes'].items():
        if node_id not in authorized:
            continue
        aliases = [row['display_name'], *([row['seat_id']] if 'seat_id' in row else [])]
        if any(re.search(r'(?<!\w)' + re.escape(alias.casefold()) + r'(?!\w)', q) for alias in aliases):
            matches.append(node_id)
    # A child mention often includes the ancestor name, e.g. company/team_01.
    # Keep the deepest explicit candidate as the active target.
    authority = topology_from_core(registry)
    return [node for node in matches if not any(node in authority.ancestors(other) for other in matches)]


def _query_terms(query: str, *, aliases: set[str] = frozenset()) -> list[str]:
    generic = {'que', 'qué', 'sobre', 'para', 'con', 'los', 'las', 'una', 'del',
               'decidió', 'decidimos', 'dice', 'cuál', 'cuáles', 'hay'} | aliases
    return [term for term in re.findall(r'[a-záéíóúñ0-9_]{3,}', query.casefold())
            if term not in generic]


def _relevance(path: Path, root: Path, terms: Sequence[str]) -> int:
    if not terms:
        return 0
    relative = path.relative_to(root).as_posix().casefold()
    sample = path.read_text(encoding='utf-8', errors='replace')[:40000].casefold()
    return sum(4 * relative.count(term) + sample.count(term) for term in terms)


def resolve_active_context(workspace: Path, query: str, actor: VerifiedActor, registry: CoreRegistry,
                           manifest: dict, *, expected_core_commit: str,
                           node_hints: Sequence[str] = (), surfaces: Sequence[str] = (),
                           include_personal: bool = False, max_nodes: int = 3,
                           max_files: int = 8,
                           catalog: dict | None = None) -> ActiveContext:
    mode_path = workspace / '.panky/gateway-auth-mode'
    if mode_path.is_symlink():
        raise ResolutionBlocked('Gateway authentication mode path is unsafe')
    oidc_mode = mode_path.exists() and mode_path.read_text(encoding='utf-8').strip() == 'oidc'
    if oidc_mode:
        from .context_catalog20 import fetch_catalog, verify_catalog_manifest
        current = catalog if catalog is not None else fetch_catalog(workspace / '.panky')
        verify_catalog_manifest(manifest, current, actor, registry,
                                expected_core_commit=expected_core_commit)
        # The manifest alone is not proof that the bytes mounted in Obsidian
        # still belong to those repositories.  Reject an incomplete or
        # replaced organizational view before reading any note.
        from .materialization14 import materialize_authorized
        materialize_authorized(workspace, manifest, actor, registry,
                               expected_core_commit=expected_core_commit,
                               clone=False, catalog=current)
    else:
        verify_graph_manifest(manifest, actor, registry, expected_core_commit=expected_core_commit)
    authority = NodeAuthority(registry)
    if max_nodes < 1 or max_nodes > 12 or max_files < 1 or max_files > 40:
        raise ResolutionBlocked('Active Context budget outside governed bounds')
    aliases = {row['display_name'].casefold() for row in registry.topology_policy['nodes'].values()}
    terms = _query_terms(query, aliases=aliases)
    candidates = list(node_hints) if node_hints else _alias_candidates(query, registry, set(manifest['authorized_nodes']))
    semantic_search = not node_hints and not candidates and bool(terms)
    if semantic_search:
        # Search only the Actor's mounted organizational view. The result
        # budget limits selected nodes, not which authorized node can be found.
        candidates = sorted(manifest['authorized_nodes'])
    if not candidates:
        anchors = sorted(set(manifest['anchors']) & set(manifest['authorized_nodes']))
        if len(anchors) > 1:
            raise ResolutionBlocked('ACTIVE_CONTEXT_AMBIGUOUS: specify an organizational node')
        candidates = anchors
    if len(candidates) > max_nodes and not semantic_search:
        raise ResolutionBlocked('ACTIVE_CONTEXT_AMBIGUOUS: too many candidate nodes')
    selected: list[str] = []
    ranked_sources: list[tuple[int, float, str, ActiveSource]] = []
    observed_heads: dict[Path, str] = {}
    mounted_any = False
    requested_surfaces = tuple(surfaces or ('State', 'Work', 'Knowledge', 'Published'))
    for node_id in candidates:
        if node_id not in manifest['authorized_nodes']:
            raise ResolutionBlocked('NODE_NOT_AUTHORIZED')
        if not oidc_mode and not authority.graph.decide_actor(actor, registry, node_id, 'read').allowed:
            raise ResolutionBlocked('NODE_NOT_AUTHORIZED_FOR_READ')
        selected.append(node_id)
        for surface in requested_surfaces:
            if (node_id, surface) not in authority.by_surface:
                continue
            binding = authority.binding(node_id, surface)
            if binding.store_id not in manifest['materialized_bindings']:
                continue
            mounted_any = True
            root = workspace / binding.local_path
            folder = root / ('published' if surface == 'Published' else surface)
            canonical_knowledge = binding.store_id == 'organization_canonical' and surface == 'Knowledge'
            if not canonical_knowledge and (not folder.is_dir() or folder.is_symlink()):
                continue
            commit = _head(root)
            observed_heads[root] = commit
            if canonical_knowledge:
                files = [path for path in _tracked_clean(root, '*.md') if path.name != MAP_NAME]
            else:
                files = sorted((p for p in _tracked_clean(root, folder.relative_to(root).as_posix())
                                if p.name.casefold() != 'readme.md'),
                               key=lambda p: (p.parent.name == 'updates', p.name == 'Current Work.md',
                                              p.stat().st_mtime, p.as_posix()), reverse=True)
            for path in files:
                relative = path.relative_to(root).as_posix()
                if (canonical_knowledge or oidc_mode
                        or authority.decide_path(actor, binding.store_id, relative, 'read').allowed):
                    score = _relevance(path, root, terms)
                    if canonical_knowledge and score <= 0:
                        continue
                    source = ActiveSource(node_id, surface, str(path), commit)
                    ranked_sources.append((score, path.stat().st_mtime, relative, source))
    if semantic_search:
        best: dict[str, int] = {}
        for score, _, _, source in ranked_sources:
            if score > 0:
                best[source.node_id] = max(score, best.get(source.node_id, 0))
        if best:
            selected = sorted(best, key=lambda node: (-best[node], node))[:max_nodes]
        else:
            selected = sorted(set(manifest['anchors']) & set(manifest['authorized_nodes']))[:max_nodes]
        ranked_sources = [row for row in ranked_sources if row[3].node_id in selected]
    # Obsidian links are relationships between authorized notes, not authority
    # to follow a path. Build the graph only from clean, mounted Git content.
    if terms and ranked_sources:
        from .obsidian_graph import related_notes
        related_sources: dict[Path, ActiveSource] = {
            Path(source.path).resolve(): source for _, _, _, source in ranked_sources
            if Path(source.path).suffix.casefold() == '.md'}
        for store_id, row in manifest['materialized_bindings'].items():
            binding = authority.bindings.get(store_id)
            if binding is None or binding.node_id not in manifest['authorized_nodes']:
                continue
            surface = 'Published' if binding.mode == 'generated' else 'Knowledge'
            if surface not in binding.surfaces:
                continue
            if (not oidc_mode and
                    not authority.decide(actor, binding.node_id, surface, 'read').allowed):
                continue
            root = workspace / binding.local_path
            if not root.is_dir() or root.is_symlink():
                continue
            folder = root / ('published' if surface == 'Published' else 'Knowledge')
            if store_id != 'organization_canonical' and (not folder.is_dir() or folder.is_symlink()):
                continue
            for path in _tracked_clean(root, '*.md' if store_id == 'organization_canonical'
                                       else folder.relative_to(root).as_posix()):
                if (path.suffix.casefold() != '.md' or
                        path.name.casefold() == 'readme.md' or path.name == MAP_NAME):
                    continue
                relative = path.relative_to(root).as_posix()
                if not oidc_mode and store_id != 'organization_canonical' and not authority.decide_path(
                        actor, store_id, relative, 'read').allowed:
                    continue
                related_sources.setdefault(path.resolve(), ActiveSource(
                    binding.node_id, surface, str(path), _head(root)))
                observed_heads[root] = _head(root)
                if len(related_sources) >= 1000:
                    break
            if len(related_sources) >= 1000:
                break
        graph = related_notes(sorted(related_sources), vault_root=workspace)
        existing = {Path(source.path).resolve() for _, _, _, source in ranked_sources}
        seeds = [source for score, _, _, source in sorted(
            ranked_sources, key=lambda item: item[0], reverse=True)
                 if score > 0 and Path(source.path).suffix.casefold() == '.md'][:3]
        for seed in seeds:
            for neighbor in sorted(graph.get(Path(seed.path).resolve(), ())):
                source = related_sources[neighbor]
                if neighbor in existing or (source.node_id not in selected and len(selected) >= max_nodes):
                    continue
                if source.node_id not in selected:
                    selected.append(source.node_id)
                ranked_sources.append((1, neighbor.stat().st_mtime, neighbor.name, source))
                existing.add(neighbor)
    ranked_sources.sort(key=lambda row: (row[0] > 0, row[0], row[1], row[2]), reverse=True)
    personal_sources: list[ActiveSource] = []
    personal_status = 'NOT_REQUESTED'
    if include_personal:
        if manifest['personal']['owner_actor_id'] != actor.actor_id:
            raise ResolutionBlocked('Personal hard boundary')
        root = workspace / manifest['personal']['path']
        if root.is_dir() and (root / '.git').is_dir():
            commit = _head(root)
            observed_heads[root] = commit
            terms = [term for term in re.findall(r'[a-záéíóúñ0-9_]{3,}', query.casefold())
                     if term not in {'que', 'qué', 'sobre', 'para', 'con', 'los', 'las', 'una', 'del',
                                     'personal', 'cómo', 'como', 'estoy', 'sabes',
                                     'contexto', 'quién', 'quien', 'soy', 'recuerdas', 'tengo'}]
            ranked: list[tuple[int, float, str, Path]] = []
            for path in _tracked_clean(root, '*.md'):
                relative = path.relative_to(root).as_posix()
                if relative.startswith('99 Archive/') or path.name in {'AGENTS.md', 'README.md', MAP_NAME}:
                    continue
                sample = path.read_text(encoding='utf-8', errors='replace')[:40000].casefold()
                score = sum(4 * relative.casefold().count(term) + sample.count(term) for term in terms)
                ranked.append((score, path.stat().st_mtime, relative, path))
            for score, _, _, path in sorted(ranked, key=lambda row: (-row[0], -row[1], row[2])):
                if terms and score <= 0:
                    break
                personal_sources.append(ActiveSource(f'personal:{actor.actor_id}:general',
                                                     'Knowledge', str(path), commit))
            personal_status = 'READY' if personal_sources else 'NO_MATCHING_SOURCE'
        else:
            personal_status = 'BACKING_UNAVAILABLE'
    # Reserve part of the bounded result for Personal when requested. Otherwise
    # eight organizational matches can hide every private source.
    personal_limit = min(len(personal_sources), max(1, max_files // 2)) if include_personal else 0
    sources = [source for _, _, _, source in ranked_sources[:max_files - personal_limit]]
    sources.extend(personal_sources[:personal_limit])
    status = 'READY' if sources else 'NO_PUBLISHED_SOURCE' if mounted_any or include_personal else 'NODE_NOT_MATERIALIZED'
    # A policy publication or Git pull can race this read.  Never return a
    # mixture of notes from different catalog/repository generations.
    if oidc_mode:
        latest = catalog if catalog is not None else fetch_catalog(workspace / '.panky')
        verify_catalog_manifest(manifest, latest, actor, registry,
                                expected_core_commit=expected_core_commit)
    if any(_head(root) != commit for root, commit in observed_heads.items()):
        raise ResolutionBlocked('CONTEXT_CHANGED_DURING_READ: retry after synchronization')
    return ActiveContext(tuple(selected), tuple(sources), bool(personal_limit), status, personal_status)
