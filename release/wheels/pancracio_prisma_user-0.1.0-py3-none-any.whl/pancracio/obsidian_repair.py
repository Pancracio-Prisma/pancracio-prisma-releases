"""One-time governed repair of organizational and Actor-owned Obsidian maps.

    Dry-run by default. Organizational writes require current Gateway authority
    for each node. Personal requires proof of the owning Actor and stays in its backing.
"""

from __future__ import annotations

import argparse
import hashlib
from pathlib import Path
import subprocess

import yaml

from .composition import inspect_runtime
from .context_catalog20 import fetch_catalog, verify_catalog_manifest, context_decision
from .identity import authenticate_runtime
from .materialization14 import _local, _verify_binding
from .node_authority import NodeAuthority
from .obsidian_map import (MAP_NAME, audit_mounted_graph,
                                   audit_personal_graph, render_map, tracked_markdown)
from .personal_topology14 import read_personal_topology
from .registry import CoreRegistry


def git(root: Path, *args: str) -> str:
    result = subprocess.run(["git", "-C", str(root), *args], capture_output=True,
                            text=True, timeout=45)
    if result.returncode:
        raise RuntimeError("organizational Git operation failed; local work preserved")
    return result.stdout.strip()


def _personal_untracked(root: Path) -> tuple[str, ...]:
    result = subprocess.run(["git", "-C", str(root), "ls-files", "-z", "--others",
                             "--exclude-standard", "--", "*.md"], capture_output=True, timeout=30)
    if result.returncode:
        raise RuntimeError("Personal Git inventory unavailable")
    extra = tuple(sorted(name for name in result.stdout.decode("utf-8", "surrogateescape").split("\0")
                         if name and name != MAP_NAME))
    listed = set(tracked_markdown(root, extra=extra))
    actual = {path.relative_to(root).as_posix() for path in root.rglob("*.md")
              if ".git" not in path.relative_to(root).parts and path.name != MAP_NAME}
    if actual != listed:
        raise RuntimeError("Personal contains ignored or unsafe Markdown; repair stopped")
    return extra


def _apply_personal(workspace: Path, root: Path, manifest: dict, extra: tuple[str, ...],
                    content: str) -> None:
    map_path = root / MAP_NAME
    if map_path.is_symlink() or git(root, "status", "--porcelain", "--", MAP_NAME):
        raise RuntimeError("Personal map has preexisting local work")
    if manifest["personal"]["mode"] == "private":
        if git(root, "remote", "get-url", "origin") != manifest["personal"]["remote"]:
            raise RuntimeError("Personal remote differs from Actor manifest")
        git(root, "fetch", "origin", "main")
        head = git(root, "rev-parse", "HEAD")
        if (head != git(root, "rev-parse", "refs/remotes/origin/main") or
                head != git(root, "ls-remote", "origin", "refs/heads/main").split()[0]):
            raise RuntimeError("Personal remote advanced; local work preserved")
    elif manifest["personal"]["mode"] != "local":
        raise RuntimeError("Personal storage mode unsupported")
    before = {name: hashlib.sha256((root / name).read_bytes()).digest() for name in extra}
    map_path.write_text(content, encoding="utf-8")
    if any(hashlib.sha256((root / name).read_bytes()).digest() != before[name] for name in extra):
        raise RuntimeError("Personal note changed during repair; local work preserved")
    paths = [MAP_NAME, *extra]
    git(root, "add", "--", *paths)
    for name in paths:
        if not git(root, "ls-files", "--stage", "--", name).startswith("100644 "):
            raise RuntimeError("Personal Git entry is unsafe; local work preserved")
    git(root, "commit", "--only", "-m", "Connect Actor-owned Obsidian notes", "--", *paths)
    if manifest["personal"]["mode"] == "private":
        commit = git(root, "rev-parse", "HEAD")
        git(root, "push", "origin", "HEAD:main")
        if git(root, "ls-remote", "origin", "refs/heads/main").split()[0] != commit:
            raise RuntimeError("Personal repair push lacks remote readback")


def repair(workspace: Path, *, apply: bool = False, scope: str = "all") -> dict[str, int]:
    if scope not in {"all", "organization", "personal"}:
        raise ValueError("repair scope must be all, organization or personal")
    workspace = workspace.resolve(strict=True)
    inspect_runtime(workspace, probe_gateway=False)
    registry = CoreRegistry.load(workspace / "domains/core")
    actor = authenticate_runtime(registry, workspace)
    manifest = yaml.safe_load((workspace / ".panky/context-manifest.yaml").read_text())
    plan = []
    audits = {}
    if scope in {"all", "organization"}:
        audits = audit_mounted_graph(workspace)
        pending = any(row.status != "READY" for row in audits.values())
        if pending:
            core_commit = git(workspace / "domains/core", "rev-parse", "refs/remotes/origin/main")
            mode_path = workspace / ".panky/gateway-auth-mode"
            if mode_path.is_symlink():
                raise RuntimeError("Gateway authentication mode path is unsafe")
            oidc_mode = mode_path.is_file() and mode_path.read_text(encoding="utf-8").strip() == "oidc"
            if oidc_mode:
                verify_catalog_manifest(manifest, fetch_catalog(workspace / ".panky"), actor, registry,
                                        expected_core_commit=core_commit)
            else:
                from .context_manifest14 import verify_graph_manifest
                verify_graph_manifest(manifest, actor, registry, expected_core_commit=core_commit)
            authority = NodeAuthority(registry)
            for store_id, row in manifest["materialized_bindings"].items():
                binding = authority.bindings[store_id]
                repo_id = binding.repository.split("/", 1)[1]
                report = audits[repo_id]
                if report.status == "READY":
                    continue
                root = _local(workspace, binding.local_path)
                _verify_binding(root, binding)
                if git(root, "status", "--porcelain"):
                    raise RuntimeError("organizational repository has local work; repair stopped")
                git(root, "fetch", "origin", "main")
                head = git(root, "rev-parse", "HEAD")
                if (head != git(root, "rev-parse", "refs/remotes/origin/main") or
                        head != git(root, "ls-remote", "origin", "refs/heads/main").split()[0]):
                    raise RuntimeError("organizational repository differs from remote; repair stopped")
                if binding.mode == "generated":
                    if not authority.decide(actor, binding.node_id, "Published", "publish_down").allowed:
                        raise RuntimeError("Core did not authorize generated publication repair")
                elif oidc_mode:
                    decision = context_decision(workspace / ".panky", node_id=binding.node_id,
                                                surface="knowledge", operation="update")
                    if not decision["allowed"] or decision.get("release") != core_commit:
                        raise RuntimeError("Gateway did not authorize organizational graph repair")
                elif not authority.decide(actor, binding.node_id, "Knowledge", "write").allowed:
                    raise RuntimeError("Core did not authorize organizational graph repair")
                map_path = root / MAP_NAME
                if map_path.is_symlink():
                    raise RuntimeError("organizational map path is unsafe")
                plan.append((repo_id, root, render_map(workspace, root)))
    personal = None
    if scope in {"all", "personal"}:
        if manifest["personal"]["owner_actor_id"] != actor.actor_id:
            raise RuntimeError("Personal backing belongs to another Actor")
        read_personal_topology(workspace, actor)
        report = audit_personal_graph(workspace, actor.actor_id)
        root = workspace / "domains/actor"
        if report.status != "READY" and report.notes:
            extra = _personal_untracked(root)
            personal = (root, extra, render_map(workspace, root, extra=extra, scope="personal"))
    if apply:
        for _, root, content in plan:
            (root / MAP_NAME).write_text(content, encoding="utf-8")
            git(root, "add", "--", MAP_NAME)
            if not git(root, "ls-files", "--stage", "--", MAP_NAME).startswith("100644 "):
                raise RuntimeError("organizational map Git entry is unsafe")
            git(root, "commit", "--only", "-m", "Connect organizational Obsidian notes", "--", MAP_NAME)
            commit = git(root, "rev-parse", "HEAD")
            git(root, "push", "origin", "HEAD:main")
            if git(root, "ls-remote", "origin", "refs/heads/main").split()[0] != commit:
                raise RuntimeError("organizational graph repair push lacks remote readback")
        if personal:
            _apply_personal(workspace, personal[0], manifest, personal[1], personal[2])
    org_orphans = (sum(row.orphans for row in audit_mounted_graph(workspace).values()) if apply
                   else sum(row.orphans for row in audits.values())) if scope != "personal" else 0
    personal_orphans = (audit_personal_graph(workspace, actor.actor_id).orphans if apply else report.orphans) if scope != "organization" else 0
    if apply and (org_orphans or personal_orphans or
                  (scope != "personal" and any(row.status != "READY" for row in audit_mounted_graph(workspace).values())) or
                  (scope != "organization" and audit_personal_graph(workspace, actor.actor_id).status != "READY")):
        raise RuntimeError("Obsidian graph remains unhealthy after governed repair")
    return {"repositories": len(plan) + int(personal is not None),
            "notes": sum(audits[name].notes for name, _, _ in plan) + (report.notes if personal else 0),
            "remaining_orphans": org_orphans + personal_orphans}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--workspace", type=Path, required=True)
    parser.add_argument("--apply", action="store_true")
    parser.add_argument("--scope", choices=("all", "organization", "personal"), default="all")
    args = parser.parse_args()
    print(repair(args.workspace, apply=args.apply, scope=args.scope))


if __name__ == "__main__":
    main()
