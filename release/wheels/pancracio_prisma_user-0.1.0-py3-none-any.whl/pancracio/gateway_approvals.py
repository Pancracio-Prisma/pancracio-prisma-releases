"""Codex host approvals for verified read-only Gateway MCP operations.

These lists govern whether Codex may invoke a tool without a host approval
prompt. They grant no Gateway principal, source, capability, or write scope.
The single bounded exploration mutation is permitted for the user-authorized
Panky/Engine handoff; Gateway RBAC, active-cycle mandate and Engine budget
remain authoritative. Other mutation tools retain the conservative default.
"""

VERIFIED_READ_TOOLS = (
    "acquisition_get_account",
    "acquisition_get_attention",
    "acquisition_get_attention_counts",
    "acquisition_get_buyer_dry_run",
    "acquisition_get_cycle",
    "acquisition_get_exploration_map",
    "acquisition_get_effect",
    "acquisition_get_effect_bindings",
    "acquisition_get_health",
    "acquisition_list_accounts",
    "acquisition_list_attention",
    "acquisition_list_crm",
    "acquisition_list_cycles",
    "acquisition_list_effect_attention",
    "acquisition_list_priorities",
    "acquisition_list_work",
    "agent_signal_status",
    "discover_source_candidates",
    "get_agent_signal",
    "get_agent_signal_operation_history",
    "get_operation_history",
    "get_source_candidate_details",
    "get_source_proposal",
    "hubspot_call_read_tool",
    "hubspot_get_crm_objects",
    "hubspot_get_properties",
    "hubspot_get_user_details",
    "hubspot_list_tools",
    "hubspot_search_crm_objects",
    "hubspot_search_owners",
    "hubspot_search_properties",
    "inspect_document_structure",
    "inspect_document_tab",
    "inspect_docx_structure",
    "inspect_sheet_validation",
    "inspect_source_artifacts",
    "inspect_spreadsheet_structure",
    "inspect_visual_asset",
    "list_agent_signals",
    "list_source_documents",
    "list_source_proposals",
    "list_sources",
    "n8n_list_tools",
    "n8n_status",
    "openwa_list_tools",
    "openwa_status",
    "resolve_source_artifact",
    "retrieve_document",
    "retrieve_sheet_range",
    "validate_document_structure",
    "validate_docx_structure",
    "validate_spreadsheet_structure",
)

APPROVED_BOUNDED_TOOLS = (
    "acquisition_direct_exploration",
)
