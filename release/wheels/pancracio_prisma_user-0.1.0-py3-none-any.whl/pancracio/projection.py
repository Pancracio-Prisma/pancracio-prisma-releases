"""Shared fail-closed dependency validation for governed 1.4 publication."""

from __future__ import annotations

from pathlib import PurePosixPath, PureWindowsPath
import re
import yaml

class ProjectionError(ValueError):
    pass


WIKI = re.compile(r"!?\[\[([^\]]+)\]\]")
MARKDOWN = re.compile(r"!?\[[^\]]*\]\(([^)]+)\)")
SAFE_ASSETS = {".png", ".jpg", ".jpeg", ".gif", ".webp", ".svg", ".pdf"}


def safe_path(name: str) -> PurePosixPath:
    if (not name or "\\" in name or name.startswith("/") or PureWindowsPath(name).is_absolute()
            or any(ord(c) < 32 for c in name) or "%" in name):
        raise ProjectionError("unsafe canonical dependency path")
    parts = name.split("/")
    if any(p in {"", ".", ".."} or p.endswith((" ", ".")) or any(c in '<>:"|?*' for c in p)
           or p.split(".", 1)[0].casefold() in {"con", "prn", "aux", "nul", *(f"com{i}" for i in range(1, 10)), *(f"lpt{i}" for i in range(1, 10))} for p in parts):
        raise ProjectionError("unsafe canonical dependency path")
    if len(name) > 240:
        raise ProjectionError("unsafe canonical dependency path")
    return PurePosixPath(name)


def _dependencies(content: str) -> list[tuple[str, bool]]:
    if content.startswith("---\n"):
        frontmatter, sep, _ = content[4:].partition("\n---\n")
        if not sep:
            raise ProjectionError("invalid Markdown metadata")
        try:
            metadata = yaml.safe_load(frontmatter) or {}
        except yaml.YAMLError as exc:
            raise ProjectionError("invalid Markdown metadata") from exc
        if not isinstance(metadata, dict):
            raise ProjectionError("invalid Markdown metadata")
        if any(metadata.get(key) for key in ("cover", "image", "images", "attachment", "attachments", "asset", "assets", "dependencies")):
            raise ProjectionError("frontmatter attachment requires explicit dependency contract")
    body = content  # Include wikilinks/embeds in frontmatter in dependency closure.
    found: list[tuple[str, bool]] = []
    for match in WIKI.finditer(body):
        target = match.group(1).split("|", 1)[0].split("#", 1)[0].strip()
        if target:
            found.append((target, True))
    for match in MARKDOWN.finditer(body):
        target = match.group(1).split("#", 1)[0].strip().strip("<>")
        if target and not re.match(r"^[a-z][a-z0-9+.-]*://", target, re.I) and not target.startswith("mailto:"):
            found.append((target, False))
    return found


def _resolve_dependency(source: str, target: str, paths: set[str], *, wiki: bool) -> str:
    # No path normalization before rejecting traversal or platform-specific syntax.
    safe_path(target)
    candidates: list[str] = []
    parent = PurePosixPath(source).parent
    for raw in (str(parent / target), target):
        if wiki and not PurePosixPath(raw).suffix:
            raw += ".md"
        if raw in paths:
            candidates.append(raw)
    if wiki and "/" not in target:
        name = target if PurePosixPath(target).suffix else target + ".md"
        candidates.extend(p for p in paths if PurePosixPath(p).name == name)
    matches = set(candidates)
    if len(matches) != 1:
        raise ProjectionError("dependency is missing or ambiguous")
    return matches.pop()
