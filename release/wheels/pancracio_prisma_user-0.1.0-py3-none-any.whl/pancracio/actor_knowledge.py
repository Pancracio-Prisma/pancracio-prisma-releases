"""Initialize private Actor Knowledge from the organizational template."""

from __future__ import annotations

from dataclasses import dataclass
import os
from pathlib import Path
import re
import subprocess
import tempfile

from .authority import RepositoryAuthority
from .identity import VerifiedActor

class ActorKnowledgeError(ValueError):
    pass


@dataclass(frozen=True)
class ActorKnowledge:
    path: Path
    mode: str
    remote: str | None


def _run(*args: str, cwd: Path | None = None) -> str:
    result = subprocess.run(args, cwd=cwd, capture_output=True, text=True, check=False)
    if result.returncode:
        raise ActorKnowledgeError(f"{args[0]} operation failed; local data preserved")
    return result.stdout.strip()


def _git(root: Path, *args: str) -> str:
    return _run("git", "-C", str(root), *args)


def _private_remote(actor: VerifiedActor, approved_owner: str, organization_owner: str,
                    repository_name: str | None = None) -> str:
    """Connect a private personal repo already created and verified in the browser."""
    if not re.fullmatch(r"[A-Za-z0-9](?:[A-Za-z0-9-]{0,38})", approved_owner):
        raise ActorKnowledgeError("explicit personal GitHub owner confirmation is required")
    if approved_owner.casefold() == organization_owner.casefold():
        raise ActorKnowledgeError("Actor Knowledge owner must be personal")
    repo_name = repository_name or f"actor-{actor.actor_id.replace('_', '-')}-knowledge"
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]{0,99}", repo_name):
        raise ActorKnowledgeError("Actor Knowledge repository name is invalid")
    remote = f"git@github.com:{approved_owner}/{repo_name}.git"
    _run("git", "ls-remote", remote)
    return remote


def _verify_existing_private(remote: str, organization_owner: str) -> None:
    match = re.fullmatch(r"git@github\.com:([^/]+)/([^/]+)\.git", remote)
    if not match or match.group(1).casefold() == organization_owner.casefold():
        raise ActorKnowledgeError("Actor Knowledge remote is not personal GitHub")
    _run("git", "ls-remote", remote)


def initialize_actor_knowledge(
    domains_root: Path,
    actor: VerifiedActor,
    authority: RepositoryAuthority,
    mode: str,
    *,
    template_remote: str,
    organization_owner: str,
    private_remote_factory=None,
    approved_owner: str | None = None,
    repository_name: str | None = None,
) -> ActorKnowledge:
    """Clone, detach all template remotes, then select local or new private GitHub."""
    if not re.fullmatch(r"git@github\.com:[A-Za-z0-9-]+/[A-Za-z0-9._-]+\.git", template_remote):
        raise ActorKnowledgeError("signed Actor Knowledge template remote is required")
    if mode not in {"local", "private"}:
        raise ActorKnowledgeError("Actor Knowledge persistence choice is required")
    authority.require(actor, "actor_knowledge", "write",
                      path="00 Home/README.md", target_actor_id=actor.actor_id)
    if domains_root.is_symlink():
        raise ActorKnowledgeError("domains root cannot be a symlink")
    domains_root.mkdir(parents=True, exist_ok=True)
    target = domains_root / "actor"
    if target.is_symlink():
        raise ActorKnowledgeError("Actor Knowledge path cannot be a symlink")
    if target.exists():
        if not (target / ".git").is_dir():
            raise ActorKnowledgeError("Actor Knowledge path is not an independent Git repository")
        remote = _git(target, "remote", "get-url", "origin") if "origin" in _git(target, "remote").splitlines() else None
        if remote == template_remote:
            raise ActorKnowledgeError("template remote remains attached")
        if mode == "local":
            if remote is not None:
                raise ActorKnowledgeError("existing Actor Knowledge persistence differs")
            return ActorKnowledge(target, mode, None)
        if remote is not None:
            if private_remote_factory is None:
                _verify_existing_private(remote, organization_owner)
            return ActorKnowledge(target, mode, remote)
    else:
        with tempfile.TemporaryDirectory(prefix=".actor-init-", dir=domains_root) as temp_dir:
            staging = Path(temp_dir) / "actor"
            _run("git", "clone", "--", template_remote, str(staging))
            remotes = _git(staging, "remote").splitlines()
            for remote in remotes:
                _git(staging, "remote", "remove", remote)
            if _git(staging, "remote"):
                raise ActorKnowledgeError("template remotes could not be detached")
            if not (staging / ".git").is_dir():
                raise ActorKnowledgeError("Actor Knowledge template is not Git")
            os.replace(staging, target)

    if mode == "local":
        print("Actor Knowledge is local only: it will not synchronize or recover on another device.")
        return ActorKnowledge(target, mode, None)

    try:
        if private_remote_factory is None:
            if not approved_owner:
                raise ActorKnowledgeError("private Actor Knowledge requires an explicit GitHub owner")
            remote = _private_remote(actor, approved_owner, organization_owner, repository_name)
        else:
            remote = private_remote_factory(actor)
        if not remote or remote == template_remote:
            raise ActorKnowledgeError("private remote cannot be the template")
        _git(target, "remote", "add", "origin", remote)
        _git(target, "push", "-u", "origin", "HEAD:main")
    except Exception as exc:
        # Keep the detached local repository. A failed private setup may be
        # retried deliberately; never push to an unverified remote.
        if "origin" in _git(target, "remote").splitlines():
            _git(target, "remote", "remove", "origin")
        if isinstance(exc, ActorKnowledgeError):
            raise
        raise ActorKnowledgeError("private Actor Knowledge setup failed; local data preserved") from exc
    return ActorKnowledge(target, mode, remote)
