"""Authorized, non-destructive Git freshness and Context Event handling.

An event is only a hint.  Every transition compares the configured origin/main;
no event-supplied URL, path or commit is ever checked out.
"""

from __future__ import annotations

from dataclasses import dataclass
import json
import os
from pathlib import Path
import re
import subprocess
from typing import Any

from filelock import FileLock, Timeout

from .composition import CompositionError, _read_yaml, _verify_repo
from prisma_common.repository_profile import repository_profile
from .registry import CoreRegistry, RegistryError
from .processes import background_creationflags


class SyncError(ValueError):
    pass


SHA = re.compile(r"[0-9a-f]{40}\Z")
PRIVATE_ID = re.compile(r"actor-private:act_[a-z0-9_]+\Z")
SAFE_ID = re.compile(r"[a-z][a-z0-9-]{0,79}\Z")


@dataclass(frozen=True)
class Mount:
    repository_id: str
    path: Path
    remote: str
    kind: str
    generation: int | None = None
    node_id: str | None = None
    store_id: str | None = None


@dataclass(frozen=True)
class SyncResult:
    repository_id: str
    before: str
    result: str
    local_head: str | None = None
    remote_head: str | None = None


def parse_event(raw: bytes | str | dict[str, Any]) -> dict[str, str]:
    try:
        event = json.loads(raw) if not isinstance(raw, dict) else raw
    except (ValueError, TypeError) as exc:
        raise SyncError("invalid Context Event JSON") from exc
    if (not isinstance(event, dict)
            or set(event) != {"schema_version", "event_type", "repository_id", "ref", "commit"}
            or event["schema_version"] != 1
            or event["event_type"] != "repo_updated"
            or event["ref"] != "refs/heads/main"
            or not isinstance(event["repository_id"], str)
            or not (SAFE_ID.fullmatch(event["repository_id"]) or PRIVATE_ID.fullmatch(event["repository_id"]))
            or not isinstance(event["commit"], str)
            or not SHA.fullmatch(event["commit"])):
        raise SyncError("unsupported or unsafe Context Event")
    return event


def make_event(repository_id: str, commit: str, *, allowed_ids: frozenset[str]) -> dict[str, Any]:
    if repository_id not in allowed_ids:
        raise SyncError("publisher repository is not allowlisted")
    return parse_event({"schema_version": 1, "event_type": "repo_updated",
                        "repository_id": repository_id, "ref": "refs/heads/main", "commit": commit})


def _git(path: Path, *args: str) -> tuple[int, str]:
    environment = os.environ.copy()
    environment["GIT_TERMINAL_PROMPT"] = "0"
    environment["GIT_SSH_COMMAND"] = "ssh -o BatchMode=yes -o ConnectTimeout=10 -o ConnectionAttempts=1"
    try:
        proc = subprocess.run(["git", "-C", str(path), *args], capture_output=True,
                              text=True, env=environment, timeout=30,
                              creationflags=background_creationflags())
    except subprocess.TimeoutExpired:
        return 124, ""
    return proc.returncode, proc.stdout.strip()


def _require_git(path: Path, *args: str) -> str:
    code, output = _git(path, *args)
    if code:
        raise SyncError("Git repository is unavailable")
    return output


def _runtime_manifest(workspace: Path) -> dict[str, Any]:
    from .context_manifest14 import validate_graph_manifest

    state = workspace / ".panky"
    manifest = _read_yaml(state / "context-manifest.yaml")
    owner = _read_yaml(state / "owner.yaml")
    if not manifest or not owner:
        raise SyncError("runtime is not enrolled")
    if manifest.get("schema_version") != 3:
        raise SyncError("UPDATE_REQUIRED: Context Manifest schema 3 required")
    validate_graph_manifest(manifest)
    if (manifest["state"] != "RUNTIME_COMPOSED"
            or any(manifest.get(k) != owner.get(k) for k in ("runtime_id", "actor_id", "google_subject_sha256"))):
        raise SyncError("runtime owner/manifest mismatch")
    return manifest



def authorized_mounts(workspace: Path, *, registry: CoreRegistry | None = None) -> dict[str, Mount]:
    """Reconstruct graph mounts from protected Core, never event-supplied paths."""
    workspace = workspace.resolve()
    manifest = _runtime_manifest(workspace)
    registry = registry or CoreRegistry.load(workspace / "domains" / "core")
    return _authorized_graph_mounts(workspace, manifest, registry)



def _authorized_graph_mounts(workspace: Path, manifest: dict[str, Any], registry: CoreRegistry) -> dict[str, Mount]:
    from .identity import authenticate_runtime
    from .context_manifest14 import verify_graph_manifest
    from .materialization14 import materialize_authorized
    from .node_authority import NodeAuthority

    # The worker refreshes the enrolled Google proof; local YAML and GitHub
    # credentials cannot select a different Actor or widen a mount.
    actor = authenticate_runtime(registry, workspace)
    trusted_commit = _require_git(workspace / "domains/core", "rev-parse", "refs/remotes/origin/main")
    mode_path = workspace / ".panky/gateway-auth-mode"
    if mode_path.is_symlink():
        raise SyncError("Gateway authentication mode path is unsafe")
    oidc_mode = mode_path.is_file() and mode_path.read_text(encoding="utf-8").strip() == "oidc"
    catalog = None
    if oidc_mode:
        from .context_catalog20 import fetch_catalog, verify_catalog_manifest
        catalog = fetch_catalog(workspace / ".panky")
        verify_catalog_manifest(manifest, catalog, actor, registry,
                                expected_core_commit=trusted_commit)
    else:
        verify_graph_manifest(manifest, actor, registry, expected_core_commit=trusted_commit)
    materialize_authorized(workspace, manifest, actor, registry,
                           expected_core_commit=trusted_commit, clone=False, catalog=catalog)
    authority = NodeAuthority(registry)
    profile = repository_profile(workspace)
    mounts = {
        profile.workspace_id: Mount(profile.workspace_id, workspace, profile.workspace_remote, "workspace"),
        profile.core_id: Mount(profile.core_id, workspace / "domains/core", profile.core_remote, "core"),
    }
    for store_id in manifest["materialized_bindings"]:
        binding = authority.bindings[store_id]
        repo_id = binding.repository.split("/", 1)[1]
        mounts[repo_id] = Mount(repo_id, workspace / binding.local_path,
                                f"git@github.com:{binding.repository}.git",
                                "graph_publication" if binding.mode == "generated" else "graph_node",
                                binding.generation, binding.node_id, store_id)
    personal = manifest["personal"]
    if personal["mode"] == "private":
        mounts[f"actor-private:{actor.actor_id}"] = Mount(
            f"actor-private:{actor.actor_id}", workspace / personal["path"],
            personal["remote"], "actor_private")
    return mounts


def _lock_path(workspace: Path, repository_id: str) -> Path:
    # ID was validated by mount resolution; no path fragments supplied by event.
    return workspace / ".panky" / "sync" / "locks" / f"{repository_id.replace(':', '-')}.lock"


def sync_mount(workspace: Path, mount: Mount, *, fetch: bool = True) -> SyncResult:
    """Fetch authoritative origin and fast-forward only a clean, behind checkout."""
    root = mount.path
    if root.is_symlink() or not (root / ".git").is_dir():
        return SyncResult(mount.repository_id, "INVALID_REPOSITORY", "SECURITY_BLOCKED")
    try:
        _verify_repo(root, mount.remote)
    except CompositionError:
        return SyncResult(mount.repository_id, "INVALID_REMOTE", "SECURITY_BLOCKED")
    if mount.kind in {"graph_node", "graph_publication"}:
        marker_name = "publication.yaml" if mount.kind == "graph_publication" else ("repo.yaml" if mount.store_id == "organization_canonical" else "node.yaml")
        marker = _read_yaml(root / marker_name)
        if marker is None:
            return SyncResult(mount.repository_id, "BACKING_MARKER_MISSING", "SECURITY_BLOCKED")
        if mount.kind == "graph_publication" and (marker.get("target_node_id") != mount.node_id or marker.get("generation") != mount.generation):
            return SyncResult(mount.repository_id, "GENERATION_MISMATCH", "RECONCILIATION_REQUIRED")
        if mount.kind == "graph_node" and mount.store_id != "organization_canonical" and (marker.get("node_id") != mount.node_id or marker.get("generation") != mount.generation):
            return SyncResult(mount.repository_id, "GENERATION_MISMATCH", "RECONCILIATION_REQUIRED")
    lock_path = _lock_path(workspace, mount.repository_id)
    lock_path.parent.mkdir(parents=True, exist_ok=True)
    lock = FileLock(lock_path)
    try:
        lock.acquire(timeout=0)
    except Timeout:
        return SyncResult(mount.repository_id, "BUSY", "DEFERRED")
    try:
        return _sync_locked(mount, fetch)
    finally:
        lock.release()


def _sync_locked(mount: Mount, fetch: bool) -> SyncResult:
    root = mount.path
    repo_id = mount.repository_id
    code, branch = _git(root, "symbolic-ref", "--quiet", "--short", "HEAD")
    if code or branch != "main":
        return SyncResult(repo_id, "DETACHED_OR_UNEXPECTED_BRANCH", "RECONCILIATION_REQUIRED")
    if (root / ".git" / "index.lock").exists():
        return SyncResult(repo_id, "GIT_BUSY", "DEFERRED")
    tracked_dirty = bool(_require_git(root, "status", "--porcelain", "--untracked-files=no"))
    untracked = bool(_require_git(root, "ls-files", "--others", "--exclude-standard"))
    dirty = tracked_dirty or untracked
    local = _require_git(root, "rev-parse", "HEAD")
    if fetch:
        code, _ = _git(root, "fetch", "--no-tags", "origin", "+refs/heads/main:refs/remotes/origin/main")
        if code:
            return SyncResult(repo_id, "UNAVAILABLE", "UNAVAILABLE", local)
    code, remote = _git(root, "rev-parse", "refs/remotes/origin/main")
    if code or not SHA.fullmatch(remote):
        return SyncResult(repo_id, "INVALID_REMOTE_REF", "SECURITY_BLOCKED", local)
    if local == remote:
        state = "DIRTY" if dirty else "CURRENT"
        return SyncResult(repo_id, state, "DIRTY" if dirty else "NO_CHANGE", local, remote)
    code, _ = _git(root, "merge-base", "--is-ancestor", local, remote)
    behind = code == 0
    code, _ = _git(root, "merge-base", "--is-ancestor", remote, local)
    ahead = code == 0
    if behind:
        if tracked_dirty:
            return SyncResult(repo_id, "DIRTY_BEHIND", "PENDING_RECONCILIATION", local, remote)
        before = "UNTRACKED_BEHIND" if untracked else "BEHIND_CLEAN"
        code, _ = _git(root, "merge", "--ff-only", "refs/remotes/origin/main")
        if code:
            # Git refuses a fast-forward that would overwrite an untracked
            # path.  Keep every local byte and require an explicit owner-led
            # reconciliation for that collision.
            result = "PENDING_RECONCILIATION" if untracked else "RECONCILIATION_REQUIRED"
            return SyncResult(repo_id, before, result, local, remote)
        return SyncResult(repo_id, before, "CURRENT", remote, remote)
    if ahead:
        return SyncResult(repo_id, "LOCAL_AHEAD", "RECONCILIATION_REQUIRED", local, remote)
    return SyncResult(repo_id, "DIVERGED", "RECONCILIATION_REQUIRED", local, remote)


def handle_event(workspace: Path, raw: bytes | str | dict[str, Any]) -> SyncResult:
    event = parse_event(raw)
    repo_id = event["repository_id"]
    profile = repository_profile(workspace)
    if repo_id == "pancracio-context":
        # A scope change intentionally makes the old manifest stale. Validate
        # its shape without demanding that it match the new catalog first.
        from .composition import _read_yaml
        from .context_manifest14 import validate_graph_manifest
        previous = _read_yaml(workspace / ".panky/context-manifest.yaml")
        if previous is None:
            raise SyncError("Context Manifest unavailable")
        validate_graph_manifest(previous)
        mode_path = workspace / ".panky/gateway-auth-mode"
        if mode_path.is_symlink():
            raise SyncError("Gateway authentication mode path is unsafe")
        if mode_path.is_file() and mode_path.read_text(encoding="utf-8").strip() == "oidc":
            from .composition14 import reconcile_graph_runtime14
            from .sync_transport import reconcile_transport
            profile = repository_profile(workspace)
            core = sync_mount(workspace, Mount(profile.core_id, workspace / "domains/core",
                                              profile.core_remote, "core"))
            if core.result not in {"CURRENT", "NO_CHANGE"}:
                raise SyncError("Core update must complete before scope reconciliation")
            outcome = reconcile_graph_runtime14(workspace)
            if outcome.get("status") == "REVOKED":
                return SyncResult(repo_id, "ACTOR_DISABLED", "REVOKED")
            if (workspace / ".panky/sync/transport.yaml").is_file():
                reconcile_transport(workspace)
        results = freshness(workspace)
        if any(row.result not in {"CURRENT", "NO_CHANGE", "DIRTY"} for row in results.values()):
            return SyncResult(repo_id, "GRAPH_FRESHNESS", "DEGRADED")
        return SyncResult(repo_id, "GRAPH_FRESHNESS", "CURRENT")
    mode_path = workspace / ".panky/gateway-auth-mode"
    if mode_path.is_symlink():
        raise SyncError("Gateway authentication mode path is unsafe")
    oidc_mode = mode_path.is_file() and mode_path.read_text(encoding="utf-8").strip() == "oidc"
    if oidc_mode and not PRIVATE_ID.fullmatch(repo_id):
        from .composition import _read_yaml
        metadata = _read_yaml(workspace / ".panky/sync/transport.yaml")
        if (not metadata or metadata.get("schema_version") != 2
                or repo_id not in metadata.get("subscriptions", {})):
            return SyncResult(repo_id, "UNKNOWN_REPOSITORY", "IGNORED")
    try:
        if repo_id == profile.core_id:
            _runtime_manifest(workspace)
            # Core remains fetchable when its previous graph pin needs reconciliation.
            mounts = {profile.core_id: Mount(profile.core_id, workspace / "domains/core", profile.core_remote, "core")}
        else:
            mounts = authorized_mounts(workspace)
    except (RegistryError, CompositionError) as exc:
        raise SyncError("protected Context View unavailable") from exc
    mount = mounts.get(repo_id)
    if mount is None:
        return SyncResult(repo_id, "UNAUTHORIZED_OR_UNMOUNTED", "IGNORED")
    return sync_mount(workspace, mount)



def freshness(workspace: Path) -> dict[str, SyncResult]:
    """Independent Git fallback over current graph mounts."""
    workspace = workspace.resolve()
    manifest = _runtime_manifest(workspace)
    profile = repository_profile(workspace)
    core_mount = Mount(profile.core_id, workspace / "domains/core", profile.core_remote, "core")
    core = sync_mount(workspace, core_mount)
    results = {core.repository_id: core}
    if core.result not in {"CURRENT", "NO_CHANGE"}:
        return results
    if manifest["core_commit"] != _require_git(workspace / "domains/core", "rev-parse", "refs/remotes/origin/main"):
        results[core.repository_id] = SyncResult(core.repository_id, core.before, "TOPOLOGY_RECONCILIATION_REQUIRED", core.local_head, core.remote_head)
        return results
    mounts = authorized_mounts(workspace)
    for repo_id, mount in mounts.items():
        if repo_id != profile.core_id:
            results[repo_id] = sync_mount(workspace, mount)
    return results
