"""Short, reviewable contextual onboarding over the same governed routing gate."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .context_manifest14 import verify_graph_manifest
from .identity import VerifiedActor
from .node_store14 import NodeStore, WriteResult
from .personal_store14 import PersonalWrite, add_personal_to_node
from .personal_topology14 import read_personal_topology
from .registry import CoreRegistry
from .routing14 import RoutingGate, RoutingProposal


class OnboardingBlocked(ValueError):
    pass


@dataclass(frozen=True)
class OnboardingUnit:
    title: str
    text: str
    proposal: RoutingProposal
    approved_for_persistence: bool = False
    state_kind: str = 'progress'


@dataclass(frozen=True)
class OnboardingReceipt:
    organizational: tuple[WriteResult, ...]
    personal: tuple[PersonalWrite, ...]
    ephemeral_count: int


TOPICS = frozenset({'function', 'work', 'personal'})


def next_question(actor: VerifiedActor, registry: CoreRegistry,
                  covered: frozenset[str] = frozenset()) -> tuple[str | None, str | None]:
    """Choose one conversational prompt from governed scope and prior answers.

    `covered` is a conversational observation, never an authority grant. The
    model may identify topics already answered, but cannot change Registry.
    """
    from .context_topology import topology_from_core
    if covered - TOPICS:
        raise OnboardingBlocked('unknown onboarding topic')
    graph = topology_from_core(registry)
    principals = graph.actor_principals(actor, registry)
    anchors = [anchor for anchor in graph.anchors if anchor.principal_id in principals]
    if not anchors:
        return (None, None) if 'personal' in covered else (
            'personal', 'Para empezar a conocerte, ¿qué cosas tuyas te gustaría contarme que puedan ayudarme a acompañarte?')
    seat_anchors = [anchor for anchor in anchors if anchor.principal_id.startswith('seat:')]
    if seat_anchors:
        ordered = ('work', 'personal')
        prompts = {
            'work': '¿En qué estás trabajando ahorita?',
            'personal': 'Fuera del trabajo, ¿hay algo tuyo que te gustaría que tenga presente cuando hablemos?',
        }
    else:
        domains = sorted({registry.topology_policy['nodes'][anchor.node_id]['display_name']
                          for anchor in anchors})
        organization = domains[0] if len(domains) == 1 else 'tus organizaciones'
        ordered = ('function', 'work', 'personal')
        prompts = {
            'function': f'Para conocerte un poco mejor, ¿qué haces tú en {organization}? Cuéntamelo como se lo contarías a alguien que acaba de llegar al equipo.',
            'work': '¿Y en qué cosas estás metido ahorita? Dime lo que tengas más presente.',
            'personal': f'Fuera de {organization}, ¿hay cosas tuyas que te gustaría que tenga presentes cuando hablemos?',
        }
    for topic in ordered:
        if topic not in covered:
            return topic, prompts[topic]
    return None, None


def questions(actor: VerifiedActor, registry: CoreRegistry) -> tuple[str, ...]:
    """Compatibility for callers: expose only the first turn, never a form."""
    _, prompt = next_question(actor, registry)
    return (prompt,) if prompt else ()


def start_turn(actor: VerifiedActor, registry: CoreRegistry, state: dict[str, Any]) -> dict[str, Any]:
    """Resume the same unanswered question or begin one short first turn."""
    if state.get('actor_id') != actor.actor_id or state.get('schema_version') != 1:
        raise OnboardingBlocked('onboarding state/Actor mismatch')
    status = state.get('status')
    if status == 'COMPLETE':
        return state
    if status == 'IN_PROGRESS':
        if not isinstance(state.get('question'), str) or not isinstance(state.get('topic'), str):
            raise OnboardingBlocked('incomplete onboarding turn state')
        return state
    if status != 'PENDING':
        raise OnboardingBlocked('unsupported onboarding state')
    topic, prompt = next_question(actor, registry)
    return {'schema_version': 1, 'actor_id': actor.actor_id, 'status': 'IN_PROGRESS',
            'covered_topics': [], 'topic': topic, 'question': prompt, 'turns': 0}


def advance_turn(actor: VerifiedActor, registry: CoreRegistry, state: dict[str, Any],
                 *, answer: str, covered_topics: frozenset[str], actor_done: bool = False,
                 clarification: str | None = None) -> dict[str, Any]:
    """Advance from a human answer; retain only progress metadata, not speech."""
    if state.get('actor_id') != actor.actor_id or state.get('status') != 'IN_PROGRESS':
        raise OnboardingBlocked('no active onboarding question for this Actor')
    if not isinstance(answer, str) or not answer.strip() or not isinstance(actor_done, bool):
        raise OnboardingBlocked('human answer and explicit completion signal required')
    if covered_topics - TOPICS or not isinstance(state.get('covered_topics'), list):
        raise OnboardingBlocked('invalid onboarding topics')
    if not clarification and not actor_done and state.get('topic') not in covered_topics:
        raise OnboardingBlocked('current conversational topic must be resolved or clarified')
    covered = frozenset(state['covered_topics']) | covered_topics
    if clarification is not None:
        if actor_done or not isinstance(clarification, str) or not clarification.strip():
            raise OnboardingBlocked('invalid clarification')
        if (clarification.count('?') != 1 or '\n' in clarification
                or any(word in clarification.lower() for word in ('persist', 'durader', 'almacen', 'schema', 'manifest'))):
            raise OnboardingBlocked('clarification must be one plain-language question')
        topic, prompt, status = state['topic'], clarification.strip(), 'IN_PROGRESS'
    elif actor_done:
        topic, prompt, status = None, None, 'COMPLETE'
    else:
        topic, prompt = next_question(actor, registry, covered)
        status = 'IN_PROGRESS' if prompt else 'COMPLETE'
    return {'schema_version': 1, 'actor_id': actor.actor_id, 'status': status,
            'covered_topics': sorted(covered), 'topic': topic, 'question': prompt,
            'turns': int(state.get('turns', 0)) + 1}


def commit_onboarding(workspace: Path, actor: VerifiedActor, registry: CoreRegistry,
                      manifest: dict[str, Any], expected_core_commit: str,
                      units: tuple[OnboardingUnit, ...]) -> OnboardingReceipt:
    """Validate all ownership decisions before the first persistent write.

    Each accepted unit is a separate bounded Git change. A later transport
    failure returns a concrete error; earlier confirmed commits remain valid.
    """
    verify_graph_manifest(manifest, actor, registry, expected_core_commit=expected_core_commit)
    if not 0 <= len(units) <= 20:
        raise OnboardingBlocked('onboarding units must be bounded')
    personal_graph = read_personal_topology(workspace, actor)
    personal_nodes = frozenset(node_id for node_id, row in personal_graph['nodes'].items()
                               if node_id != f'personal:{actor.actor_id}' and row['lifecycle'] == 'ACTIVE')
    gate = RoutingGate(registry, personal_nodes=personal_nodes)
    decisions = []
    for unit in units:
        if not unit.text.strip() or not unit.title.strip():
            raise OnboardingBlocked('onboarding unit needs title and content')
        if not isinstance(unit.approved_for_persistence, bool):
            raise OnboardingBlocked('specific confirmation flag must be boolean')
        decision = gate.decide(actor, unit.proposal)
        if decision.status not in {'EPHEMERAL', 'PERSIST'}:
            raise OnboardingBlocked(f'onboarding routing unresolved: {decision.status}')
        if (decision.status == 'PERSIST' and unit.proposal.crosses_personal_organization
                and not unit.approved_for_persistence):
            raise OnboardingBlocked('specific cross-boundary confirmation required')
        if decision.status == 'PERSIST' and decision.surface not in {'Knowledge', 'State'}:
            raise OnboardingBlocked('onboarding does not invent Work or Contributions')
        if decision.status == 'PERSIST' and unit.proposal.owner == 'personal' and decision.surface != 'Knowledge':
            raise OnboardingBlocked('Personal onboarding uses private General Knowledge')
        decisions.append(decision)
    store = NodeStore(workspace, actor, registry, manifest, expected_core_commit)
    organizational: list[WriteResult] = []
    personal: list[PersonalWrite] = []
    ephemeral = 0
    for unit, decision in zip(units, decisions):
        if decision.status == 'EPHEMERAL':
            ephemeral += 1
        elif unit.proposal.owner == 'personal':
            personal.append(add_personal_to_node(workspace, actor, registry, decision.node_id,
                                                 unit.title, unit.text, mode=manifest['personal']['mode']))
        elif decision.surface == 'Knowledge':
            organizational.append(store.add_knowledge(decision.node_id, unit.title, unit.text,
                                                       source='contextual onboarding'))
        else:
            organizational.append(store.add_state(decision.node_id, unit.text,
                                                   source='contextual onboarding', kind=unit.state_kind))
    return OnboardingReceipt(tuple(organizational), tuple(personal), ephemeral)
