"""Bounded Obsidian links over an already authorized set of clean notes."""

from __future__ import annotations

from collections import defaultdict
from pathlib import Path
import re


WIKILINK = re.compile(r"\[\[([^\]\n]+)\]\]")
MARKDOWN_LINK = re.compile(r"\[[^\]\n]*\]\(([^)\n]+\.md)(?:#[^)]*)?\)")


def related_notes(notes: list[Path], *, max_notes: int = 1000,
                  vault_root: Path | None = None) -> dict[Path, frozenset[Path]]:
    """Resolve links and backlinks only among paths the caller already admitted."""
    if len(notes) > max_notes:
        notes = notes[:max_notes]
    admitted = {path.resolve() for path in notes if path.suffix.casefold() == ".md"
                and path.is_file() and not path.is_symlink()}
    by_stem: dict[str, list[Path]] = defaultdict(list)
    by_vault_path: dict[str, Path] = {}
    by_absolute_stem = {path.with_suffix(''): path for path in admitted}
    for path in admitted:
        by_stem[path.stem.casefold()].append(path)
        if vault_root is not None and path.is_relative_to(vault_root.resolve()):
            by_vault_path[path.relative_to(vault_root.resolve()).with_suffix('').as_posix().casefold()] = path
    graph: dict[Path, set[Path]] = {path: set() for path in admitted}
    for source in admitted:
        content = source.read_text(encoding="utf-8", errors="replace")[:200_000]
        targets = [value.split("|", 1)[0].split("#", 1)[0].strip() for value in WIKILINK.findall(content)]
        targets.extend(MARKDOWN_LINK.findall(content))
        for target in targets:
            candidate = Path(target)
            if candidate.is_absolute() or ".." in candidate.parts:
                continue
            exact = by_vault_path.get(candidate.with_suffix('').as_posix().casefold())
            if exact is None and '/' in target:
                exact = by_absolute_stem.get(source.parent.joinpath(candidate).with_suffix(''))
            matches = [exact] if exact is not None else by_stem.get(candidate.stem.casefold(), [])
            # A qualified link must never fall back to an unrelated note that
            # happens to have the same filename in another context.
            if '/' in target and exact is None and vault_root is not None:
                matches = []
            if len(matches) != 1:
                continue
            linked = matches[0]
            if linked != source:
                graph[source].add(linked)
                graph[linked].add(source)
    return {path: frozenset(neighbors) for path, neighbors in graph.items()}
