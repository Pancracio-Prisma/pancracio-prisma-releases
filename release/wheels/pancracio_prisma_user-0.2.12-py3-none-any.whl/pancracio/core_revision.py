"""Recognize a Core fast-forward that cannot alter runtime authority."""

from __future__ import annotations

from pathlib import Path
import re
import subprocess

from .processes import background_creationflags
from .git_transport import git_environment


SHA = re.compile(r"[0-9a-f]{40}\Z")


def operational_only_advance(core: Path, bound: str, current: str) -> bool:
    """Accept only an ancestor fast-forward confined to operational files.

    Registry, policy, schemas, identity, and any new top-level area fail closed.
    This is a local Git check, never a grant of access or a publication proof.
    """
    if not isinstance(bound, str) or not isinstance(current, str):
        return False
    if not SHA.fullmatch(bound) or not SHA.fullmatch(current) or bound == current:
        return False
    base = ["git", "-C", str(core)]
    flags = background_creationflags()
    environment = git_environment(core)
    try:
        ancestor = subprocess.run(
            [*base, "merge-base", "--is-ancestor", bound, current],
            capture_output=True, creationflags=flags, env=environment, timeout=10,
        )
        if ancestor.returncode != 0:
            return False
        diff = subprocess.run(
            [*base, "diff", "--quiet", bound, current, "--", ".",
             ":(exclude).github/workflows", ":(exclude)scripts", ":(exclude)tests"],
            capture_output=True, creationflags=flags, env=environment, timeout=10,
        )
        return diff.returncode == 0
    except (OSError, subprocess.TimeoutExpired):
        return False
