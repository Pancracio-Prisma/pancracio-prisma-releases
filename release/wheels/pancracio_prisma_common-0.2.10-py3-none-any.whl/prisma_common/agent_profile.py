"""Operator-signed, instance-bound display name changes.

The original installation binding stays immutable. A profile revision changes
presentation only; it cannot change resources, identities, or capabilities.
"""

from __future__ import annotations

import base64
import binascii
import json
from pathlib import Path
from typing import Any

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

from .intake import SetupInputError, load_json
from .trusted_binding import canonical_bytes


def valid_display_name(value: Any) -> str:
    if (not isinstance(value, str) or not 2 <= len(value) <= 80
            or value != value.strip()
            or any(ord(char) < 32 or ord(char) == 127 for char in value)):
        raise SetupInputError("agent display name is invalid")
    return value


def verify_agent_profile(path: Path, *, pinned_public_key: bytes,
                         tenant_slug: str, instance_id: str) -> dict[str, Any]:
    envelope = load_json(path)
    if not isinstance(envelope, dict) or set(envelope) != {"payload", "signature"}:
        raise SetupInputError("agent profile envelope is invalid")
    payload = envelope["payload"]
    if (not isinstance(payload, dict) or set(payload) != {
            "schema_version", "tenant_slug", "instance_id", "revision", "display_name"}
            or payload["schema_version"] != 1
            or payload["tenant_slug"] != tenant_slug
            or payload["instance_id"] != instance_id
            or type(payload["revision"]) is not int or payload["revision"] < 1):
        raise SetupInputError("agent profile is for another instance or revision")
    valid_display_name(payload["display_name"])
    if not isinstance(envelope["signature"], str) or len(pinned_public_key) != 32:
        raise SetupInputError("agent profile signature is invalid")
    try:
        signature = base64.b64decode(envelope["signature"], validate=True)
        if len(signature) != 64:
            raise ValueError("signature length")
        Ed25519PublicKey.from_public_bytes(pinned_public_key).verify(
            signature, canonical_bytes(payload))
    except (ValueError, binascii.Error, InvalidSignature) as exc:
        raise SetupInputError("agent profile signature is invalid") from exc
    return payload


def profile_bytes(*, private_key: Any, tenant_slug: str, instance_id: str,
                  revision: int, display_name: str) -> bytes:
    valid_display_name(display_name)
    if type(revision) is not int or revision < 1:
        raise SetupInputError("agent profile revision is invalid")
    payload = {"schema_version": 1, "tenant_slug": tenant_slug,
               "instance_id": instance_id, "revision": revision,
               "display_name": display_name}
    signature = base64.b64encode(private_key.sign(canonical_bytes(payload))).decode("ascii")
    return (json.dumps({"payload": payload, "signature": signature},
                       indent=2, ensure_ascii=False) + "\n").encode("utf-8")
