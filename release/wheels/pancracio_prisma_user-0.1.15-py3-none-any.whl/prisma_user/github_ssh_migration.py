"""Guided GitHub CLI adapter for the verified per-Actor SSH migration."""

from __future__ import annotations

import base64
import hashlib
import json
import os
from pathlib import Path
import re
import shlex
import shutil
import subprocess
import sys
from uuid import uuid4
from typing import Any, Callable

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

from .ssh_transport import SSHTransportError, stage_ssh_transport
from prisma_common.installed_binding import runtime_directory


def chrome_user_data_root(*, platform: str, home: Path | None = None,
                          local_appdata: Path | None = None) -> Path:
    if platform == "macos":
        return (home or Path.home()) / "Library" / "Application Support" / "Google" / "Chrome"
    if platform == "windows":
        appdata = local_appdata or (Path(os.environ["LOCALAPPDATA"])
                                    if os.environ.get("LOCALAPPDATA") else None)
        if appdata is None:
            raise SSHTransportError("Chrome profile storage is unavailable")
        return appdata / "Google" / "Chrome" / "User Data"
    raise SSHTransportError("Chrome profile sign-in is supported on macOS and Windows")


def list_chrome_profiles(*, platform: str, home: Path | None = None,
                         local_appdata: Path | None = None) -> list[tuple[str, str]]:
    root = chrome_user_data_root(platform=platform, home=home,
                                 local_appdata=local_appdata)
    local_state = root / "Local State"
    if local_state.is_symlink() or not local_state.is_file():
        return []
    try:
        state = json.loads(local_state.read_text(encoding="utf-8"))
        cache = state["profile"]["info_cache"]
    except (OSError, ValueError, KeyError, TypeError) as exc:
        raise SSHTransportError("Chrome profile list is invalid") from exc
    if not isinstance(cache, dict):
        raise SSHTransportError("Chrome profile list is invalid")
    rows = []
    for directory, details in cache.items():
        if (not isinstance(directory, str) or directory in {".", ".."}
                or "/" in directory or "\\" in directory or not isinstance(details, dict)):
            continue
        if not (root / directory).is_dir():
            continue
        label = details.get("name")
        if not isinstance(label, str) or not label.strip():
            label = directory
        rows.append((directory, label.strip()))
    return sorted(rows, key=lambda row: row[1].casefold())


def chrome_browser_command(profile_directory: str, *, platform: str,
                           home: Path | None = None,
                           local_appdata: Path | None = None,
                           environ: dict[str, str] | None = None) -> str:
    if (not isinstance(profile_directory, str) or not profile_directory
            or "/" in profile_directory or "\\" in profile_directory):
        raise SSHTransportError("selected Chrome profile is invalid")
    if platform == "macos":
        args = ["/usr/bin/open", "-na", "Google Chrome", "--args",
                f"--profile-directory={profile_directory}"]
        return shlex.join(args)
    if platform == "windows":
        variables = environ if environ is not None else os.environ
        candidates = [Path(variables[name]) / "Google" / "Chrome" / "Application" / "chrome.exe"
                      for name in ("PROGRAMFILES", "PROGRAMFILES(X86)") if variables.get(name)]
        if local_appdata is not None:
            candidates.append(local_appdata / "Google" / "Chrome" / "Application" / "chrome.exe")
        chrome = next((candidate for candidate in candidates if candidate.is_file()), None)
        if chrome is None:
            raise SSHTransportError("Google Chrome is unavailable")
        return shlex.join([chrome.as_posix(), f"--profile-directory={profile_directory}"])
    raise SSHTransportError("Chrome profile sign-in is supported on macOS and Windows")


def choose_chrome_profile(*, platform: str, home: Path | None = None,
                          local_appdata: Path | None = None,
                          selected_profile: str | None = None) -> str:
    profiles = list_chrome_profiles(platform=platform, home=home,
                                    local_appdata=local_appdata)
    if not profiles:
        raise SSHTransportError("no Chrome profiles were found for GitHub sign-in")
    if selected_profile is not None:
        selected = [row for row in profiles
                    if row[0].casefold() == selected_profile.casefold()
                    or row[1].casefold() == selected_profile.casefold()]
        if len(selected) != 1:
            raise SSHTransportError("selected Chrome profile was not found")
        directory = selected[0][0]
        return chrome_browser_command(directory, platform=platform, home=home,
                                      local_appdata=local_appdata)
    if not sys.stdin.isatty():
        raise SSHTransportError("interactive Chrome profile selection is required for GitHub sign-in")
    print("Select the Chrome profile that is signed in to the Core-assigned GitHub account:")
    for index, (_directory, label) in enumerate(profiles, start=1):
        print(f"{index}. {label}")
    selection = input("Profile number: ").strip()
    if not selection.isdigit() or not 1 <= int(selection) <= len(profiles):
        raise SSHTransportError("Chrome profile selection is required")
    directory, _label = profiles[int(selection) - 1]
    return chrome_browser_command(directory, platform=platform, home=home,
                                  local_appdata=local_appdata)


class GitHubCLIAdapter:
    """Use an already authenticated `gh` account; never print command output."""

    def __init__(self, *, run: Callable[..., Any] = subprocess.run,
                 which: Callable[[str], str | None] = shutil.which,
                 workspace: Path | None = None,
                 platform: str | None = None,
                 home: Path | None = None,
                 local_appdata: Path | None = None,
                 profile_selector: Callable[..., str] | None = None,
                 chrome_profile: str | None = None) -> None:
        self._run = run
        self._which = which
        self._workspace = workspace
        self._platform = platform or ("windows" if os.name == "nt" else "macos" if sys.platform == "darwin" else "unsupported")
        self._home = home
        self._local_appdata = local_appdata
        self._chrome_profile = chrome_profile
        self._profile_selector = profile_selector or choose_chrome_profile
        self._environment: dict[str, str] | None = None
        self._verified_login: str | None = None
        if workspace is None:
            raise SSHTransportError("instance-scoped GitHub CLI configuration is required")
        try:
            _, runtime = runtime_directory(workspace, home=home,
                                           local_appdata=local_appdata,
                                           platform=self._platform)
        except (OSError, ValueError) as exc:
            raise SSHTransportError("instance runtime is unavailable for GitHub sign-in") from exc
        config = runtime / "github-cli"
        if config.is_symlink():
            raise SSHTransportError("instance GitHub CLI configuration is unsafe")
        config.mkdir(mode=0o700, parents=True, exist_ok=True)
        if not config.is_dir():
            raise SSHTransportError("instance GitHub CLI configuration is unavailable")
        if os.name != "nt":
            config.chmod(0o700)
        self._environment = os.environ.copy()
        self._environment["GH_CONFIG_DIR"] = str(config)

    def _command(self, args: tuple[str, ...], *, login: bool = False) -> Any:
        if self._which("gh") is None:
            raise SSHTransportError("GitHub CLI is unavailable in this instance; installation is blocked")
        try:
            return self._run(["gh", *args], capture_output=not login, text=True,
                             check=False, timeout=300 if login else 30,
                             env=self._environment)
        except (OSError, subprocess.SubprocessError) as exc:
            raise SSHTransportError("GitHub CLI operation failed") from exc

    def _ensure_authenticated(self) -> None:
        status = self._command(("auth", "status", "--hostname", "github.com"))
        if status.returncode == 0:
            return
        if not sys.stdin.isatty():
            raise SSHTransportError("this instance has no GitHub sign-in; interactive Chrome profile selection is required")
        browser = self._profile_selector(platform=self._platform, home=self._home,
                                         local_appdata=self._local_appdata,
                                         selected_profile=self._chrome_profile)
        login_env = dict(self._environment)
        login_env["GH_BROWSER"] = browser
        try:
            login = self._run(["gh", "auth", "login", "--hostname", "github.com",
                               "--web", "--git-protocol", "https",
                               "--scopes", "admin:public_key"],
                              capture_output=False, text=True, check=False,
                              timeout=600, env=login_env)
        except (OSError, subprocess.SubprocessError) as exc:
            raise SSHTransportError("GitHub web sign-in could not be completed") from exc
        if login.returncode:
            raise SSHTransportError("GitHub web sign-in did not complete")
        status = self._command(("auth", "status", "--hostname", "github.com"))
        if status.returncode:
            raise SSHTransportError("GitHub web sign-in is not active for this instance")

    def _gh(self, *args: str) -> str:
        result = self._command(args)
        if result.returncode:
            raise SSHTransportError("GitHub CLI authentication or authorization failed")
        return result.stdout.strip()

    def identity_lookup(self) -> dict[str, str]:
        self._ensure_authenticated()
        login = self._gh("api", "user", "--jq", ".login")
        if not re.fullmatch(r"[A-Za-z0-9](?:[A-Za-z0-9-]{0,37}[A-Za-z0-9])?", login):
            raise SSHTransportError("GitHub CLI returned an invalid account identity")
        self._verified_login = login
        return {"login": login}

    def add_public_key(self, public_key: str, title: str) -> bool:
        # The key is public material. Private key bytes never enter this adapter.
        raw = self._gh("api", "--method", "POST", "user/keys",
                       "-f", f"title={title}", "-f", f"key={public_key}")
        try:
            response = json.loads(raw)
        except ValueError as exc:
            raise SSHTransportError("GitHub did not return a verified SSH key record") from exc
        return (isinstance(response, dict) and response.get("key") == public_key
                and response.get("title") == title and isinstance(response.get("id"), int))

    def verify_ssh_identity(self, command: list[str]) -> str:
        try:
            result = self._run([*command, "-T", "git@github.com"], capture_output=True,
                               text=True, check=False, timeout=20)
        except (OSError, subprocess.SubprocessError) as exc:
            raise SSHTransportError("GitHub SSH identity check failed") from exc
        greeting = re.findall(r"(?:^|\n)Hi ([A-Za-z0-9-]+)!", result.stdout + result.stderr)
        if result.returncode not in {0, 1} or len(greeting) != 1:
            raise SSHTransportError("the new SSH key did not identify one GitHub account")
        return greeting[0]

    @staticmethod
    def _invitation_rows(raw: str) -> list[dict[str, Any]]:
        try:
            data = json.loads(raw)
        except ValueError as exc:
            raise SSHTransportError("GitHub repository invitations are unavailable") from exc
        # `gh api --paginate --slurp` returns one array of page arrays.
        if isinstance(data, list) and all(isinstance(page, list) for page in data):
            return [row for page in data for row in page]
        if isinstance(data, list):
            return data
        raise SSHTransportError("GitHub repository invitation response is invalid")

    def _accept_authorized_invitations(self, repositories: list[str]) -> None:
        expected_login = self._verified_login
        if expected_login is None:
            expected_login = self.identity_lookup()["login"]
        rows = self._invitation_rows(self._gh(
            "api", "--paginate", "--slurp", "user/repository_invitations"))
        by_name = {name.casefold(): name for name in repositories}
        for row in rows:
            repo = row.get("repository") if isinstance(row, dict) else None
            full_name = repo.get("full_name") if isinstance(repo, dict) else None
            invitee = row.get("invitee") if isinstance(row, dict) else None
            invitee_login = invitee.get("login") if isinstance(invitee, dict) else None
            invitation_id = row.get("id") if isinstance(row, dict) else None
            if not isinstance(full_name, str) or full_name.casefold() not in by_name:
                continue
            if (not isinstance(invitee_login, str)
                    or invitee_login.casefold() != expected_login.casefold()):
                raise SSHTransportError(
                    "authorized GitHub invitation does not match the Core-assigned account")
            if isinstance(invitation_id, bool) or not isinstance(invitation_id, int) or invitation_id < 1:
                raise SSHTransportError("authorized GitHub invitation record is invalid")
            self._gh("api", "--method", "PATCH",
                     f"user/repository_invitations/{invitation_id}")

    def verify_repository_access(self, command: list[str], repositories: list[str],
                                 required_write_repositories: list[str]) -> dict[str, Any]:
        self._accept_authorized_invitations(repositories)
        env = os.environ.copy()
        env["GIT_TERMINAL_PROMPT"] = "0"
        env["GIT_SSH_COMMAND"] = shlex.join(command)
        rows = []
        for repository in repositories:
            try:
                result = self._run(["git", "ls-remote", f"git@github.com:{repository}.git", "HEAD"],
                                   capture_output=True, text=True, check=False, timeout=30, env=env)
            except (OSError, subprocess.SubprocessError) as exc:
                raise SSHTransportError("authorized repository SSH check failed") from exc
            reachable = result.returncode == 0 and bool(result.stdout.strip())
            permissions = self._gh("api", f"repos/{repository}", "--jq", ".permissions.push")
            if permissions not in {"true", "false"}:
                raise SSHTransportError("GitHub repository permission response is invalid")
            rows.append({"repository": repository, "reachable": reachable,
                         "writable": permissions == "true"})
        return {"repositories": rows}


def migrate_instance_ssh(workspace: Path, *, adapter: GitHubCLIAdapter | None = None,
                         chrome_profile: str | None = None) -> dict[str, str]:
    """Resolve trusted transition + mounts, then register and activate this Actor key."""
    workspace = workspace.resolve(strict=True)
    from pancracio.poc_exit import refresh_pending
    transition = refresh_pending(workspace)
    if transition.get("status") != "GITHUB_MIGRATION_REQUIRED":
        raise SSHTransportError("this Actor has no verified pending GitHub migration")
    actor_id = transition.get("actor_id")
    expected_login = transition.get("github_login")
    core_commit = transition.get("core_commit")
    if (not isinstance(actor_id, str) or not isinstance(expected_login, str)
            or not isinstance(core_commit, str)
            or not re.fullmatch(r"[0-9a-f]{40}", core_commit)):
        raise SSHTransportError("verified Core GitHub assignment is unavailable")
    recovery = _recover_pending_ack(workspace, actor_id=actor_id,
                                    login=expected_login, core_commit=core_commit)
    if recovery is not None:
        return recovery
    from pancracio.context_sync import authorized_mounts
    mounts = authorized_mounts(workspace)
    repositories = sorted({
        mount.remote[len("git@github.com:"):-4]
        for mount in mounts.values()
        if isinstance(getattr(mount, "remote", None), str)
        and mount.remote.startswith("git@github.com:") and mount.remote.endswith(".git")
    })
    if not repositories or len(repositories) != len(mounts):
        raise SSHTransportError("verified mount map contains unsupported Git remotes")
    private_repositories = []
    for mount in mounts.values():
        if getattr(mount, "kind", None) != "actor_private":
            continue
        remote = getattr(mount, "remote", None)
        if not isinstance(remote, str) or not remote.startswith("git@github.com:") or not remote.endswith(".git"):
            raise SSHTransportError("Actor-private repository remote is invalid")
        repository = remote[len("git@github.com:"):-4]
        owner = repository.split("/", 1)[0]
        if owner.casefold() != expected_login.casefold():
            raise SSHTransportError("Actor-private repository must belong to the Core-assigned GitHub account")
        private_repositories.append(repository)
    client = adapter or GitHubCLIAdapter(workspace=workspace,
                                         chrome_profile=chrome_profile)
    result = stage_ssh_transport(
        workspace, expected_actor_id=actor_id, expected_login=expected_login,
        expected_repositories=repositories, required_write_repositories=private_repositories,
        authorized_mounts=lambda _workspace: mounts,
        identity_lookup=client.identity_lookup, add_public_key=client.add_public_key,
        verify_ssh_identity=client.verify_ssh_identity,
        verify_repository_access=client.verify_repository_access,
        verified_core_commit=core_commit,
        verified_repositories=repositories, activate=False)
    runtime_id = transition.get("runtime_id")
    if not isinstance(runtime_id, str) or not runtime_id:
        raise SSHTransportError("verified runtime identity is unavailable")
    manifest = _read_workspace_manifest(workspace)
    personal_mode, personal_repository = _personal_binding(mounts, manifest)
    public_key = Path(result["public_key_path"]).read_text(encoding="ascii").strip()
    from pancracio.context_catalog20 import (acknowledge_poc_transport,
                                            request_poc_transport_challenge)
    challenge = request_poc_transport_challenge(
        workspace / ".panky", runtime_id=runtime_id, public_key=public_key,
        personal_mode=personal_mode, personal_repository=personal_repository)
    payload = _validate_challenge(challenge, actor_id=actor_id, runtime_id=runtime_id,
                                  core_commit=core_commit, public_key=public_key,
                                  repositories=repositories, personal_mode=personal_mode,
                                  personal_repository=personal_repository,
                                  expected_login=expected_login,
                                  client_attested_repositories=private_repositories)
    signature = _sign_challenge(Path(result["private_key_path"]), payload)
    _save_pending_ack(Path(result["active_pointer"]).parent,
                      runtime_id=runtime_id, nonce=challenge["nonce"],
                      signature=signature, request_id=challenge["request_id"],
                      core_commit=core_commit,
                      fingerprint=challenge["public_key_fingerprint"],
                      client_attested=private_repositories)
    _activate_pending_pointer(Path(result["staged_pointer"]), Path(result["active_pointer"]))
    receipt = acknowledge_poc_transport(workspace / ".panky", runtime_id=runtime_id,
                                        nonce=challenge["nonce"], signature=signature)
    client_attested = receipt.get("client_attested_repositories")
    if (set(receipt) != {"status", "runtime_id", "transition_core_commit",
                         "key_fingerprint", "client_attested_repositories"}
            or receipt.get("status") != "acknowledged" or receipt.get("runtime_id") != runtime_id
            or receipt.get("transition_core_commit") != core_commit
            or receipt.get("key_fingerprint") != challenge["public_key_fingerprint"]
            or client_attested != private_repositories):
        raise SSHTransportError("Gateway migration acknowledgement does not match this instance")
    _mark_pointer_individual(Path(result["active_pointer"]), request_id=challenge["request_id"])
    _clear_pending_ack(Path(result["active_pointer"]).parent)
    pending = workspace / ".panky" / "sync" / "poc-exit-pending.json"
    if pending.is_symlink():
        raise SSHTransportError("migration prompt path is unsafe")
    pending.unlink(missing_ok=True)
    return {**result, "status": "SSH_KEY_ACTIVE", "gateway_transport_mode": "individual",
            "gateway_acknowledged": "true",
            "client_attested_repositories": ",".join(private_repositories)}


def verified_migration_status(workspace: Path, transition: dict[str, Any]) -> dict[str, Any]:
    """Report migrated only when this instance key matches trusted Core state."""
    if transition.get("status") != "GITHUB_MIGRATION_REQUIRED":
        return transition
    actor_id, login, core_commit = (transition.get("actor_id"),
                                    transition.get("github_login"),
                                    transition.get("core_commit"))
    if (not isinstance(actor_id, str) or not isinstance(login, str)
            or not isinstance(core_commit, str)
            or not re.fullmatch(r"[0-9a-f]{40}", core_commit)):
        return transition
    from prisma_common.installed_binding import load_installed_binding, runtime_directory
    from pancracio.composition import _read_yaml
    try:
        instance, runtime = runtime_directory(workspace)
        binding = load_installed_binding(workspace)
        pointer = runtime / "github-ssh-active.json"
        if pointer.is_symlink() or not pointer.is_file():
            return transition
        active = json.loads(pointer.read_text(encoding="utf-8"))
        owner = _read_yaml(workspace / ".panky" / "owner.yaml")
        if (not isinstance(active, dict)
                or set(active) != {"schema_version", "instance_id", "actor_id", "login", "core_commit", "repositories", "private_key", "gateway_mode", "gateway_request_id"}
                or active.get("schema_version") != 1
                or active.get("instance_id") != instance
                or active.get("instance_id") != binding.get("instance_id")
                or active.get("actor_id") != actor_id
                or not isinstance(owner, dict) or owner.get("actor_id") != actor_id
                or not isinstance(active.get("login"), str)
                or active["login"].casefold() != login.casefold()
                or active.get("core_commit") != core_commit
                or active.get("repositories") != _current_repositories(workspace)
                or active.get("gateway_mode") != "individual"
                or not isinstance(active.get("gateway_request_id"), str)
                or not active["gateway_request_id"]
                or not isinstance(active.get("private_key"), str)
                or Path(active["private_key"]).name != active["private_key"]):
            return transition
        key = runtime / active["private_key"]
        if key.is_symlink() or not key.is_file():
            return transition
        pending = workspace / ".panky" / "sync" / "poc-exit-pending.json"
        if pending.is_symlink():
            raise SSHTransportError("migration prompt path is unsafe")
        pending.unlink(missing_ok=True)
        return {**transition, "status": "GITHUB_MIGRATED", "active_key_verified": True}
    except (OSError, ValueError):
        return transition


def _current_repositories(workspace: Path) -> list[str]:
    from pancracio.context_sync import authorized_mounts
    mounts = authorized_mounts(workspace)
    repositories = sorted({mount.remote[len("git@github.com:"):-4]
                           for mount in mounts.values()
                           if isinstance(getattr(mount, "remote", None), str)
                           and mount.remote.startswith("git@github.com:")
                           and mount.remote.endswith(".git")})
    if not repositories or len(repositories) != len(mounts):
        raise SSHTransportError("verified mount map contains unsupported Git remotes")
    return repositories


def _read_workspace_manifest(workspace: Path) -> dict[str, Any]:
    from pancracio.composition import _read_yaml
    manifest = _read_yaml(workspace / ".panky" / "context-manifest.yaml")
    if not isinstance(manifest, dict) or not isinstance(manifest.get("personal"), dict):
        raise SSHTransportError("verified Context Manifest is unavailable")
    return manifest


def _personal_binding(mounts: dict[str, Any], manifest: dict[str, Any]) -> tuple[str, str | None]:
    mode = manifest["personal"].get("mode")
    private_mounts = [mount for mount in mounts.values()
                      if getattr(mount, "kind", None) == "actor_private"]
    if mode == "local":
        if private_mounts:
            raise SSHTransportError("local Personal mode unexpectedly has a remote Actor mount")
        return "local", None
    if mode != "private" or len(private_mounts) != 1:
        raise SSHTransportError("remote Personal mode does not match the verified Actor mount")
    remote = private_mounts[0].remote
    if not isinstance(remote, str) or not remote.startswith("git@github.com:") or not remote.endswith(".git"):
        raise SSHTransportError("remote Personal repository is invalid")
    return "remote", remote[len("git@github.com:"):-4]


def _validate_challenge(challenge: dict[str, Any], *, actor_id: str, runtime_id: str,
                        core_commit: str, public_key: str, repositories: list[str],
                        personal_mode: str, personal_repository: str | None,
                        expected_login: str,
                        client_attested_repositories: list[str]) -> bytes:
    rows = challenge.get("repositories")
    if (not isinstance(rows, list)
            or any(not isinstance(row, dict) or set(row) != {"repository", "permission"}
                   or not isinstance(row["repository"], str)
                   or row["permission"] not in {"read", "write"} for row in rows)):
        raise SSHTransportError("Gateway migration repository report is invalid")
    names = [row["repository"] for row in rows]
    if len(set(names)) != len(names) or sorted(names) != sorted(repositories):
        raise SSHTransportError("Gateway repository report differs from verified local mounts")
    if (not isinstance(challenge.get("client_attested_repositories"), list)
            or challenge["client_attested_repositories"] != client_attested_repositories):
        raise SSHTransportError("Gateway personal repository attestation differs from local checks")
    if personal_mode == "remote":
        personal_row = next((row for row in rows if row["repository"] == personal_repository), None)
        if personal_row is None or personal_row["permission"] != "write":
            raise SSHTransportError("Gateway did not verify write access to remote Personal")
    try:
        key_blob = base64.b64decode(public_key.split()[1], validate=True)
    except (IndexError, ValueError) as exc:
        raise SSHTransportError("staged SSH public key is invalid") from exc
    fingerprint = "SHA256:" + base64.b64encode(hashlib.sha256(key_blob).digest()).decode("ascii").rstrip("=")
    if challenge.get("public_key_fingerprint") != fingerprint:
        raise SSHTransportError("Gateway challenge fingerprint differs from the staged key")
    if (challenge.get("transition_core_commit") != core_commit
            or challenge.get("github_login") != expected_login
            or not isinstance(challenge.get("github_key_id"), (int, str))):
        raise SSHTransportError("Gateway challenge differs from the Core-assigned GitHub account")
    payload_text = challenge.get("signing_payload")
    try:
        payload = json.loads(payload_text)
    except (TypeError, ValueError) as exc:
        raise SSHTransportError("Gateway challenge signing payload is invalid") from exc
    expected = {
        "domain": "panky-poc-exit-installation-v1", "actor_id": actor_id,
        "runtime_id": runtime_id, "request_id": challenge.get("request_id"),
        "transition_core_commit": core_commit, "personal_mode": personal_mode,
        "personal_repository": personal_repository,
        "public_key_fingerprint": fingerprint, "github_login": expected_login,
        "github_key_id": challenge.get("github_key_id"), "repositories": rows,
        "client_attested_repositories": client_attested_repositories,
        "nonce": challenge.get("nonce"),
    }
    canonical = json.dumps(expected, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    if (not isinstance(challenge.get("request_id"), str) or not challenge["request_id"]
            or not isinstance(challenge.get("nonce"), str) or not challenge["nonce"]
            or payload != expected or payload_text != canonical):
        raise SSHTransportError("Gateway challenge payload does not match the verified migration")
    return payload_text.encode("utf-8")


def _sign_challenge(private_key_path: Path, payload: bytes) -> str:
    try:
        private = serialization.load_ssh_private_key(private_key_path.read_bytes(), password=None)
    except (OSError, ValueError) as exc:
        raise SSHTransportError("instance SSH signing key is unavailable") from exc
    if not isinstance(private, Ed25519PrivateKey):
        raise SSHTransportError("instance SSH signing key has the wrong type")
    return base64.urlsafe_b64encode(private.sign(payload)).decode("ascii").rstrip("=")


def _activate_pending_pointer(staged: Path, active: Path) -> None:
    if (staged.is_symlink() or not staged.is_file() or active.is_symlink()
            or staged.parent.resolve() != active.parent.resolve()):
        raise SSHTransportError("instance SSH pointer staging is unsafe")
    try:
        record = json.loads(staged.read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        raise SSHTransportError("instance SSH pointer staging is invalid") from exc
    if not isinstance(record, dict) or record.get("gateway_mode") != "pending":
        raise SSHTransportError("instance SSH pointer is not pending Gateway acknowledgement")
    os.replace(staged, active)


def _mark_pointer_individual(pointer: Path, *, request_id: str) -> None:
    if pointer.is_symlink() or not pointer.is_file():
        raise SSHTransportError("instance SSH active pointer is unavailable")
    try:
        active = json.loads(pointer.read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        raise SSHTransportError("instance SSH active pointer is invalid") from exc
    expected = {"schema_version", "instance_id", "actor_id", "login", "core_commit",
                "repositories", "gateway_mode", "gateway_request_id", "private_key"}
    if not isinstance(active, dict) or set(active) != expected or active.get("gateway_mode") != "pending":
        raise SSHTransportError("instance SSH pointer cannot be marked acknowledged")
    active["gateway_mode"] = "individual"
    active["gateway_request_id"] = request_id
    temporary = pointer.with_name(f".{pointer.name}.{uuid4().hex}.tmp")
    try:
        with temporary.open("x", encoding="utf-8") as stream:
            json.dump(active, stream, sort_keys=True)
            stream.write("\n")
        if os.name != "nt":
            temporary.chmod(0o600)
        os.replace(temporary, pointer)
    finally:
        temporary.unlink(missing_ok=True)


def _save_pending_ack(runtime: Path, *, runtime_id: str, nonce: str, signature: str,
                      request_id: str, core_commit: str, fingerprint: str,
                      client_attested: list[str]) -> Path:
    path = runtime / "poc-exit-ack-pending.json"
    if path.is_symlink():
        raise SSHTransportError("Gateway acknowledgement recovery state is unsafe")
    record = {"schema_version": 1, "runtime_id": runtime_id, "nonce": nonce,
              "signature": signature, "request_id": request_id,
              "core_commit": core_commit, "fingerprint": fingerprint,
              "client_attested_repositories": client_attested}
    temporary = runtime / f".poc-exit-ack-{uuid4().hex}.tmp"
    try:
        with temporary.open("x", encoding="utf-8") as stream:
            json.dump(record, stream, sort_keys=True)
            stream.write("\n")
        if os.name != "nt":
            temporary.chmod(0o600)
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)
    return path


def _clear_pending_ack(runtime: Path) -> None:
    path = runtime / "poc-exit-ack-pending.json"
    if path.is_symlink():
        raise SSHTransportError("Gateway acknowledgement recovery state is unsafe")
    path.unlink(missing_ok=True)


def _recover_pending_ack(workspace: Path, *, actor_id: str, login: str,
                         core_commit: str) -> dict[str, str] | None:
    from prisma_common.installed_binding import runtime_directory
    try:
        _instance, runtime = runtime_directory(workspace)
    except (OSError, ValueError):
        return None
    state = runtime / "poc-exit-ack-pending.json"
    if not state.exists():
        return None
    pointer = runtime / "github-ssh-active.json"
    if state.is_symlink() or not state.is_file() or pointer.is_symlink() or not pointer.is_file():
        raise SSHTransportError("Gateway acknowledgement recovery state is unsafe")
    try:
        record = json.loads(state.read_text(encoding="utf-8"))
        active = json.loads(pointer.read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        raise SSHTransportError("Gateway acknowledgement recovery state is invalid") from exc
    required = {"schema_version", "runtime_id", "nonce", "signature", "request_id",
                "core_commit", "fingerprint", "client_attested_repositories"}
    if (not isinstance(record, dict) or set(record) != required
            or record.get("schema_version") != 1 or record.get("core_commit") != core_commit
            or not isinstance(active, dict) or active.get("gateway_mode") != "pending"
            or active.get("actor_id") != actor_id
            or not isinstance(active.get("login"), str)
            or active["login"].casefold() != login.casefold()
            or active.get("core_commit") != core_commit
            or active.get("repositories") != _current_repositories(workspace)
            or active.get("private_key") not in {path.name for path in runtime.iterdir() if path.is_file()}):
        raise SSHTransportError("pending Gateway acknowledgement differs from active instance")
    from pancracio.context_catalog20 import acknowledge_poc_transport
    receipt = acknowledge_poc_transport(workspace / ".panky", runtime_id=record["runtime_id"],
                                        nonce=record["nonce"], signature=record["signature"])
    if (set(receipt) != {"status", "runtime_id", "transition_core_commit",
                         "key_fingerprint", "client_attested_repositories"}
            or receipt.get("status") != "acknowledged"
            or receipt.get("runtime_id") != record["runtime_id"]
            or receipt.get("transition_core_commit") != core_commit
            or receipt.get("key_fingerprint") != record["fingerprint"]
            or receipt.get("client_attested_repositories") != record["client_attested_repositories"]):
        raise SSHTransportError("Gateway acknowledgement recovery could not be verified")
    _mark_pointer_individual(pointer, request_id=record["request_id"])
    _clear_pending_ack(runtime)
    pending = workspace / ".panky" / "sync" / "poc-exit-pending.json"
    if pending.is_symlink():
        raise SSHTransportError("migration prompt path is unsafe")
    pending.unlink(missing_ok=True)
    return {"status": "SSH_KEY_ACTIVE", "actor_id": actor_id,
            "github_login": login, "gateway_transport_mode": "individual",
            "gateway_acknowledged": "true", "recovery": "true"}
