"""Panky 2.2 operational context scope from the Knowledge Gateway.

Core proves the repository binding and its local destination. The Gateway
decides which of those bindings the authenticated Actor can use right now.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any
from uuid import uuid4

import requests

from .gateway import _authorization_token, gateway_api_base
from .identity import VerifiedActor
from .node_authority import NodeAuthority
from .registry import CoreRegistry


class ContextCatalogError(ValueError):
    pass


def fetch_catalog(runtime_root: Path, *, google_id_token: str | None = None) -> dict[str, Any]:
    """Fetch through the one Gateway door, never from PostgreSQL or GitHub."""
    try:
        if google_id_token is None:
            access = _authorization_token(runtime_root)
            if not access:
                raise ContextCatalogError("Gateway OIDC proof is unavailable")
        else:
            response = requests.post(
                gateway_api_base(runtime_root) + "auth/panky/exchange",
                json={"google_id_token": google_id_token}, timeout=20,
            )
            response.raise_for_status()
            access = response.json()["access_token"]
            if not isinstance(access, str) or not access:
                raise ContextCatalogError("Gateway OIDC exchange is invalid")
        response = requests.get(
            gateway_api_base(runtime_root) + "panky/context/catalog",
            headers={"Authorization": f"Bearer {access}"}, timeout=20,
        )
        response.raise_for_status()
        result = response.json()
        if not isinstance(result, dict):
            raise ContextCatalogError("Gateway catalog is invalid")
        return result
    except (requests.RequestException, KeyError, TypeError, ValueError) as exc:
        if isinstance(exc, ContextCatalogError):
            raise
        raise ContextCatalogError("Gateway context catalog is unavailable") from exc


def context_decision(runtime_root: Path, *, node_id: str, surface: str,
                     operation: str, preview: bool = True) -> dict[str, Any]:
    """Authorize an organizational context action through the Gateway."""
    request_id = str(uuid4())
    try:
        access = _authorization_token(runtime_root)
        if not access:
            raise ContextCatalogError("Gateway OIDC proof is unavailable")
        response = requests.post(
            gateway_api_base(runtime_root) + "panky/context/decide",
            headers={"Authorization": f"Bearer {access}"},
            json={"node_id": node_id, "surface": surface,
                  "operation": operation, "request_id": request_id,
                  "preview": preview}, timeout=20,
        )
        response.raise_for_status()
        result = response.json()
        if not isinstance(result, dict) or not isinstance(result.get("allowed"), bool):
            raise ContextCatalogError("Gateway context decision is invalid")
        result["request_id"] = request_id
        return result
    except (requests.RequestException, KeyError, TypeError, ValueError) as exc:
        if isinstance(exc, ContextCatalogError):
            raise
        raise ContextCatalogError("Gateway context decision is unavailable") from exc


def complete_context_use(runtime_root: Path, *, reservation_id: str,
                         request_id: str, status: str) -> None:
    """Finalize a limited-use context exception after Git transport settles."""
    if status not in {"committed", "released", "uncertain"}:
        raise ContextCatalogError("Invalid context use completion")
    try:
        access = _authorization_token(runtime_root)
        if not access:
            raise ContextCatalogError("Gateway OIDC proof is unavailable")
        response = requests.post(
            gateway_api_base(runtime_root) + "panky/context/uses/complete",
            headers={"Authorization": f"Bearer {access}"},
            json={"reservation_id": reservation_id, "request_id": request_id,
                  "status": status}, timeout=20,
        )
        response.raise_for_status()
    except requests.RequestException as exc:
        raise ContextCatalogError("Gateway context use completion is unavailable") from exc


GOVERNANCE_ACTIONS = frozenset({
    "share_request", "share_decide", "resource_grant_request", "resource_grant_revoke",
    "super_admin_change", "founder_transfer_request", "founder_transfer_decide",
})


def governance_inbox(runtime_root: Path) -> dict[str, Any]:
    """Read the current Actor's pending requests through the signed Gateway."""
    try:
        access = _authorization_token(runtime_root)
        if not access:
            raise ContextCatalogError("Gateway OIDC proof is unavailable")
        response = requests.get(
            gateway_api_base(runtime_root) + "panky/governance/inbox",
            headers={"Authorization": f"Bearer {access}"}, timeout=20)
        response.raise_for_status()
        result = response.json()
        if (not isinstance(result, dict)
                or not isinstance(result.get("share_requests"), list)
                or not isinstance(result.get("founder_transfers"), list)):
            raise ContextCatalogError("Gateway governance inbox is invalid")
        return result
    except (requests.RequestException, KeyError, TypeError, ValueError) as exc:
        if isinstance(exc, ContextCatalogError):
            raise
        raise ContextCatalogError("Gateway governance inbox is unavailable") from exc


def governance_action(runtime_root: Path, *, action: str,
                      data: dict[str, Any]) -> dict[str, Any]:
    """Submit a bounded decision; the backend still checks current authority."""
    if action not in GOVERNANCE_ACTIONS or not isinstance(data, dict):
        raise ContextCatalogError("Unsupported governance action")
    try:
        access = _authorization_token(runtime_root)
        if not access:
            raise ContextCatalogError("Gateway OIDC proof is unavailable")
        response = requests.post(
            gateway_api_base(runtime_root) + "panky/governance/action",
            headers={"Authorization": f"Bearer {access}"},
            json={"action": action, "data": data}, timeout=20)
        response.raise_for_status()
        result = response.json()
        if (not isinstance(result, dict)
                or result.get("status") not in {
                    "pending", "approved", "rejected", "accepted", "expired", "denied"}
                or (result.get("effective") is not False and result.get("status") != "denied")):
            raise ContextCatalogError("Gateway governance response is invalid")
        return result
    except (requests.RequestException, KeyError, TypeError, ValueError) as exc:
        if isinstance(exc, ContextCatalogError):
            raise
        raise ContextCatalogError("Gateway governance is unavailable") from exc


def resource_sharing(runtime_root: Path, *, resource_id: str,
                     via_seat_id: str) -> dict[str, Any]:
    """Inspect recipients before interpreting an ambiguous unshare request."""
    try:
        access = _authorization_token(runtime_root)
        if not access:
            raise ContextCatalogError("Gateway OIDC proof is unavailable")
        response = requests.post(
            gateway_api_base(runtime_root) + "panky/governance/action",
            headers={"Authorization": f"Bearer {access}"},
            json={"action": "resource_sharing",
                  "data": {"resource_id": resource_id, "via_seat_id": via_seat_id}},
            timeout=20)
        response.raise_for_status()
        result = response.json()
        if (not isinstance(result, dict)
                or not isinstance(result.get("resource_id"), str)
                or not result["resource_id"]
                or not isinstance(result.get("active_grants"), list)
                or not isinstance(result.get("shared_departments"), list)):
            raise ContextCatalogError("Gateway resource sharing inventory is invalid")
        return result
    except (requests.RequestException, KeyError, TypeError, ValueError) as exc:
        if isinstance(exc, ContextCatalogError):
            raise
        raise ContextCatalogError("Gateway resource sharing is unavailable") from exc


def verify_catalog(catalog: dict[str, Any], actor: VerifiedActor,
                   registry: CoreRegistry, *, core_commit: str) -> dict[str, dict[str, Any]]:
    """Reject stale scope, forged paths, unknown repos and mixed Actors."""
    if (catalog.get("status") != "ready" or catalog.get("actor_id") != actor.actor_id
            or catalog.get("release") != core_commit or not isinstance(catalog.get("nodes"), list)):
        raise ContextCatalogError("Gateway catalog identity or release differs from trusted Core")
    authority = NodeAuthority(registry)
    selected: dict[str, dict[str, Any]] = {}
    seen_nodes: set[str] = set()
    for item in catalog["nodes"]:
        if not isinstance(item, dict):
            raise ContextCatalogError("Gateway context entry is invalid")
        node_id = item.get("node_id")
        if not isinstance(node_id, str) or node_id in seen_nodes:
            raise ContextCatalogError("Gateway context node is missing or repeated")
        seen_nodes.add(node_id)
        core_node = registry.topology_policy["nodes"].get(node_id) if registry.topology_policy else None
        if (core_node is None or core_node.get("owner_class") != "organization"
                or core_node.get("lifecycle") != "ACTIVE"
                or core_node.get("parent_id") != item.get("parent_node_id")):
            raise ContextCatalogError("Gateway context is absent from protected Core")
        matches = [binding for binding in authority.bindings.values()
                   if binding.node_id == node_id and binding.mode == item.get("binding_mode")
                   and binding.repository == item.get("repository")
                   and binding.store_id == item.get("store_id")
                   and binding.generation == item.get("generation")
                   and binding.local_path == item.get("local_path")]
        if len(matches) != 1:
            raise ContextCatalogError("Gateway repository differs from protected Core")
        binding = matches[0]
        # A checkout exposes every file in its Git repository. The Gateway
        # must authorize every readable surface before mounting that context.
        surfaces = item.get("read_surfaces")
        required = {"knowledge"} if binding.mode == "generated" else {"knowledge", "state", "work"}
        if (not isinstance(surfaces, (list, tuple)) or len(surfaces) != len(required)
                or set(surfaces) != required):
            raise ContextCatalogError("Gateway context surfaces differ from its repository")
        if binding.store_id in selected:
            raise ContextCatalogError("Gateway backing is repeated")
        selected[binding.store_id] = {
            "node_id": node_id, "path": binding.local_path,
            "repository": binding.repository, "generation": binding.generation,
            "state": "MATERIALIZED",
        }
    return selected


def manifest_from_catalog(catalog: dict[str, Any], actor: VerifiedActor,
                          registry: CoreRegistry, *, runtime_id: str,
                          personal_mode: str, personal_remote: str | None,
                          gateway_status: str, sync_state: str,
                          core_commit: str) -> dict[str, Any]:
    """Keep schema-3 compatibility while deriving mounts from live policy."""
    from .context_manifest14 import derive_graph_manifest, validate_graph_manifest

    selected = verify_catalog(catalog, actor, registry, core_commit=core_commit)
    manifest = derive_graph_manifest(
        actor, registry, runtime_id=runtime_id, personal_mode=personal_mode,
        personal_remote=personal_remote, gateway_status=gateway_status,
        sync_state=sync_state, core_commit=core_commit,
    )
    manifest["authorized_nodes"] = sorted({row["node_id"] for row in selected.values()})
    manifest["materialized_bindings"] = selected
    validate_graph_manifest(manifest)
    return manifest


def verify_catalog_manifest(manifest: dict[str, Any], catalog: dict[str, Any],
                            actor: VerifiedActor, registry: CoreRegistry, *,
                            expected_core_commit: str,
                            check_subject: bool = True) -> None:
    from .context_manifest14 import GraphManifestError, validate_graph_manifest

    validate_graph_manifest(manifest)
    if manifest.get("core_commit") != expected_core_commit:
        raise GraphManifestError("manifest Core release is stale")
    expected = manifest_from_catalog(
        catalog, actor, registry, runtime_id=manifest["runtime_id"],
        personal_mode=manifest["personal"]["mode"],
        personal_remote=manifest["personal"]["remote"],
        gateway_status=manifest["gateway"]["status"],
        sync_state=manifest["sync"]["state"], core_commit=expected_core_commit,
    )
    if not check_subject:
        expected["google_subject_sha256"] = manifest["google_subject_sha256"]
    if manifest != expected:
        raise GraphManifestError("manifest differs from active Gateway catalog")
