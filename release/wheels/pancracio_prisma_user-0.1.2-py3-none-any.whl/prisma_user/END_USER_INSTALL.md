# Instalación de usuario de Pancracio Prisma

Esta instalación se hace **por persona y por equipo**, después de la
instalación técnica de la empresa. La organización ya debe tener su Core,
repositorios, identidad y señales funcionando.
El usuario recibe un paquete firmado preparado por la instalación técnica;
Codex comprueba el release en `Pancracio-Prisma/pancracio-prisma-releases`.
No necesita acceso al repositorio privado del código fuente de Prisma.

## Qué decirle al agente

Antes de empezar, el administrador te comparte **dos cosas**: el enlace a la
carpeta de instalación de tu empresa y, por otro canal corporativo, un aviso
de verificación. Descarga la carpeta en `Documents/` o dale su enlace a Codex;
abre también el aviso para que Codex pueda leerlo. No tienes que interpretar
huellas ni preparar un bundle.

Abre Codex en el equipo donde usarás Panky Prisma y dile:

> Instala Panky Prisma para mi cuenta en esta computadora. Ya tengo la carpeta
> de instalación de mi empresa y el aviso que me mandó el administrador por
> separado. Encuéntralos, sigue `AGENT_END_USER_INSTALL.md` de esa carpeta y
> comprueba tú la firma antes de instalar. No modifiques otros Pancracios.

Codex te pedirá la ubicación del enlace o la carpeta y del aviso si todavía
no puede verlos; comprobará por sí mismo que las huellas coincidan. Si falta
el aviso separado, detendrá la instalación y pedirá al administrador que lo
envíe. Te preguntará qué cuenta GitHub autorizada usar para los repositorios
de la empresa. Te mostrará las rutas propias de esta instancia y preguntará si quieres memoria
Personal local o privada en GitHub. El Gateway de tu empresa ya viene
configurado en el paquete; no tienes que elegir cómo se aloja ni dar su URL.
Harás tú el inicio de sesión con Google y cualquier permiso del sistema; no
entregues contraseñas ni tokens por chat.

El agente instala una instancia separada, verifica quién eres contra el Core
de la empresa y pide al Gateway el catálogo vigente de tus Seats y contextos.
GitHub transporta los repos autorizados al vault de Obsidian; el contexto
Personal permanece aparte. Después comprueba el mapa de notas y backlinks,
la sincronización filtrada, la autorización vigente y tu primer onboarding
conversacional. Al cambiar un Seat, el agente reconcilia los repos y retira
del vault los contextos organizacionales que ya no correspondan, conservando
el Personal. Si ya hay
otro Pancracio en el equipo, conserva sus rutas, servicios y credenciales.
Una instalación no queda lista hasta que el agente te muestre un resultado
READY de esta instancia.
Después, para actualizar basta decirle «Panky, actualízate». El agente consulta
los releases aprobados en el repositorio central de Pancracio Prisma,
verifica la firma del publicador y ejecuta la actualización y Doctor de esta
instancia. No necesitas buscar ni descargar el paquete manualmente.
Si el Gateway o el catálogo de contextos no responden, el agente detiene la
instalación y te explica el bloqueo; no reemplaza OIDC con un token viejo.

**Estado del producto:** el ensayo local de instalación limpia con release
firmado pasó en macOS y eliminó sus archivos de prueba. Antes de entregar el
paquete a usuarios reales, Codex debe verificar el servicio de la empresa y
repetir las pruebas de instalación en el sistema operativo del destinatario.
