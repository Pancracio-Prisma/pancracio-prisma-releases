"""Self-hosted preparation tools for Pancracio Prisma."""

__version__ = "0.1.2"
