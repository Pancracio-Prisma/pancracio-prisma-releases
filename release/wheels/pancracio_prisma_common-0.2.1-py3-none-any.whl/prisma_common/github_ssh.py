"""Verified GitHub SSH host material for instance-scoped transports."""

from __future__ import annotations

import os
from pathlib import Path


GITHUB_ED25519_HOST_KEY = (
    "github.com ssh-ed25519 "
    "AAAAC3NzaC1lZDI1NTE5AAAAIOMqqnkVzrm0SdG6UOoqKLsabgH5C9okWi0dh2l9GKJl\n"
)


def ensure_github_known_hosts(runtime: Path) -> Path:
    path = runtime / "github-known-hosts"
    if path.is_symlink():
        raise ValueError("instance GitHub known-hosts file is unsafe")
    if path.exists():
        if not path.is_file() or path.read_text(encoding="ascii") != GITHUB_ED25519_HOST_KEY:
            raise ValueError("instance GitHub host key differs from the pinned key")
        return path
    try:
        with path.open("x", encoding="ascii") as stream:
            stream.write(GITHUB_ED25519_HOST_KEY)
        if os.name != "nt":
            path.chmod(0o600)
    except FileExistsError:
        if path.is_symlink() or not path.is_file() or path.read_text(encoding="ascii") != GITHUB_ED25519_HOST_KEY:
            raise ValueError("instance GitHub host key differs from the pinned key")
    return path


def known_hosts_option(path: Path) -> str:
    """Quote the OpenSSH config value as well as the outer Git command.

    Git's shell quoting alone does not protect spaces when Windows OpenSSH
    parses the value of a ``-o`` option.
    """
    return f'UserKnownHostsFile="{path}"'
