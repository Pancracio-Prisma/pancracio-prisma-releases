"""Live readiness proof for the POC universal Git-key broker."""

from __future__ import annotations

import json
import re
from typing import Any, Callable
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode, urlsplit, urlunsplit
from urllib.request import HTTPRedirectHandler, Request, build_opener

from .intake import SetupInputError


_COMMIT = re.compile(r"[0-9a-f]{40}\Z")
_LOGIN = re.compile(r"[A-Za-z0-9](?:[A-Za-z0-9-]{0,37}[A-Za-z0-9])?\Z")


class _NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def _unique(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result = {}
    for key, value in pairs:
        if key in result:
            raise SetupInputError("POC transport readiness response is invalid")
        result[key] = value
    return result


def verify_poc_transport_status(endpoint: str, *, tenant_slug: str,
                                instance_id: str, github_login: str,
                                opener: Callable[..., Any] | None = None) -> dict[str, str]:
    """Require live broker/account/active-POC proof matching the signed binding.

    The request carries only public tenant and instance identifiers. The
    Gateway status route is read-only and must not return repository or secret
    material.
    """
    if not isinstance(github_login, str) or not _LOGIN.fullmatch(github_login):
        raise SetupInputError("POC universal GitHub account is unavailable")
    try:
        parts = urlsplit(endpoint)
        if (parts.scheme != "https" or not parts.hostname or parts.username is not None
                or parts.password is not None or parts.query or parts.fragment):
            raise ValueError
        authority = parts.netloc
        url = urlunsplit(("https", authority, "/panky/poc-transport/status",
                          urlencode({"tenant_slug": tenant_slug, "instance_id": instance_id}), ""))
        request = Request(url, headers={"Accept": "application/json"}, method="GET")
        if opener is None:
            response_context = build_opener(_NoRedirect()).open(request, timeout=8)
        else:
            response_context = opener(request, timeout=8)
        with response_context as response:
            if response.status != 200:
                raise SetupInputError("POC transport broker is not ready")
            raw = response.read(16_385)
        if len(raw) > 16_384:
            raise SetupInputError("POC transport readiness response is too large")
        data = json.loads(raw.decode("utf-8"), object_pairs_hook=_unique)
    except SetupInputError:
        raise
    except (HTTPError, URLError, OSError, ValueError, TypeError, UnicodeError):
        raise SetupInputError("POC transport broker readiness could not be verified") from None
    if (not isinstance(data, dict)
            or set(data) != {"status", "tenant_slug", "instance_id", "github_login", "core_commit"}
            or data.get("status") != "ready"
            or data.get("tenant_slug") != tenant_slug
            or data.get("instance_id") != instance_id
            or not isinstance(data.get("github_login"), str)
            or data["github_login"].casefold() != github_login.casefold()
            or not isinstance(data.get("core_commit"), str)
            or not _COMMIT.fullmatch(data["core_commit"])):
        raise SetupInputError("POC transport readiness does not match the signed binding")
    return data
