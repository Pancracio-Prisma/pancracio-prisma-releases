"""Instance-scoped GitHub SSH key staging.

External GitHub actions are deliberately supplied by the caller. This module
never opens a browser, accepts an invitation, or reports an unverified key as
active.
"""

from __future__ import annotations

import json
import os
import csv
from pathlib import Path
import re
import subprocess
from typing import Any, Callable
from uuid import uuid4

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
import yaml

from prisma_common.installed_binding import load_installed_binding, runtime_directory
from prisma_common.intake import SetupInputError
from prisma_common.github_ssh import ensure_github_known_hosts, known_hosts_option


class SSHTransportError(SetupInputError):
    """SSH transport setup could not be safely completed."""


def secure_private_key(path: Path, *, platform: str | None = None) -> None:
    """Restrict a newly created or resumed instance key before OpenSSH uses it."""
    if path.is_symlink() or not path.is_file():
        raise SSHTransportError("instance SSH private key is unavailable")
    if (platform or ("windows" if os.name == "nt" else "macos")) != "windows":
        path.chmod(0o600)
        return
    try:
        identity = subprocess.run(["whoami", "/user", "/fo", "csv", "/nh"],
                                  capture_output=True, text=True, timeout=10, check=True)
        rows = list(csv.reader(identity.stdout.splitlines()))
        sid = rows[0][1] if len(rows) == 1 and len(rows[0]) == 2 else ""
        if not re.fullmatch(r"S-1-(?:[0-9]+-)+[0-9]+", sid):
            raise ValueError("Windows Actor SID is invalid")
        for options in (["/inheritance:r"], ["/remove:g", "*S-1-3-4"],
                        ["/grant:r", f"*{sid}:F"]):
            subprocess.run(["icacls", str(path), *options], capture_output=True,
                           text=True, timeout=15, check=True)
        checked = subprocess.run(["ssh-keygen", "-y", "-P", "", "-f", str(path)],
                                 capture_output=True, text=True, timeout=15, check=False)
        if checked.returncode or not checked.stdout.startswith("ssh-ed25519 "):
            reason = (checked.stderr or "unknown OpenSSH error").strip().splitlines()[-1]
            reason = reason.rsplit('": ', 1)[-1]  # omit the local key path
            raise ValueError(f"Windows OpenSSH rejected the private key: {reason[:160]}")
    except (OSError, subprocess.SubprocessError, ValueError, IndexError) as exc:
        raise SSHTransportError("instance SSH private key permissions are unavailable") from exc


def _instance_owner(workspace: Path, expected_actor_id: str | None) -> str | None:
    """Bind the operation to this composed Actor when an owner record exists."""
    owner_path = workspace / ".panky" / "owner.yaml"
    if not owner_path.exists():
        if expected_actor_id is not None:
            raise SSHTransportError("composed Actor binding is unavailable")
        return None
    if owner_path.is_symlink() or not owner_path.is_file():
        raise SSHTransportError("composed Actor binding is unsafe")
    try:
        owner = yaml.safe_load(owner_path.read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        raise SSHTransportError("composed Actor binding is invalid") from exc
    actor_id = owner.get("actor_id") if isinstance(owner, dict) else None
    if not isinstance(actor_id, str) or not re.fullmatch(r"[A-Za-z][A-Za-z0-9_-]{2,63}", actor_id):
        raise SSHTransportError("composed Actor binding is invalid")
    if expected_actor_id is not None and actor_id != expected_actor_id:
        raise SSHTransportError("authenticated Actor differs from this instance")
    return actor_id


def generate_key_pair(workspace: Path, *, actor_id: str | None = None,
                      home: Path | None = None, local_appdata: Path | None = None,
                      platform: str | None = None) -> dict[str, str]:
    """Create a fresh Ed25519 pair in this instance runtime without overwriting.

    The returned metadata deliberately excludes private key bytes.
    """
    binding = load_installed_binding(workspace, home=home,
                                     local_appdata=local_appdata, platform=platform)
    instance, runtime = runtime_directory(workspace, home=home,
                                          local_appdata=local_appdata, platform=platform)
    bound_actor = _instance_owner(workspace, actor_id)
    if binding.get("instance_id") != instance:
        raise SSHTransportError("signed binding belongs to another instance")
    if runtime.is_symlink() or not runtime.is_dir():
        raise SSHTransportError("instance runtime directory is unavailable")
    if os.name != "nt":
        runtime.chmod(0o700)

    private = Ed25519PrivateKey.generate()
    private_bytes = private.private_bytes(serialization.Encoding.PEM,
                                          serialization.PrivateFormat.OpenSSH,
                                          serialization.NoEncryption())
    public_bytes = private.public_key().public_bytes(serialization.Encoding.OpenSSH,
                                                      serialization.PublicFormat.OpenSSH)
    stem = f"github-ed25519-{uuid4().hex}"
    private_path, public_path = runtime / stem, runtime / f"{stem}.pub"
    private_created = public_created = False
    try:
        # Exclusive creation prevents clobbering even in a concurrent call.
        with private_path.open("xb") as stream:
            private_created = True
            stream.write(private_bytes)
        secure_private_key(private_path, platform=platform)
        with public_path.open("xb") as stream:
            public_created = True
            stream.write(public_bytes + b"\n")
        if os.name != "nt":
            public_path.chmod(0o600)
    except Exception:
        if private_created:
            private_path.unlink(missing_ok=True)
        if public_created:
            public_path.unlink(missing_ok=True)
        raise
    return {"instance_id": instance, "actor_id": bound_actor or "",
            "private_key_path": str(private_path), "public_key_path": str(public_path),
            "public_key": public_bytes.decode("ascii")}


def check_github_login(identity_lookup: Callable[[], Any], expected_login: str) -> str:
    """Call an authenticated identity interface and require its exact login."""
    if not isinstance(expected_login, str) or not re.fullmatch(r"[A-Za-z0-9](?:[A-Za-z0-9-]{0,37}[A-Za-z0-9])?", expected_login):
        raise SSHTransportError("expected GitHub login is invalid")
    try:
        result = identity_lookup()
    except Exception as exc:
        raise SSHTransportError("GitHub account identity could not be verified") from exc
    login = result.get("login") if isinstance(result, dict) else result
    if not isinstance(login, str) or login.casefold() != expected_login.casefold():
        raise SSHTransportError(
            "authenticated GitHub login does not match expected login; use the Core-assigned account with "
            "gh auth login --hostname github.com --web")
    return login


def key_specific_ssh_command(private_key_path: Path | str) -> list[str]:
    """Return SSH argv constrained to one identity and strict host checking."""
    key_path = Path(private_key_path)
    if key_path.is_symlink() or not key_path.is_file():
        raise SSHTransportError("instance SSH private key is unavailable")
    try:
        known_hosts = ensure_github_known_hosts(key_path.parent)
    except (OSError, ValueError) as exc:
        raise SSHTransportError("trusted GitHub SSH host key is unavailable") from exc
    return ["ssh", "-i", str(key_path), "-o", "IdentitiesOnly=yes",
            "-o", "StrictHostKeyChecking=yes", "-o", known_hosts_option(known_hosts),
            "-o", "BatchMode=yes"]


def _verify_repository_access(report: Any, expected_repositories: list[str],
                              required_write_repositories: list[str]) -> None:
    """Require one explicit access result for every and only authorized repo."""
    if not isinstance(report, dict) or set(report) != {"repositories"}:
        raise SSHTransportError("repository access verification report is invalid")
    rows = report["repositories"]
    if not isinstance(rows, list):
        raise SSHTransportError("repository access verification report is invalid")
    seen: dict[str, dict[str, Any]] = {}
    for row in rows:
        if (not isinstance(row, dict) or set(row) != {"repository", "reachable", "writable"}
                or not isinstance(row["repository"], str)
                or row["repository"] in seen
                or not isinstance(row["reachable"], bool)
                or not isinstance(row["writable"], bool)):
            raise SSHTransportError("repository access verification report is invalid")
        seen[row["repository"]] = row
    if set(seen) != set(expected_repositories):
        raise SSHTransportError("verified repositories differ from the authorized repository list")
    for repository in expected_repositories:
        row = seen[repository]
        if not row["reachable"]:
            raise SSHTransportError("authorized repository is not reachable with the new SSH key")
        if repository in required_write_repositories and not row["writable"]:
            raise SSHTransportError("required repository write access is not verified")


def _signed_repositories(binding: dict[str, Any]) -> set[str]:
    try:
        github = binding["resources"]["github"]
        owner = github["owner"]
        names = {github[name] for name in ("workspace_repository", "core_repository",
                                             "actor_template_repository", "knowledge_repository")}
        names.update(github["node_repositories"])
        names.update(github["publication_repositories"])
    except (KeyError, TypeError) as exc:
        raise SSHTransportError("signed repository authorization is unavailable") from exc
    if (not isinstance(owner, str) or not owner
            or any(not isinstance(name, str) or not name for name in names)):
        raise SSHTransportError("signed repository authorization is invalid")
    return {f"{owner}/{name}" for name in names}


def _mount_repositories(mounts: Any, expected_actor_id: str) -> tuple[set[str], set[str]]:
    """Resolve the exact repository set from verified Context Sync mounts."""
    if not isinstance(mounts, dict) or not mounts:
        raise SSHTransportError("verified Actor mount map is unavailable")
    all_repositories: set[str] = set()
    tenant_repositories: set[str] = set()
    allowed_kinds = {"workspace", "core", "graph_node", "graph_publication", "actor_private"}
    for key, mount in mounts.items():
        repository_id = getattr(mount, "repository_id", None)
        remote = getattr(mount, "remote", None)
        kind = getattr(mount, "kind", None)
        if (key != repository_id or kind not in allowed_kinds or not isinstance(remote, str)
                or not remote.startswith("git@github.com:") or not remote.endswith(".git")):
            raise SSHTransportError("verified Actor mount map is invalid")
        repo_path = remote[len("git@github.com:"):-4]
        if not re.fullmatch(r"[A-Za-z0-9](?:[A-Za-z0-9_.-]{0,98}[A-Za-z0-9])?/[A-Za-z0-9](?:[A-Za-z0-9_.-]{0,98}[A-Za-z0-9])?", repo_path):
            raise SSHTransportError("verified Actor mount remote is invalid")
        if repo_path in all_repositories:
            raise SSHTransportError("verified Actor mount map contains duplicate repositories")
        if kind == "actor_private":
            if repository_id != f"actor-private:{expected_actor_id}":
                raise SSHTransportError("private Actor mount is bound to another Actor")
        else:
            tenant_repositories.add(repo_path)
        all_repositories.add(repo_path)
    return all_repositories, tenant_repositories


def stage_ssh_transport(
    workspace: Path, *, expected_actor_id: str, expected_login: str,
    expected_repositories: list[str], required_write_repositories: list[str],
    authorized_mounts: Callable[[Path], Any],
    identity_lookup: Callable[[], Any], add_public_key: Callable[[str, str], Any],
    verify_ssh_identity: Callable[[list[str]], Any],
    verify_repository_access: Callable[[list[str], list[str], list[str]], Any],
    verified_core_commit: str,
    verified_repositories: list[str],
    activate: bool = True,
    home: Path | None = None, local_appdata: Path | None = None,
    platform: str | None = None,
) -> dict[str, str]:
    """Register, verify, then atomically activate one instance key.

    Prior keys and the active pointer are left intact until the new key proves
    usable. The callbacks must perform real authenticated GitHub operations;
    a falsy registration or verification result fails closed.
    """
    binding = load_installed_binding(workspace, home=home,
                                     local_appdata=local_appdata, platform=platform)
    instance, runtime = runtime_directory(workspace, home=home,
                                          local_appdata=local_appdata, platform=platform)
    _instance_owner(workspace, expected_actor_id)
    if binding.get("instance_id") != instance:
        raise SSHTransportError("signed binding belongs to another instance")
    if not isinstance(verified_core_commit, str) or not re.fullmatch(r"[0-9a-f]{40}", verified_core_commit):
        raise SSHTransportError("verified Core transition commit is unavailable")
    repository_pattern = re.compile(r"[A-Za-z0-9](?:[A-Za-z0-9_.-]{0,98}[A-Za-z0-9])?/[A-Za-z0-9](?:[A-Za-z0-9_.-]{0,98}[A-Za-z0-9])?\Z")
    if (not isinstance(expected_repositories, list) or not expected_repositories
            or any(not isinstance(repo, str) or not repository_pattern.fullmatch(repo)
                   for repo in expected_repositories)
            or len(set(expected_repositories)) != len(expected_repositories)):
        raise SSHTransportError("an exact non-empty authorized repository list is required")
    if (not isinstance(required_write_repositories, list)
            or any(not isinstance(repo, str) for repo in required_write_repositories)
            or len(set(required_write_repositories)) != len(required_write_repositories)
            or any(repo not in expected_repositories for repo in required_write_repositories)):
        raise SSHTransportError("required write repositories must be an authorized subset")
    tenant_repositories = _signed_repositories(binding)
    try:
        mounts = authorized_mounts(workspace)
    except Exception as exc:
        raise SSHTransportError("verified Actor mount map is unavailable") from exc
    mount_repositories, tenant_mount_repositories = _mount_repositories(mounts, expected_actor_id)
    if set(expected_repositories) != mount_repositories:
        raise SSHTransportError("repository list differs from the verified Actor mount map")
    if (not isinstance(verified_repositories, list)
            or len(set(verified_repositories)) != len(verified_repositories)
            or set(verified_repositories) != set(expected_repositories)):
        raise SSHTransportError("verified repository inventory differs from authorized mounts")
    if not tenant_mount_repositories.issubset(tenant_repositories):
        raise SSHTransportError("Actor mount exceeds the signed tenant repository authorization")
    login = check_github_login(identity_lookup, expected_login)
    key = generate_key_pair(workspace, actor_id=expected_actor_id, home=home,
                            local_appdata=local_appdata, platform=platform)
    title = f"Pancracio Prisma {instance}"
    try:
        registered = add_public_key(key["public_key"], title)
        if not registered:
            raise SSHTransportError("GitHub did not confirm SSH key registration")
        command = key_specific_ssh_command(key["private_key_path"])
        verified_login = verify_ssh_identity(command)
        if isinstance(verified_login, dict):
            verified_login = verified_login.get("login")
        if not isinstance(verified_login, str) or verified_login.casefold() != login.casefold():
            raise SSHTransportError("new SSH key did not authenticate as the expected GitHub account")
        access_report = verify_repository_access(command, expected_repositories,
                                                 required_write_repositories)
        _verify_repository_access(access_report, expected_repositories,
                                  required_write_repositories)

        active = runtime / "github-ssh-active.json"
        if active.is_symlink():
            raise SSHTransportError("instance SSH active pointer is unsafe")
        temporary = runtime / f".github-ssh-active-{uuid4().hex}.tmp"
        try:
            with temporary.open("x", encoding="utf-8") as stream:
                json.dump({"schema_version": 1, "instance_id": instance,
                           "actor_id": expected_actor_id, "login": login,
                           "core_commit": verified_core_commit,
                           "repositories": sorted(verified_repositories),
                           "gateway_mode": "pending", "gateway_request_id": "",
                           "private_key": Path(key["private_key_path"]).name}, stream,
                          sort_keys=True)
                stream.write("\n")
            if os.name != "nt":
                temporary.chmod(0o600)
            if activate:
                os.replace(temporary, active)
        except Exception:
            temporary.unlink(missing_ok=True)
            raise
        return {"status": "SSH_KEY_ACTIVE", "instance_id": instance,
                "actor_id": expected_actor_id, "github_login": login,
                "private_key_path": key["private_key_path"],
                "public_key_path": key["public_key_path"],
                "active_pointer": str(active),
                "staged_pointer": "" if activate else str(temporary),
                "github_key_registered": "true", "ssh_identity_verified": "true",
                "verified_repositories": ",".join(expected_repositories),
                "verified_write_repositories": ",".join(required_write_repositories)}
    except Exception:
        # Keep the generated pair for inspection/retry, but never promote it.
        # No prior active key or GitHub key is removed here.
        raise
