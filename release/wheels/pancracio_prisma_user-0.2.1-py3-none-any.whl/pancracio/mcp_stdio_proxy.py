"""Instance-bound stdio bridge for harnesses without dynamic HTTP headers.

The signed binding chooses the remote Gateway. OAuth stays in the instance
keyring; no credential is written to a project instruction or MCP config.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys
from typing import Any, TextIO

import requests

from prisma_common.installed_binding import load_installed_binding
from .gateway import _authorization_token, gateway_endpoint


def _response_payload(response: requests.Response) -> dict[str, Any] | None:
    if response.status_code == 202 or not response.content:
        return None
    if "text/event-stream" in response.headers.get("Content-Type", ""):
        for line in response.text.splitlines():
            if line.startswith("data:"):
                value = json.loads(line[5:].strip())
                if isinstance(value, dict) and value.get("jsonrpc") == "2.0":
                    return value
        raise ValueError("Gateway MCP stream has no response")
    value = response.json()
    if not isinstance(value, dict) or value.get("jsonrpc") != "2.0":
        raise ValueError("Gateway MCP response is invalid")
    return value


def _forward(workspace: Path, request: dict[str, Any], session_id: str | None,
             *, post=requests.post) -> tuple[dict[str, Any] | None, str | None]:
    if request.get("jsonrpc") != "2.0" or not isinstance(request.get("method"), str):
        raise ValueError("MCP request is invalid")
    token = _authorization_token(workspace / ".panky")
    endpoint = gateway_endpoint(workspace / ".panky")
    if not token or not endpoint:
        raise ValueError("Gateway OIDC is unavailable")
    headers = {"Authorization": f"Bearer {token}",
               "Accept": "application/json, text/event-stream",
               "Content-Type": "application/json",
               "MCP-Protocol-Version": "2025-06-18"}
    if session_id:
        headers["Mcp-Session-Id"] = session_id
    response = post(endpoint, headers=headers, json=request, timeout=60)
    response.raise_for_status()
    next_session = response.headers.get("Mcp-Session-Id") or session_id
    return _response_payload(response), next_session


def serve(workspace: Path, source: TextIO, sink: TextIO, *, post=requests.post) -> None:
    # Refuse arbitrary directories before processing any tool request.
    load_installed_binding(workspace)
    session_id: str | None = None
    for line in source:
        request: Any = None
        try:
            request = json.loads(line)
            if not isinstance(request, dict):
                raise ValueError("MCP request is invalid")
            reply, session_id = _forward(workspace, request, session_id, post=post)
        except (ValueError, requests.RequestException):
            # Do not echo transport failures or credentials into model context.
            if not isinstance(request, dict) or "id" not in request:
                continue
            reply = {"jsonrpc": "2.0", "id": request["id"],
                     "error": {"code": -32000, "message": "Panky Gateway unavailable or request rejected"}}
        if reply is not None:
            sink.write(json.dumps(reply, ensure_ascii=False, separators=(",", ":")) + "\n")
            sink.flush()


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="panky-prisma-mcp")
    parser.add_argument("--workspace", type=Path, required=True)
    args = parser.parse_args(argv)
    try:
        serve(args.workspace.resolve(strict=True), sys.stdin, sys.stdout)
    except (OSError, ValueError):
        return 4
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
