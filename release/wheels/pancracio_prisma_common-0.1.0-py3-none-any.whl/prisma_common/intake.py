"""Validate untrusted business input without granting runtime authority."""

from __future__ import annotations

from importlib import resources
import json
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator


class SetupInputError(ValueError):
    pass


MAX_INPUT_BYTES = 64 * 1024


def _unique_object(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise SetupInputError("input contains duplicate keys")
        result[key] = value
    return result


def load_json(path: Path) -> Any:
    if path.is_symlink() or not path.is_file() or path.stat().st_size > MAX_INPUT_BYTES:
        raise SetupInputError("input must be a regular JSON file under 64 KiB")
    try:
        return json.loads(path.read_text(encoding="utf-8"), object_pairs_hook=_unique_object)
    except (UnicodeError, json.JSONDecodeError) as exc:
        raise SetupInputError("input is not valid UTF-8 JSON") from exc


def _schema(name: str) -> dict[str, Any]:
    source = resources.files("prisma_common").joinpath("resources", name)
    schema = json.loads(source.read_text(encoding="utf-8"))
    Draft202012Validator.check_schema(schema)
    return schema


def _validate(value: Any, schema_name: str) -> dict[str, Any]:
    errors = list(Draft202012Validator(_schema(schema_name)).iter_errors(value))
    if errors or not isinstance(value, dict):
        # Submitted values may include secrets even though the schema forbids them.
        raise SetupInputError("input does not match the Prisma schema")
    if schema_name == "tenant-intake.schema.json":
        for field in (value["tenant"]["legal_name"], value["product"]["display_name"]):
            if any(ord(character) < 32 or ord(character) == 127 for character in field):
                raise SetupInputError("display names must be single-line text")
    return value


def load_intake(path: Path) -> dict[str, Any]:
    return _validate(load_json(path), "tenant-intake.schema.json")


def load_resources(path: Path, intake: dict[str, Any]) -> dict[str, Any]:
    value = _validate(load_json(path), "customer-resources.schema.json")
    return validate_resources(value, intake)


def validate_resources(value: dict[str, Any], intake: dict[str, Any]) -> dict[str, Any]:
    """Apply tenant and cross-field checks to already schema-validated values."""
    if value["tenant_slug"] != intake["tenant"]["slug"]:
        raise SetupInputError("resource tenant differs from intake")
    if value["google_workspace"]["primary_domain"] != intake["tenant"]["primary_domain"]:
        raise SetupInputError("resource domain differs from intake")
    if value["gateway"]["enabled"] != intake["gateway"]["enabled"]:
        raise SetupInputError("Gateway choice differs from intake")
    if intake["deployment"]["mode"] != "self_hosted":
        raise SetupInputError("this setup kit currently supports self-hosted only")
    names = [value["github"]["workspace_repository"], value["github"]["core_repository"],
             value["github"]["actor_template_repository"], value["github"]["knowledge_repository"],
             *value["github"]["node_repositories"], *value["github"]["publication_repositories"]]
    if len(names) != len({name.casefold() for name in names}):
        raise SetupInputError("repository names must be unique within the customer organization")
    cloud = value["google_cloud"]
    project_number = cloud["project_number"]
    for key in ("desktop_wif_provider", "github_wif_provider"):
        if not cloud[key].startswith(f"projects/{project_number}/"):
            raise SetupInputError("WIF provider belongs to another Google Cloud project")
    if cloud["desktop_wif_provider"] == cloud["github_wif_provider"]:
        raise SetupInputError("desktop and GitHub WIF providers must be separate")
    if not cloud["context_invoker_service_account"].endswith(
        f"@{cloud['project_id']}.iam.gserviceaccount.com"
    ):
        raise SetupInputError("context invoker belongs to another Google Cloud project")
    workspace_connector = "google_workspace" in intake["gateway"]["requested_connectors"]
    auth_mode = value["google_workspace"]["connector_authorization"]
    if workspace_connector == (auth_mode == "none"):
        raise SetupInputError("Google Workspace connector authorization does not match intake")
    return value
