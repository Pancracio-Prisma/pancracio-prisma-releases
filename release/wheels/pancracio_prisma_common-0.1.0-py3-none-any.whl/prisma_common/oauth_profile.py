"""Check a desktop OAuth client against the signed instance binding."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from .installed_binding import load_installed_binding, runtime_directory
from .intake import SetupInputError, load_json


def load_desktop_oauth(workspace: Path, *, home: Path | None = None,
                       local_appdata: Path | None = None,
                       platform: str | None = None) -> dict[str, Any]:
    binding = load_installed_binding(workspace, home=home,
                                     local_appdata=local_appdata, platform=platform)
    _, runtime = runtime_directory(workspace, home=home,
                                   local_appdata=local_appdata, platform=platform)
    config = load_json(runtime / "desktop_oauth.json")
    return validate_desktop_oauth_data(config, binding["resources"]["google_cloud"])


def validate_desktop_oauth_data(config: Any, cloud: dict[str, Any]) -> dict[str, Any]:
    """Check public desktop OAuth metadata before bundling or using it."""
    if not isinstance(config, dict) or set(config) != {"installed"} or not isinstance(config["installed"], dict):
        raise SetupInputError("invalid desktop OAuth client file")
    installed = config["installed"]
    if (installed.get("client_id") != cloud["desktop_oauth_client_id"]
            or installed.get("project_id") != cloud["project_id"]
            or installed.get("auth_uri") != "https://accounts.google.com/o/oauth2/auth"
            or installed.get("token_uri") != "https://oauth2.googleapis.com/token"):
        raise SetupInputError("desktop OAuth client differs from signed binding")
    redirects = installed.get("redirect_uris")
    if not isinstance(redirects, list) or not redirects or not all(
        isinstance(uri, str) and uri in {"http://localhost", "http://127.0.0.1"}
        for uri in redirects
    ):
        raise SetupInputError("desktop OAuth redirects must be loopback only")
    if not isinstance(installed.get("client_secret", ""), str):
        raise SetupInputError("invalid desktop OAuth client metadata")
    return config
