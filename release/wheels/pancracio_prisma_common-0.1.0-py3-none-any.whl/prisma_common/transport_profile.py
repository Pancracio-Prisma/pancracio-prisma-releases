"""Derive Context Sync resource names only from a verified instance binding."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from .installed_binding import load_installed_binding


@dataclass(frozen=True)
class TransportProfile:
    project_id: str
    topic_id: str
    wif_provider: str
    provisioner_url: str
    provisioner_name: str
    invoker_service_account: str
    keyring_service: str


def transport_profile(workspace: Path) -> TransportProfile:
    binding = load_installed_binding(workspace)
    cloud = binding["resources"]["google_cloud"]
    return TransportProfile(
        project_id=cloud["project_id"], topic_id=cloud["context_topic_id"],
        wif_provider=cloud["desktop_wif_provider"],
        provisioner_url=cloud["provisioner_url"].rstrip("/"),
        provisioner_name=cloud["provisioner_service_name"],
        invoker_service_account=cloud["context_invoker_service_account"],
        keyring_service=f"pancracio-prisma/{binding['instance_id']}/context-sync",
    )
