"""Verify a customer-signed installation binding before using resource IDs."""

from __future__ import annotations

import base64
import binascii
import hashlib
import json
from pathlib import Path
from typing import Any

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

from .instance import instance_id
from .intake import SetupInputError, _validate, load_json, validate_resources


def canonical_bytes(value: dict[str, Any]) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"),
                      ensure_ascii=False, allow_nan=False).encode("utf-8")


def binding_payload(intake: dict[str, Any], resources: dict[str, Any]) -> dict[str, Any]:
    """Create unsigned data for an authorized customer operator to review."""
    intake = _validate(intake, "tenant-intake.schema.json")
    resources = validate_resources(_validate(resources, "customer-resources.schema.json"), intake)
    return {"schema_version": 1, "tenant_slug": intake["tenant"]["slug"],
            "instance_id": instance_id(intake), "intake": intake, "resources": resources}


def public_key_fingerprint(public_key_bytes: bytes) -> str:
    if len(public_key_bytes) != 32:
        raise SetupInputError("invalid Ed25519 public key")
    return hashlib.sha256(public_key_bytes).hexdigest()


def verify_signed_binding(path: Path, *, pinned_public_key: bytes,
                          expected_instance_id: str) -> dict[str, Any]:
    """Verify against a key pinned outside the editable customer profile."""
    envelope = load_json(path)
    if not isinstance(envelope, dict) or set(envelope) != {"payload", "signature"}:
        raise SetupInputError("invalid signed binding envelope")
    payload = envelope["payload"]
    if not isinstance(payload, dict) or set(payload) != {
        "schema_version", "tenant_slug", "instance_id", "intake", "resources"
    } or payload["schema_version"] != 1:
        raise SetupInputError("invalid signed binding payload")
    intake = _validate(payload["intake"], "tenant-intake.schema.json")
    if payload["instance_id"] != expected_instance_id or payload["instance_id"] != instance_id(intake):
        raise SetupInputError("signed binding belongs to another instance")
    resources = _validate(payload["resources"], "customer-resources.schema.json")
    validate_resources(resources, intake)
    if payload["tenant_slug"] != resources["tenant_slug"] or payload["tenant_slug"] != intake["tenant"]["slug"]:
        raise SetupInputError("signed binding tenant mismatch")
    if not isinstance(envelope["signature"], str) or len(pinned_public_key) != 32:
        raise SetupInputError("invalid binding signature or pinned key")
    try:
        signature = base64.b64decode(envelope["signature"], validate=True)
        if len(signature) != 64:
            raise SetupInputError("invalid binding signature")
        Ed25519PublicKey.from_public_bytes(pinned_public_key).verify(signature, canonical_bytes(payload))
    except (binascii.Error, ValueError, InvalidSignature) as exc:
        raise SetupInputError("signed binding verification failed") from exc
    return payload
