"""Derive customer Git remotes solely from the pinned instance binding."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from .installed_binding import load_installed_binding


@dataclass(frozen=True)
class RepositoryProfile:
    owner: str
    workspace_id: str
    core_id: str
    workspace_remote: str
    core_remote: str
    actor_template_remote: str


def repository_profile(workspace: Path) -> RepositoryProfile:
    github = load_installed_binding(workspace)["resources"]["github"]
    owner = github["owner"]
    workspace_id = github["workspace_repository"]
    core_id = github["core_repository"]
    actor_template_id = github["actor_template_repository"]
    return RepositoryProfile(
        owner=owner, workspace_id=workspace_id, core_id=core_id,
        workspace_remote=f"git@github.com:{owner}/{workspace_id}.git",
        core_remote=f"git@github.com:{owner}/{core_id}.git",
        actor_template_remote=f"git@github.com:{owner}/{actor_template_id}.git")
