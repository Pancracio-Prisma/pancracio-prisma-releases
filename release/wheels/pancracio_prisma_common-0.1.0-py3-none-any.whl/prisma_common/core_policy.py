"""Customer organization boundary for a protected Core policy."""

from __future__ import annotations

import re
from typing import Any


class CorePolicyError(ValueError):
    pass


_OWNER = re.compile(r"[A-Za-z0-9](?:[A-Za-z0-9-]{0,37}[A-Za-z0-9])?\Z")
_REPO = re.compile(r"[A-Za-z0-9._-]{1,100}\Z")


def approved_remote(repository: str, organization: str, reference_remote: str | None = None) -> str:
    """Format only a Core-approved repository in the approved organization."""
    if not isinstance(organization, str) or not _OWNER.fullmatch(organization):
        raise CorePolicyError("invalid protected organization")
    if not isinstance(repository, str) or repository.count("/") != 1:
        raise CorePolicyError("invalid protected backing repository")
    owner, name = repository.split("/")
    if owner.casefold() != organization.casefold() or not _REPO.fullmatch(name) or name in {".", ".."}:
        raise CorePolicyError("backing is outside protected organization")
    if reference_remote is not None and reference_remote.startswith("https://"):
        return f"https://github.com/{organization}/{name}.git"
    return f"git@github.com:{organization}/{name}.git"


def validate_core_owner(repository_policy: dict[str, Any], topology_policy: dict[str, Any]) -> str:
    """Reject cross-organization backings even if a broad schema accepts them."""
    organization = repository_policy.get("organization")
    if not isinstance(organization, str) or not _OWNER.fullmatch(organization):
        raise CorePolicyError("invalid protected organization")
    for node in topology_policy.get("nodes", {}).values():
        for binding in node.get("backing_bindings", []):
            approved_remote(binding["repository"], organization)
    return organization
