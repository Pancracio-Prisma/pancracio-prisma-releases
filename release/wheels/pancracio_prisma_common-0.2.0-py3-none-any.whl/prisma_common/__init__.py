"""Self-hosted preparation tools for Pancracio Prisma."""

__version__ = "0.2.0"
