"""Derive Pancracio 1.4 authorized/materialized graph metadata from Core."""

from __future__ import annotations

import hashlib
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator, FormatChecker

from .context_topology import topology_from_core
from .identity import VerifiedActor
from .node_authority import NodeAuthority
from .registry import CoreRegistry


class GraphManifestError(ValueError):
    pass


def _schema() -> dict[str, Any]:
    from prisma_common.intake import _schema as common_schema
    return common_schema("context-graph-manifest.schema.json")


def validate_graph_manifest(manifest: dict[str, Any]) -> None:
    errors = list(Draft202012Validator(_schema(), format_checker=FormatChecker()).iter_errors(manifest))
    if errors:
        raise GraphManifestError(f"Context Graph Manifest invalid: {errors[0].message}")
    if any("." in Path(row["path"]).parts or ".." in Path(row["path"]).parts
           for row in manifest["materialized_bindings"].values()):
        raise GraphManifestError("Context Graph Manifest contains unsafe backing path")


def derive_graph_manifest(actor: VerifiedActor, registry: CoreRegistry, *, runtime_id: str,
                          personal_mode: str, personal_remote: str | None,
                          gateway_status: str, sync_state: str,
                          core_commit: str,
                          requested_nodes: frozenset[str] = frozenset()) -> dict[str, Any]:
    """Produce a candidate manifest; no clone or local path can add authority."""
    authority = NodeAuthority(registry)
    graph = authority.graph
    try:
        principals = graph.actor_principals(actor, registry)
    except Exception as exc:
        raise GraphManifestError("verified Actor/Registry binding failed") from exc
    discoverable = sorted(node_id for node_id, node in graph.nodes.items()
                          if node.owner_class == "organization"
                          and graph.decide_actor(actor, registry, node_id, "discover").allowed)
    anchors = sorted({anchor.node_id for anchor in graph.anchors if anchor.principal_id in principals})
    if not requested_nodes.issubset(discoverable) or any(
            not graph.decide_actor(actor, registry, node_id, "read").allowed for node_id in requested_nodes):
        raise GraphManifestError("requested node outside readable authorized graph")
    policy = registry.topology_policy
    assert policy is not None
    selected = set(requested_nodes)
    selected.update(node_id for node_id in discoverable
                    if policy["nodes"][node_id]["materialization"] == "eager"
                    and graph.decide_actor(actor, registry, node_id, "read").allowed)
    mounts: dict[str, dict[str, Any]] = {}
    for node_id in sorted(selected):
        for item in policy["nodes"][node_id]["backing_bindings"]:
            surfaces = item["surfaces"]
            if not surfaces:
                raise GraphManifestError("binding without surfaces")
            for surface in surfaces:
                decision = authority.decide(actor, node_id, surface, "materialize",
                                            generation=item["generation"], store_id=item["store_id"])
                if not decision.allowed:
                    raise GraphManifestError("selected binding lacks materialization capability")
            mounts[item["store_id"]] = {"node_id": node_id, "path": item["local_path"],
                                        "repository": item["repository"], "generation": item["generation"],
                                        "state": "MATERIALIZED"}
    if personal_mode not in {"local", "private"} or (personal_mode == "local") != (personal_remote is None):
        raise GraphManifestError("Personal storage mode/remote mismatch")
    manifest = {"schema_version": 3, "architecture_version": "1.4", "state": "RUNTIME_COMPOSED",
                "runtime_id": runtime_id, "actor_id": actor.actor_id,
                "google_subject_sha256": hashlib.sha256(actor.google_subject.encode("utf-8")).hexdigest(),
                "role": actor.role, "core_commit": core_commit, "topology_schema_version": 1,
                "anchors": anchors, "authorized_nodes": discoverable,
                "materialized_bindings": mounts,
                "personal": {"owner_actor_id": actor.actor_id, "path": "domains/actor",
                             "mode": personal_mode, "remote": personal_remote, "state": "MATERIALIZED"},
                "gateway": {"status": gateway_status}, "sync": {"state": sync_state}}
    validate_graph_manifest(manifest)
    return manifest


def verify_graph_manifest(manifest: dict[str, Any], actor: VerifiedActor, registry: CoreRegistry,
                          *, expected_core_commit: str) -> None:
    """Reject local privilege expansion by comparing exact protected derivation."""
    validate_graph_manifest(manifest)
    if manifest["core_commit"] != expected_core_commit:
        raise GraphManifestError("manifest Core commit is stale or untrusted")
    if manifest["actor_id"] != actor.actor_id:
        raise GraphManifestError("manifest Actor differs from verified Actor")
    candidate = derive_graph_manifest(actor, registry, runtime_id=manifest["runtime_id"],
                                      personal_mode=manifest["personal"]["mode"],
                                      personal_remote=manifest["personal"]["remote"],
                                      gateway_status=manifest["gateway"]["status"],
                                      sync_state=manifest["sync"]["state"],
                                      core_commit=manifest["core_commit"],
                                      requested_nodes=frozenset(item["node_id"]
                                                                for item in manifest["materialized_bindings"].values()))
    for key in ("schema_version", "architecture_version", "state", "actor_id", "google_subject_sha256",
                "role", "topology_schema_version", "anchors", "authorized_nodes", "materialized_bindings", "personal"):
        if manifest[key] != candidate[key]:
            raise GraphManifestError("manifest differs from protected graph derivation")
