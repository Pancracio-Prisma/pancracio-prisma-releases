"""Prisma release lifecycle boundary.

The old Pancracio updater was tied to a different product repository. Prisma
must use its own publisher-signed artifacts and per-instance environment.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any


class UpgradeBlocked(ValueError):
    pass


def upgrade(workspace: Path, *, check_only: bool = False,
            release: dict[str, Any] | None = None,
            _recovery_checkpoint: Path | None = None) -> dict[str, Any]:
    raise UpgradeBlocked("Prisma release channel is not configured")


def recover(workspace: Path) -> dict[str, Any]:
    raise UpgradeBlocked("Prisma release channel is not configured")
