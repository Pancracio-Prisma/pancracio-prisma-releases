"""Audience-safe derived attention from authorized durable node surfaces."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import subprocess

import yaml

from .context_manifest14 import verify_graph_manifest
from .identity import VerifiedActor
from .materialization14 import _local, _verify_binding
from .node_authority import NodeAuthority
from .registry import CoreRegistry


@dataclass(frozen=True)
class AttentionItem:
    node_id: str
    kind: str
    source_path: str
    source_commit: str
    summary: str


@dataclass(frozen=True)
class AttentionView:
    items: tuple[AttentionItem, ...]
    materialized_nodes_checked: int
    authorized_nodes_total: int
    partial: bool


def _head(root: Path) -> str:
    result = subprocess.run(['git', '-C', str(root), 'rev-parse', 'HEAD'], capture_output=True, text=True)
    if result.returncode:
        raise ValueError('attention source Git unavailable')
    return result.stdout.strip()


def derive_attention(workspace: Path, actor: VerifiedActor, registry: CoreRegistry,
                     manifest: dict, *, expected_core_commit: str,
                     max_items: int = 25) -> AttentionView:
    verify_graph_manifest(manifest, actor, registry, expected_core_commit=expected_core_commit)
    if not 1 <= max_items <= 100:
        raise ValueError('attention budget invalid')
    authority = NodeAuthority(registry)
    mounted = manifest['materialized_bindings']
    items: list[AttentionItem] = []
    inspected: set[str] = set()
    eligible: set[str] = set()
    for node_id in manifest['authorized_nodes']:
        if not authority.graph.decide_actor(actor, registry, node_id, 'inspect_activity').allowed:
            continue
        for surface, kind in [('Contributions', 'PENDING_CONTRIBUTION'),
                              ('Work', 'OPEN_WORK'), ('State', 'BLOCKER')]:
            binding = authority.by_surface.get((node_id, surface))
            if binding is None:
                continue
            eligible.add(node_id)
            if binding.store_id not in mounted:
                continue
            inspected.add(node_id)
            root = _local(workspace.resolve(strict=True), binding.local_path)
            _verify_binding(root, binding)
            folder = root / surface
            if not folder.is_dir() or folder.is_symlink():
                continue
            commit = _head(root)
            for path in sorted(folder.rglob('*.yaml')):
                if len(items) >= max_items or path.is_symlink():
                    break
                relative = path.relative_to(root).as_posix()
                if not authority.decide_path(actor, binding.store_id, relative, 'read').allowed:
                    continue
                try:
                    data = yaml.safe_load(path.read_text(encoding='utf-8'))
                except (OSError, yaml.YAMLError):
                    continue
                if not isinstance(data, dict) or data.get('node_id', data.get('owning_node_id', data.get('source_node_id'))) != node_id:
                    continue
                if surface == 'Contributions' and data.get('status') == 'proposed':
                    summary = f"Pending Contribution {data.get('contribution_id', '')}"
                elif surface == 'Work' and data.get('status') in {'OPEN', 'BLOCKED'}:
                    summary = str(data.get('title', 'Open Work Item'))[:160]
                elif surface == 'State' and data.get('kind') == 'blocker':
                    summary = str(data.get('summary', 'Blocker'))[:160]
                else:
                    continue
                items.append(AttentionItem(node_id, kind, str(path), commit, summary))
    return AttentionView(tuple(items), len(inspected), len(manifest['authorized_nodes']),
                         len(inspected) < len(eligible))
