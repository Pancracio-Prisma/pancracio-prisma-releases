"""Deterministic repository and surface authority for verified Actors."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path, PurePosixPath, PureWindowsPath
import subprocess
from typing import Literal

import yaml

from .identity import VerifiedActor, actor_matches_registry
from .registry import CoreRegistry

Operation = Literal["read", "write", "commit", "push"]


class AuthorityDenied(PermissionError):
    pass


@dataclass(frozen=True)
class Decision:
    allowed: bool
    reason: str


class RepositoryAuthority:
    def __init__(self, registry: CoreRegistry):
        self.registry = registry

    def decide(self, actor: VerifiedActor, repo_type: str, operation: Operation,
               *, path: str = "", target_actor_id: str | None = None) -> Decision:
        if not isinstance(actor, VerifiedActor) or actor.actor_id not in self.registry.actors:
            return Decision(False, "verified Actor required")
        record = self.registry.actors[actor.actor_id]
        if not actor_matches_registry(actor, record):
            return Decision(False, "Actor/Registry mismatch")
        policy = self.registry.repository_policy["repositories"].get(repo_type)
        if policy is None or operation not in {"read", "write", "commit", "push"}:
            return Decision(False, "unknown repository or operation")
        if operation != "read" and _forbidden_versioned_path(repo_type, path):
            return Decision(False, "path is local, secret, or outside repository authority")
        if policy.get("actor_scoped") and target_actor_id != actor.actor_id:
            return Decision(False, "Actor Knowledge belongs to another Actor")
        if operation not in policy["roles"].get(actor.role, []):
            return Decision(False, "role has no repository operation authority")
        return Decision(True, "authorized")

    def require(self, actor: VerifiedActor, repo_type: str, operation: Operation, **kwargs: object) -> None:
        decision = self.decide(actor, repo_type, operation, **kwargs)
        if not decision.allowed:
            raise AuthorityDenied(decision.reason)


def _forbidden_versioned_path(repo_type: str, path: str) -> bool:
    if not path:
        return False
    normalized = path.replace("\\", "/")
    parts = PurePosixPath(normalized).parts
    if not parts:
        return True
    folded = tuple(part.casefold() for part in parts)
    if normalized.startswith("/") or PureWindowsPath(path).is_absolute() or ".." in parts or ".git" in folded:
        return True
    if len(normalized) > 240 or any(
        not part or any(ord(char) < 32 or char in '<>:"|?*' for char in part) or part.endswith((" ", "."))
        or part.split(".", 1)[0].casefold() in {"con", "prn", "aux", "nul", *(f"com{i}" for i in range(1, 10)), *(f"lpt{i}" for i in range(1, 10))}
        for part in parts
    ):
        return True
    name = parts[-1].lower() if parts else ""
    if name.startswith(".env") or name.endswith((".pem", ".key", ".p12", ".pfx")) or "client_secret" in name or "oauth_client" in name:
        return True
    if repo_type == "workspace":
        if folded[0] in {"domains", ".panky"}:
            return True
        if len(parts) >= 2 and folded[0] == ".obsidian" and (folded[1].startswith("workspace") or folded[1] in {"graph.json", "cache", ".cache", "trash"}):
            return True
    return False


class GuardedRepository:
    """Mutation gateway used by Panky code; direct human Git use is out of scope."""

    def __init__(self, root: Path, authority: RepositoryAuthority, *, fixture: bool = False):
        self.root = root.resolve(strict=True)
        self.authority = authority
        if (self.root / "panky.yaml").is_file():
            marker = yaml.safe_load((self.root / "panky.yaml").read_text(encoding="utf-8"))
            self.repo_type = marker["workspace"]["repo_type"]
        elif (self.root / "repo.yaml").is_file():
            marker = yaml.safe_load((self.root / "repo.yaml").read_text(encoding="utf-8"))
            self.repo_type = marker["repo_type"]
        else:
            raise AuthorityDenied("repository marker missing")
        if self.repo_type not in authority.registry.repository_policy["repositories"]:
            raise AuthorityDenied("unknown repository marker")
        if not fixture:
            # A local marker alone cannot relabel Core or Workspace as a less
            # restricted repository. Production callers must bind it to origin.
            expected = authority.registry.repository_policy["repositories"][self.repo_type].get("remote")
            if not expected:
                raise AuthorityDenied("repository origin binding is not implemented for this repository type")
            actual = self._git("remote", "get-url", "origin")
            if actual not in {f"git@github.com:{expected}.git", f"https://github.com/{expected}.git"}:
                raise AuthorityDenied("repository origin does not match protected policy")
            if Path(self._git("rev-parse", "--show-toplevel")).resolve() != self.root:
                raise AuthorityDenied("repository root does not match marker")

    def write_bytes(self, actor: VerifiedActor, relative_path: str, content: bytes,
                    *, target_actor_id: str | None = None) -> None:
        target = (self.root / relative_path).resolve()
        if not target.is_relative_to(self.root) or target == self.root:
            raise AuthorityDenied("path escapes repository")
        self.authority.require(actor, self.repo_type, "write", path=relative_path,
                               target_actor_id=target_actor_id)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(content)

    def commit(self, actor: VerifiedActor, message: str, *, target_actor_id: str | None = None) -> None:
        paths = [item for item in self._git("diff", "--cached", "--name-only", "-z").split("\0") if item]
        if not paths:
            raise AuthorityDenied("nothing staged")
        for path in paths:
            self.authority.require(actor, self.repo_type, "commit", path=path,
                                   target_actor_id=target_actor_id)
            self._check_git_entry(path, staged=True)
        self._git("commit", "-m", message)

    def push(self, actor: VerifiedActor, *, target_actor_id: str | None = None) -> None:
        paths = [item for item in self._git("diff", "--name-only", "-z", "origin/main...HEAD").split("\0") if item]
        if not paths:
            raise AuthorityDenied("no changed paths to push")
        for path in paths:
            self.authority.require(actor, self.repo_type, "push", path=path,
                                   target_actor_id=target_actor_id)
            self._check_git_entry(path, staged=False)
        self._git("push", "origin", "HEAD:main")

    def _check_git_entry(self, path: str, *, staged: bool) -> None:
        if staged:
            rows = self._git("ls-files", "--stage", "-z").split("\0")
        else:
            rows = self._git("ls-tree", "-rz", "HEAD").split("\0")
        entries = [row for row in rows if row and "\t" in row and row.split("\t", 1)[1] == path]
        if len(entries) != 1:
            raise AuthorityDenied("Git deletion or ambiguous entry requires separate governance")
        mode = entries[0].split(" ", 1)[0]
        if mode not in {"100644", "100755"}:
            raise AuthorityDenied("Git symlink or submodule cannot be committed by Panky")

    def _git(self, *args: str) -> str:
        result = subprocess.run(["git", "-C", str(self.root), *args], capture_output=True, text=True)
        if result.returncode:
            raise AuthorityDenied("Git operation failed; local work preserved")
        return result.stdout.strip()
