"""Context Event pull worker and portable lifecycle descriptors."""

from __future__ import annotations

from dataclasses import asdict
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import plistlib
import re
import subprocess
import sys
import tempfile
import time
from typing import Any
from xml.etree import ElementTree
from xml.sax.saxutils import escape

from filelock import FileLock, Timeout

from .context_sync import SyncError, handle_event, parse_event
from .sync_transport import (
    TransportError, acknowledge, decode_message, extend_ack_deadline, pull, subscription_id,
)
from .composition import _read_yaml
from .processes import background_creationflags


class WorkerError(ValueError):
    pass


def _state_dir(workspace: Path) -> Path:
    path = workspace / ".panky" / "sync"
    if path.is_symlink():
        raise WorkerError("sync state path is unsafe")
    path.mkdir(parents=True, exist_ok=True)
    return path


def _record(workspace: Path, *, repository_id: str, before: str, result: str,
            event_type: str = "repo_updated", error_code: str | None = None) -> None:
    path = _state_dir(workspace) / "operations.jsonl"
    owner = _read_yaml(workspace / ".panky" / "owner.yaml") or {}
    item = {"timestamp": datetime.now(timezone.utc).isoformat(), "runtime_id": owner.get("runtime_id"),
            "repository_id": repository_id, "event_type": event_type, "before": before,
            "result": result, "error_code": error_code}
    descriptor = os.open(path, os.O_CREAT | os.O_WRONLY | os.O_APPEND, 0o600)
    with os.fdopen(descriptor, "a", encoding="utf-8") as stream:
        stream.write(json.dumps(item, sort_keys=True) + "\n")


def recent_results(workspace: Path) -> dict[str, str]:
    path = workspace / ".panky" / "sync" / "operations.jsonl"
    if not path.is_file() or path.is_symlink():
        return {}
    results: dict[str, str] = {}
    for line in path.read_text(encoding="utf-8").splitlines()[-100:]:
        try:
            item = json.loads(line)
            if isinstance(item.get("repository_id"), str) and isinstance(item.get("result"), str):
                results[item["repository_id"]] = item["result"]
        except (ValueError, TypeError):
            continue
    return results


def governance_pending_count(workspace: Path) -> int | None:
    """Local notice only; the Actor-scoped Gateway inbox is authoritative."""
    path = workspace / ".panky" / "sync" / "governance_pending.json"
    if path.is_symlink() or not path.is_file():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return len(data["request_ids"]) if isinstance(data.get("request_ids"), list) else None
    except (OSError, ValueError, TypeError):
        return None


def _poll_governance(workspace: Path) -> None:
    mode = workspace / ".panky" / "gateway-auth-mode"
    if mode.is_symlink() or not mode.is_file() or mode.read_text(encoding="utf-8").strip() != "oidc":
        return
    from .context_catalog20 import governance_inbox
    inbox = governance_inbox(workspace / ".panky")
    ids = sorted({str(item[key]) for group, key in (
        ("share_requests", "request_id"), ("founder_transfers", "transfer_id"))
        for item in inbox[group]})
    path = _state_dir(workspace) / "governance_pending.json"
    temporary = path.with_suffix(".tmp")
    descriptor = os.open(temporary, os.O_CREAT | os.O_WRONLY | os.O_TRUNC, 0o600)
    with os.fdopen(descriptor, "w", encoding="utf-8") as stream:
        json.dump({"checked_at": datetime.now(timezone.utc).isoformat(),
                   "request_ids": ids}, stream, sort_keys=True)
    os.replace(temporary, path)


def _heartbeat(workspace: Path) -> None:
    path = _state_dir(workspace) / "heartbeat.json"
    temporary = path.with_suffix(".tmp")
    descriptor = os.open(temporary, os.O_CREAT | os.O_WRONLY | os.O_TRUNC, 0o600)
    with os.fdopen(descriptor, "w", encoding="utf-8") as stream:
        supervisor = os.environ.get("PANKY_SYNC_SUPERVISOR_PID")
        json.dump({"timestamp": time.time(), "pid": os.getpid(),
                   "supervisor_pid": int(supervisor) if supervisor and supervisor.isdigit() else None}, stream)
    os.replace(temporary, path)


def heartbeat_ready(workspace: Path, *, max_age_seconds: float = 60, expected_pid: int | None = None) -> bool:
    path = workspace / ".panky" / "sync" / "heartbeat.json"
    if path.is_symlink() or not path.is_file():
        return False
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return (isinstance(data.get("timestamp"), (int, float))
                and 0 <= time.time() - data["timestamp"] <= max_age_seconds
                and (expected_pid is None or expected_pid in (data.get("pid"), data.get("supervisor_pid"))))
    except (OSError, ValueError, TypeError):
        return False


def _heartbeat_process_alive(workspace: Path) -> bool:
    path = workspace / ".panky" / "sync" / "heartbeat.json"
    try:
        pid = json.loads(path.read_text(encoding="utf-8"))["pid"]
        if not isinstance(pid, int) or pid <= 0:
            return False
        if sys.platform == "win32":
            import ctypes
            from ctypes import wintypes
            kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
            kernel32.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
            kernel32.OpenProcess.restype = wintypes.HANDLE
            kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
            kernel32.CloseHandle.restype = wintypes.BOOL
            kernel32.GetExitCodeProcess.argtypes = [wintypes.HANDLE, ctypes.POINTER(wintypes.DWORD)]
            kernel32.GetExitCodeProcess.restype = wintypes.BOOL
            handle = kernel32.OpenProcess(0x1000, False, pid)  # PROCESS_QUERY_LIMITED_INFORMATION
            if handle:
                try:
                    exit_code = wintypes.DWORD()
                    return bool(kernel32.GetExitCodeProcess(handle, ctypes.byref(exit_code))
                                and exit_code.value == 259)  # STILL_ACTIVE
                finally:
                    kernel32.CloseHandle(handle)
            return ctypes.get_last_error() == 5  # Access denied still proves the PID exists.
        os.kill(pid, 0)
        return True
    except PermissionError:
        return True
    except (OSError, ValueError, TypeError, KeyError):
        return False


def run_once(workspace: Path, *, pull_messages=pull, ack=acknowledge,
             lease=extend_ack_deadline) -> int:
    """ACK invalid/unauthorized hints; Git remains the retry/freshness authority."""
    workspace = workspace.resolve()
    received = pull_messages(workspace)
    def ack_ref(item):
        ack_id = item.get("ackId")
        if not isinstance(ack_id, str) or not ack_id:
            return None
        name = item.get("_panky_subscription")
        return (ack_id, name) if isinstance(name, str) else ack_id

    ack_ids = [ref for item in received if (ref := ack_ref(item)) is not None]
    lease(workspace, ack_ids)
    processed_ack_ids: list[str | tuple[str, str]] = []
    for item in received:
        ack_id = item.get("ackId")
        if not isinstance(ack_id, str) or not ack_id:
            continue
        ref = ack_ref(item)
        try:
            event = parse_event(decode_message(item))
        except (SyncError, TransportError):
            _record(workspace, repository_id="invalid", before="INVALID_EVENT", result="IGNORED",
                    error_code="INVALID_EVENT")
            processed_ack_ids.append(ref)
            continue
        try:
            result = handle_event(workspace, event)
            _record(workspace, repository_id=event["repository_id"], before=result.before,
                    result=result.result)
            if result.result == "REVOKED":
                return -1
            if event["repository_id"] == "pancracio-context" and result.result != "CURRENT":
                continue
        except (SyncError, OSError, ValueError):
            _record(workspace, repository_id=event["repository_id"], before="UNAVAILABLE",
                    result="DEGRADED", error_code="CONTEXT_OR_GIT_UNAVAILABLE")
            if event["repository_id"] == "pancracio-context":
                continue
        processed_ack_ids.append(ref)
    ack(workspace, processed_ack_ids)
    return len(processed_ack_ids)


def run_forever(workspace: Path, *, interval: float = 5.0) -> None:
    workspace = workspace.resolve()
    lock = FileLock(_state_dir(workspace) / "worker.lock")
    try:
        lock.acquire(timeout=0)
    except Timeout as exc:
        # Windows Task Scheduler can start the same persistent task again for
        # its periodic trigger even while the original worker still owns the
        # runtime. Give a newly started owner time to publish its first
        # heartbeat before deciding whether the lock holder is healthy.
        for _ in range(20):
            if heartbeat_ready(workspace) and _heartbeat_process_alive(workspace):
                return
            time.sleep(0.25)
        raise WorkerError("another Context Sync worker already owns this runtime") from exc
    try:
        # A remote validation can legitimately take longer than launchd's
        # Advertise liveness only after this worker owns its instance lock.
        _heartbeat(workspace)
        next_governance_check = 0.0
        while True:
            try:
                if run_once(workspace) == -1:
                    return
            except TransportError:
                _record(workspace, repository_id="transport", before="UNAVAILABLE",
                        result="DEGRADED", error_code="TRANSPORT_UNAVAILABLE")
            if time.monotonic() >= next_governance_check:
                next_governance_check = time.monotonic() + 60
                try:
                    _poll_governance(workspace)
                except (OSError, ValueError, KeyError, TypeError):
                    pass
            _heartbeat(workspace)
            time.sleep(interval)
    finally:
        lock.release()


def _instance_layout(workspace: Path) -> dict[str, Any]:
    from prisma_common.installed_binding import load_installed_binding
    from prisma_common.instance import layouts
    return layouts(load_installed_binding(workspace)["intake"])


def _require_active_instance_interpreter(workspace: Path) -> None:
    """A background service must never be registered from the setup Python."""
    from prisma_common.installed_binding import runtime_directory

    _, runtime = runtime_directory(workspace)
    pointer = runtime / "active-release.json"
    if pointer.is_symlink() or not pointer.is_file():
        raise WorkerError("active Prisma release is required for service registration")
    try:
        value = json.loads(pointer.read_text(encoding="utf-8"))
        version = value["version"]
        if not isinstance(version, str) or not re.fullmatch(r"[0-9]+\.[0-9]+\.[0-9]+", version):
            raise ValueError
    except (OSError, ValueError, KeyError, TypeError) as exc:
        raise WorkerError("active Prisma release pointer is invalid") from exc
    selected = runtime / "versions" / version / "venv" / ("Scripts/python.exe" if sys.platform == "win32" else "bin/python")
    if not selected.is_file() or Path(sys.executable).absolute() != selected.absolute():
        raise WorkerError("run service registration from this instance's active Prisma executable")


def launchagent_label(workspace: Path) -> str:
    return _instance_layout(workspace)["macos"]["launch_agent_label"]


def windows_task_name(workspace: Path) -> str:
    return _instance_layout(workspace)["windows"]["task_name"]


def macos_plist(workspace: Path, runtime_id: str, *, executable: str | None = None) -> dict[str, Any]:
    logs = _state_dir(workspace) / "logs"
    logs.mkdir(parents=True, exist_ok=True)
    return {"Label": launchagent_label(workspace), "ProgramArguments": [executable or sys.executable,
            "-m", "pancracio.sync_worker", "--workspace", str(workspace), "run"],
            "WorkingDirectory": str(workspace), "RunAtLoad": True, "KeepAlive": True,
            "ThrottleInterval": 10, "StandardOutPath": str(logs / "stdout.log"),
            "StandardErrorPath": str(logs / "stderr.log"), "Umask": 0o077}


def windows_task_command(workspace: Path, *, executable: str | None = None) -> str:
    selected, arguments = _windows_task_action(workspace, executable=executable)
    return subprocess.list2cmdline([selected, *arguments])


def _windows_task_action(workspace: Path, *, executable: str | None = None) -> tuple[str, list[str]]:
    selected = Path(executable or sys.executable)
    windowless = selected.with_name("pythonw.exe")
    if windowless.is_file():
        selected = windowless
    return str(selected), ["-m", "pancracio.sync_worker", "--workspace", str(workspace), "run"]


def windows_task_xml(workspace: Path, user_id: str, *, executable: str | None = None) -> str:
    """Run one worker and let periodic probes replace it after a crash."""
    command, arguments = _windows_task_action(workspace, executable=executable)
    argument_line = subprocess.list2cmdline(arguments)
    return f'''<?xml version="1.0" encoding="UTF-16"?>
<Task version="1.4" xmlns="http://schemas.microsoft.com/windows/2004/02/mit/task">
  <RegistrationInfo><Description>Pancracio Context Sync worker</Description></RegistrationInfo>
  <Triggers>
    <LogonTrigger><Enabled>true</Enabled></LogonTrigger>
    <TimeTrigger>
      <Repetition><Interval>PT5M</Interval><StopAtDurationEnd>false</StopAtDurationEnd></Repetition>
      <StartBoundary>2000-01-01T00:00:00</StartBoundary><Enabled>true</Enabled>
    </TimeTrigger>
  </Triggers>
  <Principals><Principal id="Author"><UserId>{escape(user_id)}</UserId>
    <LogonType>InteractiveToken</LogonType><RunLevel>LeastPrivilege</RunLevel>
  </Principal></Principals>
  <Settings>
    <MultipleInstancesPolicy>Parallel</MultipleInstancesPolicy>
    <DisallowStartIfOnBatteries>false</DisallowStartIfOnBatteries>
    <StopIfGoingOnBatteries>false</StopIfGoingOnBatteries>
    <AllowHardTerminate>true</AllowHardTerminate><StartWhenAvailable>true</StartWhenAvailable>
    <RunOnlyIfNetworkAvailable>false</RunOnlyIfNetworkAvailable>
    <IdleSettings><StopOnIdleEnd>false</StopOnIdleEnd><RestartOnIdle>true</RestartOnIdle></IdleSettings>
    <AllowStartOnDemand>true</AllowStartOnDemand><Enabled>true</Enabled><Hidden>false</Hidden>
    <RunOnlyIfIdle>false</RunOnlyIfIdle><WakeToRun>false</WakeToRun>
    <ExecutionTimeLimit>PT0S</ExecutionTimeLimit><Priority>7</Priority>
    <RestartOnFailure><Interval>PT1M</Interval><Count>999</Count></RestartOnFailure>
  </Settings>
  <Actions Context="Author"><Exec><Command>{escape(command)}</Command>
    <Arguments>{escape(argument_line)}</Arguments>
  </Exec></Actions>
</Task>'''


def _windows_task_is_current(document: str, workspace: Path, *, executable: str | None = None) -> bool:
    try:
        root = ElementTree.fromstring(document)
    except ElementTree.ParseError:
        return False
    namespace = {'t': 'http://schemas.microsoft.com/windows/2004/02/mit/task'}
    command, arguments = _windows_task_action(workspace, executable=executable)
    expected = {
        './/t:Command': command,
        './/t:Arguments': subprocess.list2cmdline(arguments),
        './/t:DisallowStartIfOnBatteries': 'false',
        './/t:StopIfGoingOnBatteries': 'false',
        './/t:ExecutionTimeLimit': 'PT0S',
        './/t:RestartOnFailure/t:Interval': 'PT1M',
        './/t:RestartOnFailure/t:Count': '999',
        './/t:MultipleInstancesPolicy': 'Parallel',
        './/t:LogonTrigger/t:Enabled': 'true',
        './/t:TimeTrigger/t:Repetition/t:Interval': 'PT5M',
    }
    return all((element := root.find(path, namespace)) is not None and element.text == value
               for path, value in expected.items())


def _windows_user_id() -> str:
    result = subprocess.run(['whoami'], capture_output=True, text=True,
                            creationflags=background_creationflags())
    if result.returncode or not result.stdout.strip():
        raise WorkerError('Windows task owner is unavailable')
    return result.stdout.strip()


def _ensure_windows_task(workspace: Path, name: str, *, executable: str | None = None) -> bool:
    """Install or repair the task definition. Return whether registration changed."""
    existing = _run_schtasks(['/Query', '/TN', name, '/XML'], capture_output=True, text=True)
    if existing.returncode == 0 and _windows_task_is_current(existing.stdout, workspace,
                                                              executable=executable):
        return False
    if existing.returncode == 0:
        raise WorkerError("Windows task name is already occupied by a different definition")
    document = windows_task_xml(workspace, _windows_user_id(), executable=executable)
    with tempfile.TemporaryDirectory(prefix='panky-windows-task-') as directory:
        path = Path(directory) / 'task.xml'
        path.write_text(document, encoding='utf-16')
        create = ['schtasks', '/Create', '/TN', name, '/XML', str(path)]
        proc = _run_schtasks(create[1:], capture_output=True)
        if proc.returncode and _run_windows_elevated(create):
            raise WorkerError('Windows worker task installation failed')
    return True


def _run_windows_elevated(command: list[str]) -> int:
    """Run one bounded Windows command through the native UAC consent dialog."""
    import ctypes
    from ctypes import wintypes

    class ShellExecuteInfo(ctypes.Structure):
        _fields_ = [
            ("cbSize", wintypes.DWORD), ("fMask", wintypes.ULONG),
            ("hwnd", wintypes.HWND), ("lpVerb", wintypes.LPCWSTR),
            ("lpFile", wintypes.LPCWSTR), ("lpParameters", wintypes.LPCWSTR),
            ("lpDirectory", wintypes.LPCWSTR), ("nShow", ctypes.c_int),
            ("hInstApp", wintypes.HINSTANCE), ("lpIDList", ctypes.c_void_p),
            ("lpClass", wintypes.LPCWSTR), ("hkeyClass", wintypes.HKEY),
            ("dwHotKey", wintypes.DWORD), ("hIconOrMonitor", wintypes.HANDLE),
            ("hProcess", wintypes.HANDLE),
        ]

    shell32 = ctypes.WinDLL("shell32", use_last_error=True)
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    shell_execute = shell32.ShellExecuteExW
    shell_execute.argtypes = [ctypes.POINTER(ShellExecuteInfo)]
    shell_execute.restype = wintypes.BOOL
    info = ShellExecuteInfo()
    info.cbSize = ctypes.sizeof(info)
    info.fMask = 0x00000040  # SEE_MASK_NOCLOSEPROCESS
    info.lpVerb = "runas"
    info.lpFile = command[0]
    info.lpParameters = subprocess.list2cmdline(command[1:])
    info.nShow = 0
    if not shell_execute(ctypes.byref(info)):
        error = ctypes.get_last_error()
        if error == 1223:
            raise WorkerError("Windows worker task installation was canceled at the UAC prompt")
        raise WorkerError(f"Windows worker task elevation failed ({error})")
    try:
        kernel32.WaitForSingleObject(info.hProcess, 0xFFFFFFFF)
        exit_code = wintypes.DWORD()
        if not kernel32.GetExitCodeProcess(info.hProcess, ctypes.byref(exit_code)):
            raise WorkerError("Windows worker task elevation result is unavailable")
        return int(exit_code.value)
    finally:
        kernel32.CloseHandle(info.hProcess)


def _run_schtasks(arguments: list[str], **kwargs: Any) -> subprocess.CompletedProcess:
    """Run Task Scheduler's console client without flashing terminal windows."""
    return subprocess.run(
        ["schtasks", *arguments],
        creationflags=background_creationflags(),
        **kwargs,
    )


def _wait_for_worker_stop(workspace: Path, *, attempts: int = 40, delay: float = 0.25) -> None:
    """Wait until the previous worker releases its cross-process ownership lock."""
    lock = FileLock(_state_dir(workspace) / "worker.lock")
    for _ in range(attempts):
        try:
            lock.acquire(timeout=0)
        except Timeout:
            time.sleep(delay)
            continue
        lock.release()
        return
    raise WorkerError("previous Context Sync worker did not stop")


def install_lifecycle(workspace: Path) -> str:
    _require_active_instance_interpreter(workspace)
    owner = _read_yaml(workspace / ".panky" / "owner.yaml")
    if not owner:
        raise WorkerError("runtime owner unavailable")
    runtime_id = owner["runtime_id"]
    if sys.platform == "darwin":
        label = launchagent_label(workspace)
        path = Path.home() / "Library" / "LaunchAgents" / f"{label}.plist"
        path.parent.mkdir(parents=True, exist_ok=True)
        desired = macos_plist(workspace, runtime_id)
        if path.is_file() and lifecycle_status(workspace) == "RUNNING":
            try:
                with path.open("rb") as stream:
                    if plistlib.load(stream) == desired:
                        return label
            except (OSError, ValueError):
                pass
        if path.exists() or path.is_symlink():
            raise WorkerError("macOS LaunchAgent name is already occupied")
        with path.open("xb") as stream:
            plistlib.dump(desired, stream)
        os.chmod(path, 0o600)
        uid = os.getuid()
        subprocess.run(["launchctl", "bootout", f"gui/{uid}/{label}"], capture_output=True)
        for _ in range(20):
            registered = subprocess.run(["launchctl", "print", f"gui/{uid}/{label}"], capture_output=True)
            if registered.returncode:
                break
            time.sleep(0.25)
        else:
            raise WorkerError("previous macOS LaunchAgent did not stop")
        proc = subprocess.run(["launchctl", "bootstrap", f"gui/{uid}", str(path)], capture_output=True)
        if proc.returncode:
            raise WorkerError("macOS LaunchAgent installation failed")
        for _ in range(15):
            if lifecycle_status(workspace) == "RUNNING":
                return label
            time.sleep(1)
        subprocess.run(["launchctl", "bootout", f"gui/{uid}/{label}"], capture_output=True)
        path.unlink(missing_ok=True)
        raise WorkerError("macOS worker did not complete a health heartbeat")
    if sys.platform == "win32":
        name = windows_task_name(workspace)
        changed = _ensure_windows_task(workspace, name)
        if not changed and lifecycle_status(workspace) == "RUNNING":
            return name
        (workspace / ".panky" / "sync" / "heartbeat.json").unlink(missing_ok=True)
        started = _run_schtasks(["/Run", "/TN", name], capture_output=True)
        if started.returncode:
            raise WorkerError("Windows worker task could not start")
        for _ in range(15):
            if lifecycle_status(workspace) == "RUNNING":
                return name
            time.sleep(1)
        raise WorkerError("Windows worker did not complete a health heartbeat")
    raise WorkerError("worker lifecycle supports macOS and Windows")


def lifecycle_status(workspace: Path) -> str:
    owner = _read_yaml(workspace / ".panky" / "owner.yaml")
    if not owner:
        return "NOT_ENROLLED"
    if sys.platform == "darwin":
        result = subprocess.run(["launchctl", "print", f"gui/{os.getuid()}/{launchagent_label(workspace)}"],
                                capture_output=True, text=True)
        if result.returncode or "state = running" not in result.stdout:
            return "STOPPED"
        match = re.search(r"\bpid = (\d+)", result.stdout)
        return "RUNNING" if match and heartbeat_ready(workspace, expected_pid=int(match.group(1))) else "STALLED"
    if sys.platform == "win32":
        name = windows_task_name(workspace)
        result = _run_schtasks(["/Query", "/TN", name, "/FO", "LIST"], capture_output=True, text=True)
        return ("RUNNING" if heartbeat_ready(workspace) and _heartbeat_process_alive(workspace)
                else "STALLED") if result.returncode == 0 else "STOPPED"
    return "UNSUPPORTED"


def lifecycle_stop(workspace: Path) -> None:
    owner = _read_yaml(workspace / ".panky" / "owner.yaml")
    if not owner:
        raise WorkerError("runtime owner unavailable")
    if sys.platform == "darwin":
        label = launchagent_label(workspace)
        proc = subprocess.run(["launchctl", "bootout", f"gui/{os.getuid()}/{label}"], capture_output=True)
    elif sys.platform == "win32":
        name = windows_task_name(workspace)
        proc = _run_schtasks(["/End", "/TN", name], capture_output=True)
    else:
        raise WorkerError("unsupported worker platform")
    if proc.returncode:
        raise WorkerError("Context Sync worker could not be stopped")


def uninstall_lifecycle(workspace: Path) -> None:
    """Remove only this runtime's stopped worker registration."""
    owner = _read_yaml(workspace / ".panky" / "owner.yaml")
    if not owner:
        raise WorkerError("runtime owner unavailable")
    if sys.platform == "darwin":
        label = launchagent_label(workspace)
        service = f"gui/{os.getuid()}/{label}"
        present = subprocess.run(["launchctl", "print", service], capture_output=True)
        if present.returncode == 0:
            stopped = subprocess.run(["launchctl", "bootout", service], capture_output=True)
            if stopped.returncode:
                raise WorkerError("macOS worker could not be unregistered")
        (Path.home() / "Library" / "LaunchAgents" / f"{label}.plist").unlink(missing_ok=True)
        return
    if sys.platform == "win32":
        name = windows_task_name(workspace)
        present = _run_schtasks(["/Query", "/TN", name], capture_output=True)
        if present.returncode == 0:
            delete = ["schtasks", "/Delete", "/F", "/TN", name]
            removed = _run_schtasks(delete[1:], capture_output=True)
            if removed.returncode and _run_windows_elevated(delete):
                raise WorkerError("Windows worker could not be unregistered")
        return
    raise WorkerError("unsupported worker platform")


def lifecycle_restart(workspace: Path) -> None:
    _require_active_instance_interpreter(workspace)
    owner = _read_yaml(workspace / ".panky" / "owner.yaml")
    if not owner:
        raise WorkerError("runtime owner unavailable")
    if sys.platform == "darwin":
        label = launchagent_label(workspace)
        registered = subprocess.run(["launchctl", "print", f"gui/{os.getuid()}/{label}"],
                                    capture_output=True)
        if registered.returncode:
            install_lifecycle(workspace)
            return
        proc = subprocess.run(["launchctl", "kickstart", "-k", f"gui/{os.getuid()}/{label}"], capture_output=True)
    elif sys.platform == "win32":
        name = windows_task_name(workspace)
        changed = _ensure_windows_task(workspace, name)
        if not changed:
            _run_schtasks(["/End", "/TN", name], capture_output=True)
            _wait_for_worker_stop(workspace)
        (workspace / ".panky" / "sync" / "heartbeat.json").unlink(missing_ok=True)
        proc = _run_schtasks(["/Run", "/TN", name], capture_output=True)
    else:
        raise WorkerError("unsupported worker platform")
    if proc.returncode:
        raise WorkerError("Context Sync worker could not be restarted")


def main() -> int:
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--workspace", type=Path, required=True)
    parser.add_argument("action", choices=["run", "once"])
    args = parser.parse_args()
    if sys.stdout is None or sys.stderr is None:
        logs = _state_dir(args.workspace.resolve()) / "logs"
        logs.mkdir(parents=True, exist_ok=True)
        if sys.stdout is None:
            sys.stdout = (logs / "stdout.log").open("a", encoding="utf-8", buffering=1)
        if sys.stderr is None:
            sys.stderr = (logs / "stderr.log").open("a", encoding="utf-8", buffering=1)
    try:
        if args.action == "run":
            run_forever(args.workspace)
        else:
            run_once(args.workspace)
        return 0
    except (WorkerError, TransportError, SyncError) as exc:
        print(f"Pancracio Context Sync worker: {exc}", file=sys.stderr)
        return 3


if __name__ == "__main__":
    raise SystemExit(main())
