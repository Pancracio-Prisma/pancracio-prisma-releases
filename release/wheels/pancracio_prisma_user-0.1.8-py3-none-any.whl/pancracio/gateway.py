"""Optional, local Gateway credential and safe connectivity probe."""

from __future__ import annotations

import json
import errno
from pathlib import Path
import sys
import time

import keyring
import requests
from . import __version__

class GatewayError(ValueError):
    pass


def gateway_endpoint(runtime_root: Path) -> str | None:
    from prisma_common.installed_binding import load_installed_binding
    try:
        gateway = load_installed_binding(runtime_root.parent)["resources"]["gateway"]
    except (OSError, ValueError) as exc:
        raise GatewayError("signed Gateway configuration is unavailable") from exc
    return gateway["endpoint"] if gateway["enabled"] else None


def gateway_api_base(runtime_root: Path) -> str:
    endpoint = gateway_endpoint(runtime_root)
    if not endpoint or not endpoint.endswith("/mcp/"):
        raise GatewayError("signed Gateway MCP endpoint is unavailable")
    return endpoint[:-4]


def _authorization_token(runtime_root: Path) -> str | None:
    """Use the signed instance endpoint and a cache scoped to this runtime."""
    mode_path = runtime_root / "gateway-auth-mode"
    if mode_path.is_symlink():
        raise GatewayError("Gateway authentication mode path is unsafe")
    mode = mode_path.read_text(encoding="utf-8").strip() if mode_path.exists() else ""
    if mode != "oidc":
        raise GatewayError("Gateway requires Google OIDC")
    from .composition import _read_yaml
    from .sync_transport import _fresh_google_id_token

    owner = _read_yaml(runtime_root / "owner.yaml")
    if not owner or not isinstance(owner.get("runtime_id"), str):
        raise GatewayError("runtime owner is unavailable")
    cache_key = owner["runtime_id"]
    try:
        cached = keyring.get_password("pancracio-prisma-gateway-access", cache_key)
    except Exception as exc:
        raise GatewayError("Gateway credential cache is unavailable") from exc
    if cached:
        try:
            record = json.loads(cached)
            if record["expires_at"] > time.time() + 30:
                return record["token"]
        except (KeyError, TypeError, ValueError):
            pass
    try:
        proof = _fresh_google_id_token(runtime_root.parent, allow_disabled=True)
        response = requests.post(
            gateway_api_base(runtime_root) + "auth/panky/exchange",
            json={"google_id_token": proof}, timeout=20,
        )
        response.raise_for_status()
        data = response.json()
        token, lifetime = data["access_token"], int(data["expires_in"])
        if not isinstance(token, str) or not token or not 30 <= lifetime <= 300:
            raise GatewayError("Gateway access token response is invalid")
    except (requests.RequestException, ValueError, KeyError, TypeError) as exc:
        raise GatewayError("Gateway OIDC exchange failed") from exc
    try:
        keyring.set_password("pancracio-prisma-gateway-access", cache_key, json.dumps({
            "token": token, "expires_at": time.time() + lifetime,
        }))
    except Exception as exc:
        raise GatewayError("Gateway credential cache is unavailable") from exc
    return token


def diagnose(runtime_root: Path) -> str:
    """Return a non-secret operational state from one safe MCP initialize probe."""
    try:
        token = _authorization_token(runtime_root)
    except GatewayError:
        return "AUTHENTICATION_REJECTED"
    if token is None:
        return "NOT_CONFIGURED"
    endpoint = gateway_endpoint(runtime_root)
    if endpoint is None:
        return "CONFIGURATION_REJECTED"
    try:
        response = requests.post(
            endpoint,
            headers={
                "Authorization": f"Bearer {token}",
                "Accept": "application/json, text/event-stream",
                "Content-Type": "application/json",
                "MCP-Protocol-Version": "2025-06-18",
            },
            json={"jsonrpc": "2.0", "id": 1, "method": "initialize",
                  "params": {"protocolVersion": "2025-06-18",
                             "capabilities": {}, "clientInfo": {"name": "panky", "version": __version__}}},
            timeout=8,
        )
        if response.status_code in {401, 403}:
            return "AUTHENTICATION_REJECTED"
        if response.status_code != 200:
            return "ENDPOINT_UNREACHABLE" if response.status_code >= 500 or response.status_code == 404 else "MCP_INITIALIZATION_FAILED"
        try:
            body = response.json()
        except (ValueError, AttributeError):
            try:
                body = json.loads(response.text)
            except (ValueError, AttributeError):
                return "MCP_INITIALIZATION_FAILED"
        if (not isinstance(body, dict) or not isinstance(body.get("result"), dict)
                or not isinstance(body["result"].get("serverInfo"), dict)):
            return "MCP_INITIALIZATION_FAILED"
        return "READY"
    except requests.RequestException as exc:
        # A sandbox can deny the CLI's socket while Codex-hosted MCP remains
        # available. Do not mislabel local policy as a remote outage.
        current: BaseException | None = exc
        seen: set[int] = set()
        while current is not None and id(current) not in seen:
            seen.add(id(current))
            if isinstance(current, OSError) and current.errno in {errno.EPERM, errno.EACCES}:
                return "LOCAL_PROBE_BLOCKED"
            next_error = current.__cause__ or current.__context__ or getattr(current, "reason", None)
            current = next_error if isinstance(next_error, BaseException) else None
        if "Operation not permitted" in str(exc):
            return "LOCAL_PROBE_BLOCKED"
        return "ENDPOINT_UNREACHABLE"


def probe(runtime_root: Path) -> str:
    """Retain Context Manifest v2's coarse state; diagnostics remain local."""
    detail = diagnose(runtime_root)
    if detail == "NOT_CONFIGURED":
        return detail
    return "CONFIGURED_REACHABLE" if detail == "READY" else "CONFIGURED_UNAVAILABLE"


def headers_main(argv: list[str]) -> int:
    # Used by Codex http_headers_helper. Never log the output or token.
    if len(argv) != 1:
        return 2
    try:
        token = _authorization_token(Path(argv[0]))
    except GatewayError:
        return 4
    if token is None:
        return 3
    json.dump({"Authorization": f"Bearer {token}"}, sys.stdout)
    return 0


if __name__ == "__main__":
    raise SystemExit(headers_main(sys.argv[1:]))
