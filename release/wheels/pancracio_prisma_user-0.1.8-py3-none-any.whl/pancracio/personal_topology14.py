"""Actor-owned Personal topology, independent from organizational scope."""

from __future__ import annotations

from pathlib import Path
import re
import subprocess
from uuid import uuid4

import yaml

from .git_closure import begin as begin_work, close as close_work
from .identity import VerifiedActor
from .registry import CoreRegistry


class PersonalTopologyBlocked(ValueError):
    pass


def _root(workspace: Path) -> Path:
    root = workspace / 'domains/actor'
    if root.is_symlink() or not (root / '.git').is_dir():
        raise PersonalTopologyBlocked('Actor-owned Personal backing unavailable')
    return root


def read_personal_topology(workspace: Path, actor: VerifiedActor) -> dict:
    path = _root(workspace) / 'personal-topology.yaml'
    if path.is_symlink() or not path.is_file():
        raise PersonalTopologyBlocked('Personal topology not initialized')
    data = yaml.safe_load(path.read_text(encoding='utf-8'))
    root_id = f'personal:{actor.actor_id}'
    if (not isinstance(data, dict) or data.get('schema_version') != 1
            or data.get('owner_actor_id') != actor.actor_id or not isinstance(data.get('nodes'), dict)
            or data['nodes'].get(root_id, {}).get('parent_id') is not None
            or data['nodes'].get(f'{root_id}:general', {}).get('parent_id') != root_id):
        raise PersonalTopologyBlocked('Personal hard ownership/topology boundary invalid')
    nodes = data['nodes']
    for node_id, row in nodes.items():
        if (not node_id.startswith(f'{root_id}:') and node_id != root_id) or not isinstance(row, dict):
            raise PersonalTopologyBlocked('foreign Personal node')
        if row.get('lifecycle') not in {'ACTIVE', 'ARCHIVED'}:
            raise PersonalTopologyBlocked('Personal lifecycle invalid')
        if node_id != root_id and row.get('parent_id') not in nodes:
            raise PersonalTopologyBlocked('Personal parent invalid')
        seen = set()
        cursor = node_id
        while cursor is not None:
            if cursor in seen:
                raise PersonalTopologyBlocked('Personal topology cycle')
            seen.add(cursor)
            cursor = nodes[cursor].get('parent_id')
    return data


def initialize_personal_topology(workspace: Path, actor: VerifiedActor, registry: CoreRegistry) -> str:
    """Map existing Actor Knowledge to logical General without moving bytes."""
    root = _root(workspace)
    target = root / 'personal-topology.yaml'
    if target.exists():
        read_personal_topology(workspace, actor)
        tracked = subprocess.run(['git', '-C', str(root), 'ls-files', '--error-unmatch',
                                  'personal-topology.yaml'], capture_output=True)
        if tracked.returncode:
            raise PersonalTopologyBlocked('partial Personal topology initialization needs controlled recovery')
        return 'EXISTING'
    root_id = f'personal:{actor.actor_id}'
    data = {'schema_version': 1, 'owner_actor_id': actor.actor_id,
            'nodes': {root_id: {'parent_id': None, 'display_name': 'Personal', 'lifecycle': 'ACTIVE',
                                'storage_path': '.'},
                      f'{root_id}:general': {'parent_id': root_id, 'display_name': 'General',
                                             'lifecycle': 'ACTIVE', 'storage_path': '.'}}}
    unit = begin_work(workspace, 'actor_knowledge')
    marker = root / 'repo.yaml'
    paths = ['personal-topology.yaml']
    if not marker.exists():
        marker.write_text('repo_type: actor_knowledge\n', encoding='utf-8')
        paths.insert(0, 'repo.yaml')
    elif marker.is_symlink() or yaml.safe_load(marker.read_text(encoding='utf-8')).get('repo_type') != 'actor_knowledge':
        raise PersonalTopologyBlocked('Actor-private repository marker invalid')
    target.write_text(yaml.safe_dump(data, sort_keys=False, allow_unicode=True), encoding='utf-8')
    return close_work(workspace, unit, actor, registry, paths,
                      f'Initialize Actor-owned Personal topology for {actor.actor_id}')


def create_personal_subdomain(workspace: Path, actor: VerifiedActor, registry: CoreRegistry,
                              name: str, *, distinct_durable_sources: int,
                              retrieval_reason: str, lifecycle_reason: str,
                              actor_confirmed: bool) -> tuple[str, str]:
    if (not actor_confirmed or distinct_durable_sources < 3
            or not retrieval_reason.strip() or not lifecycle_reason.strip()):
        raise PersonalTopologyBlocked('meaningful independent value and Actor confirmation required')
    if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9 _-]{2,59}', name):
        raise PersonalTopologyBlocked('Personal subdomain name invalid')
    data = read_personal_topology(workspace, actor)
    if any(row['display_name'].casefold() == name.casefold() for row in data['nodes'].values()):
        raise PersonalTopologyBlocked('Personal subdomain already exists')
    node_id = f'personal:{actor.actor_id}:{uuid4().hex}'
    data['nodes'][node_id] = {'parent_id': f'personal:{actor.actor_id}', 'display_name': name,
                              'lifecycle': 'ACTIVE', 'storage_path': f'Subdomains/{node_id.rsplit(":", 1)[1]}',
                              'creation_evidence': {'distinct_durable_sources': distinct_durable_sources,
                                                    'retrieval_reason': retrieval_reason.strip(),
                                                    'lifecycle_reason': lifecycle_reason.strip()}}
    unit = begin_work(workspace, 'actor_knowledge')
    target = _root(workspace) / 'personal-topology.yaml'
    target.write_text(yaml.safe_dump(data, sort_keys=False, allow_unicode=True), encoding='utf-8')
    commit = close_work(workspace, unit, actor, registry, ['personal-topology.yaml'],
                        f'Create Actor-owned Personal subdomain {name}')
    return node_id, commit
