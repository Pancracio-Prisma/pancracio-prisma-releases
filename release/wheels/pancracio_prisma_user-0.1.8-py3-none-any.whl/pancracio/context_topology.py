"""Protected Context Topology and node-scoped authority for Pancracio 1.4.

The caller supplies policy read from a trusted Core release/commit. This module
never treats local paths, repository credentials, events or manifests as grants.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping, Sequence

from .identity import VerifiedActor, actor_matches_registry
from .registry import CoreRegistry


class TopologyError(ValueError):
    """Invalid protected topology or policy; callers must fail closed."""


@dataclass(frozen=True)
class ContextNode:
    node_id: str
    parent_id: str | None
    owner_class: str  # organization | actor_private
    owner_id: str
    lifecycle: str = "ACTIVE"


@dataclass(frozen=True)
class Anchor:
    principal_id: str
    node_id: str
    capability_template: str


@dataclass(frozen=True)
class CrossGrant:
    principal_id: str
    target_node_id: str
    capabilities: frozenset[str]
    issuer: str
    provenance: str
    subtree: bool = False
    active: bool = True


@dataclass(frozen=True)
class AuthorityDecision:
    allowed: bool
    reason: str
    scope_source: str | None = None


@dataclass(frozen=True)
class TopologyImpact:
    gained: Mapping[str, frozenset[str]]
    lost: Mapping[str, frozenset[str]]
    parent_before: str | None
    parent_after: str | None


class ContextTopology:
    """A single-parent forest with derived family relations and exact scope."""

    def __init__(self, nodes: Sequence[ContextNode], anchors: Sequence[Anchor],
                 templates: Mapping[str, frozenset[str]],
                 cross_grants: Sequence[CrossGrant] = ()) -> None:
        self.nodes = {node.node_id: node for node in nodes}
        if len(self.nodes) != len(nodes) or not self.nodes:
            raise TopologyError("node IDs must be unique and nonempty")
        self.anchors = tuple(anchors)
        self.templates = dict(templates)
        self.cross_grants = tuple(cross_grants)
        self._validate()
        children: dict[str, set[str]] = {node_id: set() for node_id in self.nodes}
        for node in self.nodes.values():
            if node.parent_id is not None:
                children[node.parent_id].add(node.node_id)
        self._children = {node_id: frozenset(values) for node_id, values in children.items()}
        self._subtrees: dict[str, frozenset[str]] = {}
        self._scope_cache: dict[str, frozenset[str]] = {}

    def _validate(self) -> None:
        if not self.templates or any(not name or not isinstance(caps, frozenset) or not caps
                                     for name, caps in self.templates.items()):
            raise TopologyError("capability templates must be explicit")
        for node in self.nodes.values():
            if not node.node_id or not node.owner_id or node.owner_class not in {"organization", "actor_private"}:
                raise TopologyError("invalid node identity or owner")
            if node.lifecycle not in {"ACTIVE", "TRANSITIONING", "ARCHIVED"}:
                raise TopologyError("invalid node lifecycle")
            if node.parent_id is not None:
                parent = self.nodes.get(node.parent_id)
                if parent is None or parent.node_id == node.node_id:
                    raise TopologyError("missing parent or self-parent")
                if node.owner_class != parent.owner_class or node.owner_id != parent.owner_id:
                    raise TopologyError("parent/child ownership boundary mismatch")
        for node in self.nodes.values():
            seen: set[str] = set()
            cursor: ContextNode | None = node
            while cursor is not None:
                if cursor.node_id in seen:
                    raise TopologyError("topology cycle")
                seen.add(cursor.node_id)
                cursor = self.nodes.get(cursor.parent_id) if cursor.parent_id else None
        for anchor in self.anchors:
            node = self.nodes.get(anchor.node_id)
            if not anchor.principal_id or node is None or node.owner_class != "organization":
                raise TopologyError("organizational anchor must bind to organizational node")
            if anchor.capability_template not in self.templates:
                raise TopologyError("unknown capability template")
        for grant in self.cross_grants:
            node = self.nodes.get(grant.target_node_id)
            if (not grant.principal_id or node is None or node.owner_class != "organization"
                    or not grant.capabilities or not grant.issuer or not grant.provenance):
                raise TopologyError("invalid positive organizational cross-grant")

    def roots(self) -> frozenset[str]:
        return frozenset(node.node_id for node in self.nodes.values() if node.parent_id is None)

    def parent(self, node_id: str) -> str | None:
        return self._node(node_id).parent_id

    def children(self, node_id: str) -> frozenset[str]:
        self._node(node_id)
        return self._children[node_id]

    def ancestors(self, node_id: str) -> tuple[str, ...]:
        current = self._node(node_id)
        result: list[str] = []
        while current.parent_id is not None:
            result.append(current.parent_id)
            current = self.nodes[current.parent_id]
        return tuple(result)

    def descendants(self, node_id: str) -> frozenset[str]:
        self._node(node_id)
        found: set[str] = set()
        pending = list(self.children(node_id))
        while pending:
            child = pending.pop()
            found.add(child)
            pending.extend(self.children(child))
        return frozenset(found)

    def siblings(self, node_id: str) -> frozenset[str]:
        parent_id = self.parent(node_id)
        return self.children(parent_id) - {node_id} if parent_id else frozenset()

    def subtree(self, node_id: str) -> frozenset[str]:
        self._node(node_id)
        if node_id not in self._subtrees:
            self._subtrees[node_id] = self.descendants(node_id) | {node_id}
        return self._subtrees[node_id]

    def actor_principals(self, actor: VerifiedActor, registry: CoreRegistry) -> frozenset[str]:
        if not isinstance(actor, VerifiedActor):
            raise TopologyError("verified Actor required")
        record = registry.actors.get(actor.actor_id)
        if not actor_matches_registry(actor, record):
            raise TopologyError("Actor/Registry mismatch")
        principals = {actor.actor_id}
        for seat_id, seat in registry.seats.items():
            if seat["status"] == "active" and actor.actor_id in seat["occupied_by"]:
                principals.add(f"seat:{seat_id}")
        return frozenset(principals)

    def natural_scope_actor(self, actor: VerifiedActor, registry: CoreRegistry) -> frozenset[str]:
        return frozenset().union(*(self.natural_scope(p) for p in self.actor_principals(actor, registry)))

    def decide_actor(self, actor: VerifiedActor, registry: CoreRegistry, node_id: str, capability: str) -> AuthorityDecision:
        try:
            principals = self.actor_principals(actor, registry)
        except TopologyError as exc:
            return AuthorityDecision(False, str(exc))
        node = self.nodes.get(node_id)
        if node is not None and node.owner_class == "actor_private":
            return self.decide_personal(actor, registry, node_id, capability)
        decisions = [self.decide(p, node_id, capability) for p in principals]
        for decision in decisions:
            if decision.allowed:
                return decision
        return AuthorityDecision(False, "; ".join(sorted({d.reason for d in decisions})))

    def natural_scope(self, principal_id: str) -> frozenset[str]:
        if principal_id in self._scope_cache:
            return self._scope_cache[principal_id]
        scope: set[str] = set()
        for anchor in self.anchors:
            if anchor.principal_id == principal_id:
                scope.update(self.subtree(anchor.node_id))
        result = frozenset(scope)
        self._scope_cache[principal_id] = result
        return result

    def discoverable(self, principal_id: str) -> frozenset[str]:
        scope = set(self.natural_scope(principal_id))
        for grant in self.cross_grants:
            if grant.active and grant.principal_id == principal_id:
                scope.update(self.subtree(grant.target_node_id) if grant.subtree else {grant.target_node_id})
        return frozenset(scope)

    def decide(self, principal_id: str, node_id: str, capability: str) -> AuthorityDecision:
        node = self.nodes.get(node_id)
        if node is None or not principal_id or not capability:
            return AuthorityDecision(False, "unknown principal, node or capability")
        if node.lifecycle != "ACTIVE":
            return AuthorityDecision(False, "node lifecycle is not active")
        if node.owner_class == "actor_private":
            return AuthorityDecision(False, "Personal requires verified Actor owner")
        if node_id in self.natural_scope(principal_id):
            caps = set().union(*(self.templates[anchor.capability_template]
                                 for anchor in self.anchors
                                 if anchor.principal_id == principal_id and node_id in self.subtree(anchor.node_id)))
            if capability == "discover":
                return AuthorityDecision(True, "natural subtree discovery", "anchor")
            if capability in caps:
                return AuthorityDecision(True, "anchor and capability", "anchor")
            return AuthorityDecision(False, "capability absent within natural scope")
        for grant in self.cross_grants:
            if not grant.active or grant.principal_id != principal_id:
                continue
            targets = self.subtree(grant.target_node_id) if grant.subtree else {grant.target_node_id}
            if node_id in targets:
                if capability == "discover" or capability in grant.capabilities:
                    return AuthorityDecision(True, "positive cross-grant", "cross_grant")
                return AuthorityDecision(False, "cross-grant capability absent")
        return AuthorityDecision(False, "outside organizational scope")

    def decide_personal(self, actor: VerifiedActor, registry: CoreRegistry,
                        node_id: str, capability: str) -> AuthorityDecision:
        node = self.nodes.get(node_id)
        if node is None or node.owner_class != "actor_private" or node.lifecycle != "ACTIVE":
            return AuthorityDecision(False, "active Personal node required")
        if not isinstance(actor, VerifiedActor) or actor.actor_id != node.owner_id:
            return AuthorityDecision(False, "Personal hard boundary")
        record = registry.actors.get(actor.actor_id)
        if not actor_matches_registry(actor, record):
            return AuthorityDecision(False, "verified Actor/Registry mismatch")
        if capability in {"discover", "read", "materialize", "write_knowledge", "write_state", "create_child", "archive"}:
            return AuthorityDecision(True, "Personal owner", "personal_owner")
        return AuthorityDecision(False, "unsupported Personal capability")

    def with_node(self, node: ContextNode) -> "ContextTopology":
        if node.node_id in self.nodes:
            raise TopologyError("node identity already exists")
        return ContextTopology([*self.nodes.values(), node], self.anchors, self.templates, self.cross_grants)

    def with_move(self, node_id: str, new_parent_id: str) -> "ContextTopology":
        old = self._node(node_id)
        parent = self._node(new_parent_id)
        if old.parent_id is None:
            raise TopologyError("root move requires separate governed root operation")
        if parent.owner_class != old.owner_class or parent.owner_id != old.owner_id:
            raise TopologyError("move crosses ownership boundary")
        updated = ContextNode(old.node_id, new_parent_id, old.owner_class, old.owner_id, old.lifecycle)
        return ContextTopology([updated if n.node_id == node_id else n for n in self.nodes.values()],
                               self.anchors, self.templates, self.cross_grants)

    def impact_of(self, proposed: "ContextTopology", node_id: str) -> TopologyImpact:
        if node_id not in proposed.nodes:
            raise TopologyError("proposed topology lacks target node")
        principals = {a.principal_id for a in (*self.anchors, *proposed.anchors)}
        gained: dict[str, frozenset[str]] = {}
        lost: dict[str, frozenset[str]] = {}
        for principal in principals:
            before = self.natural_scope(principal)
            after = proposed.natural_scope(principal)
            if after - before:
                gained[principal] = after - before
            if before - after:
                lost[principal] = before - after
        return TopologyImpact(gained, lost, self.nodes[node_id].parent_id if node_id in self.nodes else None,
                              proposed.nodes[node_id].parent_id)

    def _node(self, node_id: str) -> ContextNode:
        try:
            return self.nodes[node_id]
        except KeyError as exc:
            raise TopologyError("unknown node") from exc


def topology_from_core(registry: CoreRegistry) -> ContextTopology:
    """Construct graph only from a validated, protected Core policy snapshot."""
    policy = registry.topology_policy
    if not isinstance(policy, dict) or policy.get("schema_version") != 1:
        raise TopologyError("unsupported or unavailable protected topology")
    nodes = [ContextNode(node_id, row["parent_id"], row["owner_class"], row["owner_id"], row["lifecycle"])
             for node_id, row in policy["nodes"].items()]
    anchors = [Anchor(row["principal_id"], row["node_id"], row["capability_template"])
               for row in policy["anchors"]]
    templates = {name: frozenset(values) for name, values in policy["capability_templates"].items()}
    grants = [CrossGrant(row["principal_id"], row["target_node_id"], frozenset(row["capabilities"]),
                         row["issuer"], row["provenance"], row["scope"] == "subtree", row.get("active", True))
              for row in policy["cross_grants"]]
    graph = ContextTopology(nodes, anchors, templates, grants)
    for anchor in graph.anchors:
        if anchor.principal_id.startswith("seat:"):
            if anchor.principal_id[5:] not in registry.seats:
                raise TopologyError("anchor references unknown Seat")
        elif anchor.principal_id not in registry.actors:
            raise TopologyError("anchor references unknown Actor")
    for node_id, row in policy["nodes"].items():
        if "seat_id" in row and row["seat_id"] not in registry.seats:
            raise TopologyError("node references unknown Seat")
    return graph
