"""Physical materialization of already-authorized Pancracio 1.4 bindings."""

from __future__ import annotations

import os
from pathlib import Path
import subprocess
from typing import Any

import yaml

from .context_manifest14 import validate_graph_manifest, verify_graph_manifest
from .identity import VerifiedActor
from .node_authority import NodeAuthority
from .registry import CoreRegistry
from .processes import background_creationflags
from prisma_common.core_policy import CorePolicyError, approved_remote


class MaterializationError(ValueError):
    pass


def _git(root: Path, *args: str) -> str:
    result = subprocess.run(["git", "-C", str(root), *args], capture_output=True,
                            text=True, timeout=45, creationflags=background_creationflags())
    if result.returncode:
        raise MaterializationError("authorized Git backing validation failed")
    return result.stdout.strip()


def _local(workspace: Path, path: str) -> Path:
    workspace = workspace.resolve(strict=True)
    target = workspace / path
    if not target.resolve().is_relative_to(workspace) or target == workspace:
        raise MaterializationError("backing path escapes Workspace")
    current = workspace
    for part in Path(path).parts:
        current = current / part
        if current.is_symlink():
            raise MaterializationError("backing path uses symlink")
    return target


def _remote(repository: str, organization: str, reference_remote: str | None = None) -> str:
    try:
        return approved_remote(repository, organization, reference_remote)
    except CorePolicyError as exc:
        raise MaterializationError("invalid protected backing repository") from exc


def _preflight_remote(remote: str, repository: str) -> None:
    environment = os.environ.copy()
    environment["GIT_TERMINAL_PROMPT"] = "0"
    environment["GIT_SSH_COMMAND"] = "ssh -o BatchMode=yes -o ConnectTimeout=10 -o ConnectionAttempts=1"
    try:
        result = subprocess.run(["git", "ls-remote", remote, "refs/heads/main"],
                                capture_output=True, text=True, timeout=30, env=environment,
                                creationflags=background_creationflags())
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise MaterializationError(
            f"Git transport cannot test required authorized backing: {repository}") from exc
    if result.returncode or not result.stdout.strip():
        raise MaterializationError(
            f"Git transport cannot read required authorized backing: {repository}; "
            "GitHub is transport only and does not determine Pancracio identity or scope")


def _verify_binding(root: Path, binding: Any, organization: str | None = None) -> None:
    if root.is_symlink() or not (root / ".git").is_dir():
        raise MaterializationError("independent Git backing required")
    if Path(_git(root, "rev-parse", "--show-toplevel")).resolve() != root.resolve():
        raise MaterializationError("backing Git root mismatch")
    actual = _git(root, "remote", "get-url", "origin")
    ssh = _remote(binding.repository, organization or binding.repository.split("/", 1)[0])
    if actual not in {ssh, ssh.replace("git@github.com:", "https://github.com/")}:
        raise MaterializationError("backing remote mismatch")
    if binding.store_id == "organization_canonical":
        marker = yaml.safe_load((root / "repo.yaml").read_text(encoding="utf-8"))
        if marker.get("repo_type") != "organization_canonical":
            raise MaterializationError("canonical marker mismatch")
    elif binding.mode == "generated":
        marker = yaml.safe_load((root / "publication.yaml").read_text(encoding="utf-8"))
        if (marker.get("target_node_id") != binding.node_id
                or marker.get("generation") != binding.generation):
            raise MaterializationError("publication marker/generation mismatch")
    else:
        marker = yaml.safe_load((root / "node.yaml").read_text(encoding="utf-8"))
        if (marker.get("node_id") != binding.node_id
                or marker.get("generation") != binding.generation
                or marker.get("owner_class") != "organization"):
            raise MaterializationError("node marker/generation mismatch")


def materialize_authorized(workspace: Path, manifest: dict[str, Any], actor: VerifiedActor,
                           registry: CoreRegistry, *, expected_core_commit: str,
                           clone: bool = True,
                           catalog: dict[str, Any] | None = None) -> dict[str, Path]:
    """Clone only bindings authorized by the active catalog or legacy Core."""
    validate_graph_manifest(manifest)
    if catalog is None:
        verify_graph_manifest(manifest, actor, registry, expected_core_commit=expected_core_commit)
    else:
        from .context_catalog20 import verify_catalog_manifest
        verify_catalog_manifest(manifest, catalog, actor, registry,
                                expected_core_commit=expected_core_commit)
    authority = NodeAuthority(registry)
    organization = registry.repository_policy["organization"]
    selected = manifest["materialized_bindings"]
    # An unauthorized old mount is a physical privacy failure, even if the new
    # manifest would merely ignore it. Reconciliation must remove it first.
    for store_id, binding in authority.bindings.items():
        if store_id not in selected and _local(workspace, binding.local_path).exists():
            raise MaterializationError("unauthorized backing bytes remain in Workspace")
    plan: list[tuple[str, Any, Path]] = []
    for store_id, row in selected.items():
        binding = authority.bindings.get(store_id)
        if (binding is None or row["node_id"] != binding.node_id or row["path"] != binding.local_path
                or row["repository"] != binding.repository or row["generation"] != binding.generation):
            raise MaterializationError("manifest/backing policy mismatch")
        plan.append((store_id, binding, _local(workspace, binding.local_path)))
    # Prove access to every and only the Core-authorized missing backing before
    # cloning any of them. A broad Git credential never expands this plan.
    if clone:
        workspace_origin = _git(workspace, "remote", "get-url", "origin")
        for _, binding, root in plan:
            if not root.exists():
                _preflight_remote(_remote(binding.repository, organization, workspace_origin), binding.repository)
    mounted: dict[str, Path] = {}
    for store_id, binding, root in plan:
        if not root.exists():
            if not clone:
                raise MaterializationError("authorized backing is not materialized")
            root.parent.mkdir(parents=True, exist_ok=True)
            workspace_origin = _git(workspace, "remote", "get-url", "origin")
            result = subprocess.run(["git", "-c", "core.autocrlf=false", "clone", "--",
                                     _remote(binding.repository, organization, workspace_origin), str(root)],
                                    capture_output=True, text=True, timeout=90,
                                    creationflags=background_creationflags())
            if result.returncode:
                raise MaterializationError("authorized backing clone failed")
        _verify_binding(root, binding, organization)
        mounted[store_id] = root
    return mounted
