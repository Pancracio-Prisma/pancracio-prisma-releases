# Panky 2.2: altas y cambios agénticos de organización

Este contrato lo sigue Codex durante la instalación técnica y, después, Panky
cuando ya tiene una identidad OIDC verificada y autoridad en el Core protegido.
La persona explica el resultado que busca; el agente identifica las entidades,
pregunta solo por decisiones faltantes, prepara el cambio, lo publica por la ruta
gobernada y comprueba el resultado. No le pide editar JSON, SQL ni elegir un Seat
para cada acción. Los ejemplos de la arquitectura son ficticios y no se cargan
como datos de un cliente.

## Secuencia común para cualquier alta

1. **Identificar al solicitante y la instancia.** Verificar OIDC, Actor, Seats
   activos y versión vigente de Core. Una sesión de GitHub, una ruta local o un
   token heredado de Gateway no sustituyen esa identidad. Elegir automáticamente una
   ruta de Seat completa que autorice la operación; no sumar el rol de un Seat
   al alcance de otro. Si no hay ruta, explicar la capacidad faltante.
2. **Descubrir lo existente.** Leer la topología y política protegidas de Core,
   el catálogo de herramientas, los recursos y la versión activa del backend.
   Buscar duplicados por ID estable y referencia externa antes de proponer una
   creación. No inferir permisos a partir del nombre de un puesto.
3. **Pedir el mínimo dato faltante.** Preguntar en lenguaje de negocio por
   propietario, ubicación en el árbol, responsable, alcance, operaciones,
   vigencia o cuenta de acceso solo cuando sea necesario. Si hay que iniciar
   sesión, el humano completa contraseña, MFA o consentimiento en la página;
   no pedir secretos en el chat.
4. **Preparar un cambio revisable.** Mostrar qué nodos, Seats, herramientas,
   recursos y permisos se agregarán o cambiarán, quién los heredará por
   jerarquía y qué personas quedarán excluidas. Para un recurso compartido,
   mostrar cada departamento receptor. Para operaciones destructivas,
   exigir concesión explícita, motivo y aprobador.
5. **Aplicar por la ruta gobernada.** Para compartir entre departamentos,
   otorgar o retirar un permiso de recurso, nombrar o retirar un super admin,
   o transferir Founder, registrar la solicitud por Gateway. La solicitud no
   concede acceso. El Core de la empresa recoge solo aprobaciones vigentes,
   publica el cambio y el backend activa la versión completa en PostgreSQL.
   Para otras altas, seguir el flujo protegido de Core. Nunca editar tablas
   operativas ni usar un MD descriptivo como permiso. Si falla la activación,
   no afirmar que el cambio ya rige.
6. **Verificar y entregar recibo.** Leer de vuelta Core, versión activa y
   proyección de tablas; ejecutar decisiones positivas y negativas sintéticas
   sobre el alcance afectado; confirmar que la versión anterior no decide.
   Registrar Actor, Seat usado, commit, release, entidades afectadas y resultado.
   Una alta queda terminada solo con recibos comprobados.

## Recorridos según lo que se da de alta

Antes de ofrecer una acción administrativa, consulta `panky-prisma governance
actions`. El catálogo devuelve solamente las acciones disponibles para el Actor
y sus Seats actuales. No sugieras acciones de admin o super admin que no estén
en esa respuesta. Las operaciones básicas sobre recursos se siguen evaluando
por Seat, rol y alcance; no forman parte de este catálogo delegable.

Para registrar una herramienta nueva, el conector debe estar configurado y
comprobado en el Gateway. Un dev con grant explícito `tool.register` puede
pedir el alta sin ser admin ni super admin. Panky envía el proveedor y su Seat;
el Gateway deriva las operaciones del conector vivo y la solicitud solo queda
efectiva cuando Core publica la nueva política. No aceptes operaciones
inventadas por el solicitante ni pidas credenciales en la conversación.

### Descubrir un recurso sin pedir datos técnicos

Si la persona dice «agrega esta carpeta», «comparte el tablero que tengo abierto»
o da un nombre, Panky identifica la herramienta mencionada y busca primero en
el Gateway de **esa empresa**. Consulta las fuentes o instancias que el Actor
puede leer y usa la herramienta de descubrimiento configurada para buscar el
nombre dentro de cada alcance autorizado. El Gateway obtiene la referencia
estable; Panky no pide IDs, nombres de tabla, rutas de repositorio ni JSON.

Si la persona está viendo el recurso en el navegador, Panky puede usar la
página abierta para obtener nombre, ubicación o enlace **solo como pista**.
Después vuelve al Gateway para descubrirlo y verificar que pertenezca a una
fuente autorizada. La URL visible, una captura o una sesión del navegador no
conceden acceso ni reemplazan la decisión del Gateway. Si hay varios resultados,
Panky muestra nombres y ubicaciones comprensibles y pregunta cuál es; si hay
uno verificable, continúa sin preguntar. No expone contenido ni datos de otra
fuente durante la búsqueda.

Antes de crear o registrar el recurso, comprueba que la herramienta y su
conector estén configurados, que no exista ya en Core, el Seat dueño y el
departamento responsable. Muestra quién podrá verlo por la regla vigente y
pregunta por destinatarios adicionales solo si la persona pide compartirlo.
Si el conector no soporta descubrimiento o el Gateway no puede verificar el
recurso, detiene el alta y explica qué conexión falta en lenguaje sencillo;
no convierte un ID proporcionado en permiso ni usa browsing para saltar el
Gateway. Para crear algo nuevo en la herramienta, usa una operación de creación
autorizada y después descubre y registra el resultado verificado.

| Solicitud natural | Datos que el agente necesita | Cambios esperados | Comprobación decisiva |
| --- | --- | --- | --- |
| Empresa / instalación técnica | Nombre, dominio, propietario GitHub/GCP/Workspace, perfil de navegador, región, primer superadministrador y servicios elegidos | Core y Workspace protegidos, identidad OIDC, recursos de nube, versión inicial de política y bundle de usuario propios de la instancia | Instalación aislada, primer Actor autenticado y una decisión permitida y una denegada |
| Departamento | Nombre, padre, responsable y contexto propio | Nodo de Core y `panky_context_nodes`; fila en `panky_departments`; un repositorio canónico para ese nodo | Padre ve la superficie compartida del hijo por la ruta gobernada; un hermano no hereda su recurso |
| Subcontexto | Departamento o Seat dueño, propósito, superficie, visibilidad `INHERIT` o `RESTRICTED`, lectores/escritores específicos | Nodo y backing gobernado en Core, proyección en `panky_context_nodes`; excepciones en `panky_grants` si es restringido | Solo las rutas autorizadas leen o mutan; el subnodo no expone el backing canónico por su sola ubicación |
| Rol | Nombre y operaciones por tipo de herramienta, sin mencionar recursos concretos ni departamentos | `panky_roles` y `panky_role_operations` desde Core | El rol concede la operación solo si el Seat alcanza un recurso de esa herramienta |
| Seat | Departamento, rol de negocio, tipo `basic` o `admin`, responsable jerárquico, ocupación y contexto propio | `panky_seats`, su nodo de contexto, repositorio y ancla de Core | El Seat une departamento, rol, tipo y contexto; no hereda facultades de otro Seat |
| Actor / ocupante | Correo corporativo y prueba OIDC, Seats a ocupar, estado y superadministración solo si fue autorizada | `panky_actors` y una fila vigente por Seat en `panky_actor_seats` | La persona entra con OIDC, solo ve sus rutas y Panky elige el Seat adecuado sin preguntarle |
| Tool | Proveedor, nombre estable, operaciones soportadas y forma de autenticación | `panky_tools`; configuración de conector fuera de la política | Ningún Seat gana acceso hasta que haya recurso y alcance departamental, además de operación del rol |
| Resource | Nombre o página del recurso; Panky descubre por Gateway la Tool y referencia externa verificable, y determina departamento responsable y Seat dueño | `panky_resources` con `owner_seat_id` y `panky_department_resources` (`OWNED`/`SHARED`) | El Seat dueño, admins de su departamento y ancestros, y super admins lo ven según rol; otros Seats necesitan un ALLOW específico |
| Compartir o retirar acceso de un Seat | Recurso, Seat receptor y operación | Solicitud gobernada y grant en el próximo release de Core | El ALLOW aparece o desaparece en el release activo; el historial previo permanece y no se crea un DENY al retirar |
| Compartir entre departamentos | Recurso, departamento receptor y aceptación de su admin | Solicitud y aceptación en el backend; `SHARED` solo después de publicar Core | El departamento receptor no ve el recurso antes de la publicación; cada Seat aún requiere visibilidad y rol |
| Transferir Founder | Founder actual, nuevo super admin y su aceptación | Solicitud, aceptación y nuevo release atómico | Hay exactamente un Founder; retirar super admin requiere autoridad del Founder |
| Excepción | Actor, Seat, rol o departamento; recurso o nodo; operación; permitir/denegar; motivo; aprobador; vigencia y usos | `panky_grants`, y `panky_grant_uses` cuando se ejerza un límite | DENY prevalece según alcance; vencimiento y uso único se aplican en la siguiente llamada |
| Baja o traslado | Actor/Seat/recurso afectado, fecha efectiva y destino de trabajo pendiente | Desactivar ocupación o entidad en Core y publicar nueva versión; conservar auditoría | El permiso revocado falla desde la siguiente decisión; no quedan Seats activos por accidente |

## Semántica que debe conservarse

- Una instalación pertenece a una empresa; las tablas de política no llevan
  `company_id`. `OWNED` marca el departamento responsable, no abre el recurso
  automáticamente a todos sus miembros. Un admin del departamento o de un
  ancestro puede verlo según su rol. Compartir entre ramas requiere aceptación
  del admin receptor y publicación del Core.
- Cada Seat tiene **un departamento, un tipo y un rol**. Un Actor puede tener varios
  Seats. La autorización externa normal es la intersección del recurso
  visible desde ese Seat con la operación de la Tool permitida al rol del
  mismo Seat. El tipo admin gobierna administración y herencia de visibilidad;
  el rol gobierna operaciones. Se usa una sola ruta completa y se audita.
  Si el Actor es super admin activo, esa autoridad se comprueba primero.
  `seat_type=null` nunca concede privilegios a un no super admin.
- El contexto departamental compartido es legible para Seats del departamento
  y sus ancestros autorizados. El rol manager puede crear, actualizar, publicar,
  enriquecer y asignar encargos en el subárbol departamental mediante escrituras
  gobernadas. El ocupante puede mutar el contexto de su Seat. El conocimiento
  privado de otro Actor y los backings canónicos protegidos no se abren por
  herencia. Borrar, revocar o transferir requiere permiso explícito.
- Una excepción puede aplicarse tanto a una operación de Tool sobre Resource
  como a una superficie/operación sobre un nodo de contexto. No crea nodos ni
  recursos; para una frontera durable nueva se crea primero el nodo gobernado.
- `panky_actors`, `panky_departments`, `panky_roles`, `panky_seats`,
  `panky_actor_seats`, `panky_context_nodes`, `panky_context_rules`,
  `panky_tools`, `panky_resources`, `panky_department_resources`,
  `panky_role_operations`, `panky_policy_releases`, las cuatro tablas de
  solicitudes de gobernanza, `panky_grants`,
  `panky_grant_uses` y `panky_audit_events` son la proyección operativa objetivo.
  Core conserva la autoridad; la base no se edita a mano.
- Cada nodo organizacional tiene **un repositorio canónico**. El catálogo
  vigente del Gateway entrega nodo, repo, superficie y versión a cada Actor;
  GitHub solo transporta los archivos autorizados. No se crean repos paralelos
  de publicación para duplicar el contexto. El contexto Personal vive fuera
  de ese catálogo y puede o no tener remoto propio.
- El vault de Obsidian materializa esos repos. Después de un pull, el agente
  revisa notas, enlaces y backlinks dentro del alcance actual. `Panky Context
  Map.md` conecta cada nota Markdown; Doctor falla ante notas huérfanas en
  contexto organizacional o Personal. Una reparación conserva el contenido
  Personal, incluso si aún no se publicó.
- Context Signals se suscribe por repositorio autorizado. Una señal de cambio
  de política obliga a consultar de nuevo el catálogo, montar nuevos nodos,
  retirar del vault los organizacionales revocados y reconstruir el mapa.
  Las notas personales nunca se retiran por un cambio de Seat.
- En cada turno sustantivo el agente identifica hechos duraderos claros y
  ejecuta el cierre de memoria gobernado, aunque no haya nada que guardar.
  Una conversación completada no prueba que la nota fue persistida: comprueba
  el recibo de escritura y el readback remoto correspondiente.

## Ejemplos de conversación

**Actor con dos Seats.** “Da de alta a Alex como developer en Operaciones y contributor
en Finance”. El agente pregunta el correo OIDC y quién aprueba ambos puestos
si faltan, crea o reutiliza los dos Seats, registra dos ocupaciones, publica y
comprueba que `finance_drive` solo admite el CRUD contributor. No le pregunta a
Alex cuál Seat usar al pedir una acción.

**Recurso compartido.** “Conecta el Drive de HQ y compártelo con Finance”. El
agente verifica el ID real, registra el Seat dueño y HQ como `OWNED`.
El admin de Finance acepta la solicitud; Core publica `SHARED`. Para que
una persona específica lo use, el agente comprueba además su rol y el
grant por Seat. Otra rama continúa denegada.

**Retirar acceso.** “Ya no quiero compartir este recurso con ese Seat”.
Panky consulta primero los destinatarios activos, identifica el Seat exacto,
solicita la revocación y comprueba la siguiente versión de Core. El grant
anterior queda en el historial, sin un DENY nuevo.

**Encargo en hijo.** “Pat, desde Dirección, asigna un encargo al contexto de
HQ”. El agente comprueba la relación Management→HQ y el rol manager del Seat,
usa `panky node assign` o su equivalente gobernado y confirma el recibo. No
trata esta mutación ordinaria como permiso destructivo.
