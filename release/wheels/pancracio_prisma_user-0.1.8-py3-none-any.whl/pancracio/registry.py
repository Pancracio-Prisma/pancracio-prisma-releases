"""Read and validate the protected Core Registry."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import json
import os
import re
import subprocess
from typing import Any

import yaml
from jsonschema import Draft202012Validator, FormatChecker

from .processes import background_creationflags


class RegistryError(ValueError):
    pass


class CoreRemoteUnavailable(RegistryError):
    """The authorized Core remote cannot be checked right now."""


FILES = {
    "actors": "actor",
    "roles": "role",
    "seats": "seat",
}


@dataclass(frozen=True)
class CoreRegistry:
    root: Path
    actors: dict[str, Any]
    roles: dict[str, Any]
    seats: dict[str, Any]
    repository_policy: dict[str, Any]
    topology_policy: dict[str, Any] | None = None
    publication_edges: dict[str, Any] | None = None
    approved_organization: str | None = None

    @classmethod
    def load(cls, root: Path, *, require_trusted_git: bool = True) -> "CoreRegistry":
        root = root.resolve()
        approved_organization = None
        if require_trusted_git:
            approved_organization = _check_trusted_git(root)
        def read(relative: str) -> str:
            if require_trusted_git:
                return _git(root, "show", f"refs/remotes/origin/main:{relative}")
            return (root / relative).read_text(encoding="utf-8")
        return cls._from_reader(root, read, approved_organization=approved_organization)

    @classmethod
    def load_at_trusted_commit(cls, root: Path, commit: str) -> "CoreRegistry":
        """Read old policy only from an ancestor of verified Core origin/main."""
        root = root.resolve(strict=True)
        if not isinstance(commit, str) or re.fullmatch(r"[0-9a-f]{40}", commit) is None:
            raise RegistryError("invalid historical Core commit")
        approved_organization = _check_trusted_git(root)
        _git(root, "merge-base", "--is-ancestor", commit, "refs/remotes/origin/main")
        return cls._from_reader(root, lambda relative: _git(root, "show", f"{commit}:{relative}"),
                                approved_organization=approved_organization)

    @classmethod
    def load_packaged(cls) -> "CoreRegistry":
        """Tenant Core is never bundled into a neutral Prisma release."""
        raise RegistryError("Prisma requires a verified customer Core enrollment")

    @classmethod
    def _from_reader(cls, root: Path, read: Any, *,
                     approved_organization: str | None = None) -> "CoreRegistry":
        values: dict[str, dict[str, Any]] = {}
        for field, schema_name in FILES.items():
            key = field
            path = root / "registry" / f"{field.replace('_', '-')}.yaml"
            # Historical convention uses actors.yaml, roles.yaml and seats.yaml.
            if field in {"actors", "roles", "seats"}:
                path = root / "registry" / f"{field}.yaml"
            values[field] = _read_validated(read(path.relative_to(root).as_posix()), read(f"schemas/{schema_name}.schema.json"), key)
        policy = _read_validated(read("policy/repositories.yaml"), read("schemas/repository-policy.schema.json"), None)
        topology = _read_validated(read("registry/context-topology.yaml"),
                                   read("schemas/context-topology.schema.json"), None)
        edges = _read_validated(read("registry/publication-edges.yaml"),
                                read("schemas/publication-edges.schema.json"), None)
        instance = cls(root=root, repository_policy=policy, topology_policy=topology,
                       publication_edges=edges, approved_organization=approved_organization,
                       **values)
        instance.validate_relations()
        return instance

    def validate_relations(self) -> None:
        if self.topology_policy is not None:
            from prisma_common.core_policy import CorePolicyError, validate_core_owner
            try:
                validate_core_owner(self.repository_policy, self.topology_policy)
            except CorePolicyError as exc:
                raise RegistryError("Core backing organization mismatch") from exc
            if (self.approved_organization is not None and
                    self.repository_policy["organization"].casefold() != self.approved_organization.casefold()):
                raise RegistryError("Core policy organization differs from signed binding")
        emails: set[str] = set()
        for actor_id, actor in self.actors.items():
            if not actor_id.startswith("act_"):
                raise RegistryError(f"invalid actor id: {actor_id}")
            email = actor["identities"]["google_oidc"]["email"].casefold()
            if email in emails:
                raise RegistryError("duplicate Google identity")
            emails.add(email)
            for role in actor["roles"]:
                if role not in self.roles:
                    raise RegistryError(f"unknown role: {role}")
        for seat_id, seat in self.seats.items():
            if seat["occupancy"] == "single" and len(seat["occupied_by"]) > 1:
                raise RegistryError(f"multiple occupants of single Seat: {seat_id}")
            for actor_id in seat["occupied_by"]:
                if actor_id not in self.actors:
                    raise RegistryError(f"unknown Seat occupant: {actor_id}")
        if self.topology_policy is not None:
            from .context_topology import topology_from_core
            graph = topology_from_core(self)
            if self.publication_edges is None or self.publication_edges.get("schema_version") != 1:
                raise RegistryError("protected publication edges unavailable")
            for child_id, edge in self.publication_edges["edges"].items():
                if graph.parent(child_id) != edge["parent_id"]:
                    raise RegistryError("publication edge does not match protected topology")
                parent = self.topology_policy["nodes"][edge["parent_id"]]
                child = self.topology_policy["nodes"][child_id]
                source = {b["store_id"]: b for b in parent["backing_bindings"]}
                target = {b["store_id"]: b for b in child["backing_bindings"]}
                if policy := edge.get("publication"):
                    if (policy["source_store_id"] not in source or policy["target_store_id"] not in target
                            or source[policy["source_store_id"]]["mode"] != "authoritative"
                            or target[policy["target_store_id"]]["mode"] != "generated"):
                        raise RegistryError("publication edge backing mismatch")
                if "reconciliation" in edge and not any(
                        binding["mode"] == "authoritative" for binding in target.values()):
                    raise RegistryError("reconciliation needs authoritative child backing")
        if self.repository_policy["organization_default_permission"] != "none":
            raise RegistryError("organization default permission must be none")


def _read_validated(contents: str, schema_contents: str, key: str | None) -> dict[str, Any]:
    try:
        data = yaml.safe_load(contents)
        schema = json.loads(schema_contents)
    except (yaml.YAMLError, json.JSONDecodeError) as exc:
        raise RegistryError("invalid Core file") from exc
    if not isinstance(data, dict):
        raise RegistryError("invalid Core mapping")
    if key is not None:
        if set(data) != {key} or not isinstance(data[key], dict):
            raise RegistryError("invalid Registry root")
        items = data[key]
        item_schema = schema
        for item_id, item in items.items():
            errors = list(Draft202012Validator(item_schema, format_checker=FormatChecker()).iter_errors(item))
            if errors:
                raise RegistryError(f"invalid {key} item {item_id}: {errors[0].message}")
        return items
    errors = list(Draft202012Validator(schema, format_checker=FormatChecker()).iter_errors(data))
    if errors:
        raise RegistryError(f"invalid repository policy: {errors[0].message}")
    return data


def _git(root: Path, *args: str) -> str:
    environment = os.environ.copy()
    environment["GIT_TERMINAL_PROMPT"] = "0"
    environment["GIT_SSH_COMMAND"] = "ssh -o BatchMode=yes -o ConnectTimeout=10 -o ConnectionAttempts=1"
    try:
        result = subprocess.run(["git", "-C", str(root), *args], capture_output=True,
                                text=True, check=False, env=environment, timeout=30,
                                creationflags=background_creationflags())
    except subprocess.TimeoutExpired as exc:
        raise RegistryError("Core Git validation timed out") from exc
    if result.returncode:
        raise RegistryError("Core Git state is unavailable")
    return result.stdout.strip()


def _check_trusted_git(root: Path) -> str:
    from prisma_common.installed_binding import load_installed_binding
    try:
        binding = load_installed_binding(root.parent.parent)
    except (OSError, ValueError) as exc:
        raise RegistryError("customer Core trust binding is unavailable") from exc
    github = binding["resources"]["github"]
    repository = f"{github['owner']}/{github['core_repository']}"
    enrollment_commit = github["core_expected_commit"]
    if Path(_git(root, "rev-parse", "--show-toplevel")).resolve() != root:
        raise RegistryError("Core must be an independent Git repository")
    remote = _git(root, "remote", "get-url", "origin")
    if remote not in {f"git@github.com:{repository}.git", f"https://github.com/{repository}.git"}:
        raise RegistryError("Core origin is not the authorized repository")
    remote_head = _git(root, "rev-parse", "refs/remotes/origin/main")
    try:
        live_refs = _git(root, "ls-remote", "origin", "refs/heads/main").split()
    except RegistryError as exc:
        raise CoreRemoteUnavailable("authorized Core origin/main is unavailable") from exc
    if not live_refs:
        raise RegistryError("authorized Core origin/main is unavailable")
    live_head = live_refs[0]
    if live_head != remote_head:
        raise RegistryError("Core policy is stale relative to authorized origin/main")
    _git(root, "merge-base", "--is-ancestor", enrollment_commit, remote_head)
    return github["owner"]
