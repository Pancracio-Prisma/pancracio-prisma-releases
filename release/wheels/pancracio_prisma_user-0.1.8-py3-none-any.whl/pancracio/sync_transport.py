"""Pancracio-only Pub/Sub transport; never an Actor identity source."""

from __future__ import annotations

import base64
import hashlib
from importlib import resources
import json
import os
from pathlib import Path
import re
import time
from typing import Any

from google_auth_oauthlib.flow import InstalledAppFlow
import keyring
import requests

from .composition import _read_yaml, _write_yaml_atomic
from .identity import SCOPES, VerifiedActor, load_desktop_client_config, resolve_actor, validate_google_id_token
from .registry import CoreRegistry
from prisma_common.transport_profile import transport_profile as _verified_transport_profile
from prisma_common.repository_profile import repository_profile


TRANSPORT_SCOPES = SCOPES
_TOKEN_CACHE: dict[str, tuple[str, float]] = {}


class TransportError(ValueError):
    pass


def transport_profile(workspace: Path):
    try:
        return _verified_transport_profile(workspace)
    except (OSError, ValueError) as exc:
        raise TransportError("verified instance transport configuration is unavailable") from exc


def _expected_repositories(workspace: Path, manifest: dict[str, Any]) -> set[str]:
    profile = repository_profile(workspace)
    return ({row["repository"].split("/", 1)[1]
             for row in manifest["materialized_bindings"].values()}
            | {profile.workspace_id, profile.core_id, "pancracio-context"})


def _identity_snapshot_matches(core_root: Path, pinned_commit: Any) -> bool:
    """Broker may lag topology-only Core changes, never Actor identity changes."""
    if not isinstance(pinned_commit, str) or re.fullmatch(r"[0-9a-f]{40}", pinned_commit) is None:
        return False
    core_root = core_root.resolve(strict=True)
    from .registry import _check_trusted_git, _git
    _check_trusted_git(core_root)
    _git(core_root, "merge-base", "--is-ancestor", pinned_commit, "refs/remotes/origin/main")
    return (_git(core_root, "show", f"{pinned_commit}:registry/actors.yaml")
            == _git(core_root, "show", "refs/remotes/origin/main:registry/actors.yaml"))


def subscription_id(runtime_id: str) -> str:
    from uuid import UUID
    try:
        return "panky-rt-" + UUID(runtime_id).hex
    except (ValueError, AttributeError, TypeError) as exc:
        raise TransportError("invalid runtime ID") from exc


def _metadata(workspace: Path) -> dict[str, Any]:
    path = workspace / ".panky" / "sync" / "transport.yaml"
    value = _read_yaml(path)
    if not value or value.get("project") != transport_profile(workspace).project_id or value.get("topic") != transport_profile(workspace).topic_id:
        raise TransportError("Pancracio Context Sync transport is not enrolled")
    if value.get("provisioner") != transport_profile(workspace).provisioner_name:
        raise TransportError("Context Sync provisioner differs from signed binding")
    owner = _read_yaml(workspace / ".panky" / "owner.yaml")
    if not owner or value.get("runtime_id") != owner.get("runtime_id"):
        raise TransportError("sync transport is not bound to this runtime")
    if value.get("schema_version") == 2:
        subscriptions = value.get("subscriptions")
        if (not isinstance(subscriptions, dict) or not subscriptions
                or not all(isinstance(repo, str) and isinstance(sub, str)
                           and re.fullmatch(r"[a-z][a-z0-9-]{0,79}", repo)
                           and sub == scoped_subscription_id(owner["runtime_id"], repo)
                           for repo, sub in subscriptions.items())):
            raise TransportError("scoped sync transport is invalid")
    elif value.get("subscription") != subscription_id(owner["runtime_id"]):
        raise TransportError("sync transport is not bound to this runtime")
    return value


def scoped_subscription_id(runtime_id: str, repository_id: str) -> str:
    subscription_id(runtime_id)
    if not re.fullmatch(r"[a-z][a-z0-9-]{0,79}", repository_id):
        raise TransportError("invalid repository ID")
    return subscription_id(runtime_id) + "-" + hashlib.sha256(repository_id.encode()).hexdigest()[:12]


def enroll_transport(
    workspace: Path,
    *,
    open_browser: bool = True,
    actor: VerifiedActor | None = None,
    refresh_token: str | None = None,
) -> Path:
    """Store a Pancracio OIDC refresh grant for keyless federation; no GCP user IAM."""
    owner = _read_yaml(workspace / ".panky" / "owner.yaml")
    if not owner:
        raise TransportError("runtime must be composed first")
    profile = transport_profile(workspace)
    previous_refresh = keyring.get_password(transport_profile(workspace).keyring_service, owner["runtime_id"])
    if (actor is None) != (refresh_token is None):
        raise TransportError("Actor and offline transport grant must be supplied together")
    if actor is None:
        config = load_desktop_client_config(workspace)
        previous = os.environ.get("OAUTHLIB_RELAX_TOKEN_SCOPE")
        os.environ["OAUTHLIB_RELAX_TOKEN_SCOPE"] = "1"
        try:
            flow = InstalledAppFlow.from_client_config(config, scopes=list(TRANSPORT_SCOPES))
            flow.run_local_server(host="127.0.0.1", port=0, open_browser=open_browser,
                                  access_type="offline", prompt="consent")
            from .identity import validate_issued_scopes
            validate_issued_scopes(flow.oauth2session.token.get("scope", ""))
            actor = resolve_actor(validate_google_id_token(flow.oauth2session.token["id_token"],
                                                           flow.client_config["client_id"]),
                                  CoreRegistry.load(workspace / "domains" / "core"))
            refresh_token = flow.credentials.refresh_token
        finally:
            if previous is None:
                os.environ.pop("OAUTHLIB_RELAX_TOKEN_SCOPE", None)
            else:
                os.environ["OAUTHLIB_RELAX_TOKEN_SCOPE"] = previous
    assert actor is not None
    if actor.actor_id != owner["actor_id"]:
        raise TransportError("transport consent belongs to another Actor")
    from .composition import _owner_hash
    if _owner_hash(actor) != owner["google_subject_sha256"]:
        raise TransportError("transport Google subject differs from runtime owner")
    if not refresh_token:
        raise TransportError("Google did not issue an offline transport grant")
    keyring.set_password(transport_profile(workspace).keyring_service, owner["runtime_id"], refresh_token)
    try:
        mode_path = workspace / ".panky/gateway-auth-mode"
        if mode_path.is_symlink():
            raise TransportError("Gateway authentication mode path is unsafe")
        oidc_mode = mode_path.is_file() and mode_path.read_text(encoding="utf-8").strip() == "oidc"
        if oidc_mode:
            provisioned = _scoped_broker_request(workspace, "POST", previous={})
            manifest = _read_yaml(workspace / ".panky/context-manifest.yaml")
            expected = _expected_repositories(workspace, manifest)
            if (provisioned.get("actor_id") != owner["actor_id"]
                    or provisioned.get("release") != manifest["core_commit"]
                    or provisioned.get("subscriptions") != {
                        repo: scoped_subscription_id(owner["runtime_id"], repo) for repo in expected}):
                raise TransportError("scoped provisioner differs from active context")
        else:
            provisioned = _broker_request(workspace, "POST")
            if (provisioned.get("subscription") != subscription_id(owner["runtime_id"])
                    or not _identity_snapshot_matches(workspace / "domains" / "core",
                                                      provisioned.get("core_commit"))):
                raise TransportError("provisioner response differs from protected runtime policy")
    except Exception:
        if previous_refresh is None:
            keyring.delete_password(transport_profile(workspace).keyring_service, owner["runtime_id"])
        else:
            keyring.set_password(transport_profile(workspace).keyring_service, owner["runtime_id"], previous_refresh)
        raise
    path = workspace / ".panky" / "sync" / "transport.yaml"
    metadata = {"schema_version": 2 if oidc_mode else 1, "project": transport_profile(workspace).project_id,
                "topic": transport_profile(workspace).topic_id, "runtime_id": owner["runtime_id"],
                "provisioner": profile.provisioner_name}
    if oidc_mode:
        metadata["subscriptions"] = provisioned["subscriptions"]
    else:
        metadata["subscription"] = subscription_id(owner["runtime_id"])
    _write_yaml_atomic(path, metadata)
    set_sync_state(workspace, "READY")
    return path


def set_sync_state(workspace: Path, state: str) -> None:
    if state not in {"READY", "DEGRADED", "NOT_ENROLLED"}:
        raise TransportError("invalid sync state")
    owner = _read_yaml(workspace / ".panky" / "owner.yaml")
    manifest_path = workspace / ".panky" / "context-manifest.yaml"
    manifest = _read_yaml(manifest_path)
    if not owner or not manifest or manifest.get("runtime_id") != owner["runtime_id"]:
        raise TransportError("Context Manifest does not match runtime")
    manifest["sync"] = {"state": state}
    from .context_manifest14 import validate_graph_manifest
    if manifest.get("schema_version") != 3:
        raise TransportError("UPDATE_REQUIRED: Context Manifest schema 3 required")
    validate_graph_manifest(manifest)
    _write_yaml_atomic(manifest_path, manifest)


def _fresh_google_id_token(workspace: Path, *, allow_disabled: bool = False) -> str:
    owner = _read_yaml(workspace / ".panky" / "owner.yaml")
    if not owner:
        raise TransportError("runtime owner is unavailable")
    refresh = keyring.get_password(transport_profile(workspace).keyring_service, owner["runtime_id"])
    if not refresh:
        raise TransportError("Pancracio transport credential missing or revoked")
    installed = load_desktop_client_config(workspace)["installed"]
    try:
        response = requests.post(installed["token_uri"], data={
            "grant_type": "refresh_token", "refresh_token": refresh,
            "client_id": installed["client_id"], "client_secret": installed.get("client_secret", "")}, timeout=20)
        response.raise_for_status()
        token = response.json().get("id_token")
        claims = validate_google_id_token(token, installed["client_id"])
        import hashlib
        if hashlib.sha256(claims["sub"].encode()).hexdigest() != owner["google_subject_sha256"]:
            raise TransportError("federated Google subject differs from runtime owner")
        if not allow_disabled:
            actor = resolve_actor(claims, CoreRegistry.load(workspace / "domains" / "core"))
            if actor.actor_id != owner["actor_id"]:
                raise TransportError("federated Actor differs from runtime owner")
        return token
    except (requests.RequestException, ValueError, KeyError) as exc:
        raise TransportError("Pancracio Google transport grant unavailable") from exc


def _federated_access_token(workspace: Path, id_token: str) -> tuple[str, int]:
    exchange = requests.post("https://sts.googleapis.com/v1/token", json={
        "audience": f"//iam.googleapis.com/{transport_profile(workspace).wif_provider}",
        "grantType": "urn:ietf:params:oauth:grant-type:token-exchange",
        "requestedTokenType": "urn:ietf:params:oauth:token-type:access_token",
        "subjectTokenType": "urn:ietf:params:oauth:token-type:jwt",
        "subjectToken": id_token,
        "scope": "https://www.googleapis.com/auth/cloud-platform"}, timeout=20)
    exchange.raise_for_status()
    result = exchange.json()
    access_token = result.get("access_token")
    if not isinstance(access_token, str) or not access_token:
        raise TransportError("federated Pub/Sub token unavailable")
    return access_token, int(result.get("expires_in", 900))


def _broker_request(workspace: Path, method: str) -> dict[str, Any]:
    owner = _read_yaml(workspace / ".panky" / "owner.yaml")
    if not owner:
        raise TransportError("runtime owner is unavailable")
    try:
        proof = _fresh_google_id_token(workspace)
        token, _ = _federated_access_token(workspace, proof)
        impersonation = requests.post(
            f"https://iamcredentials.googleapis.com/v1/projects/-/serviceAccounts/{transport_profile(workspace).invoker_service_account}:generateIdToken",
            headers={"Authorization": f"Bearer {token}"},
            json={"audience": transport_profile(workspace).provisioner_url, "includeEmail": False}, timeout=20)
        impersonation.raise_for_status()
        invoker = impersonation.json()["token"]
        response = requests.request(method, transport_profile(workspace).provisioner_url + "/v1/runtime/subscription",
                                    headers={"Authorization": f"Bearer {invoker}",
                                             "X-Pancracio-Actor-Proof": proof},
                                    json={"runtime_id": owner["runtime_id"]}, timeout=25)
        response.raise_for_status()
        return response.json()
    except (requests.RequestException, ValueError, KeyError) as exc:
        raise TransportError("Pancracio runtime subscription provisioning unavailable") from exc


def _scoped_broker_request(workspace: Path, method: str,
                           *, previous: dict[str, str]) -> dict[str, Any]:
    owner = _read_yaml(workspace / ".panky" / "owner.yaml")
    if not owner:
        raise TransportError("runtime owner is unavailable")
    try:
        proof = _fresh_google_id_token(workspace)
        token, _ = _federated_access_token(workspace, proof)
        impersonation = requests.post(
            f"https://iamcredentials.googleapis.com/v1/projects/-/serviceAccounts/{transport_profile(workspace).invoker_service_account}:generateIdToken",
            headers={"Authorization": f"Bearer {token}"},
            json={"audience": transport_profile(workspace).provisioner_url, "includeEmail": False}, timeout=20)
        impersonation.raise_for_status()
        invoker = impersonation.json()["token"]
        response = requests.request(method, transport_profile(workspace).provisioner_url + "/v2/runtime/subscriptions",
                                    headers={"Authorization": f"Bearer {invoker}",
                                             "X-Pancracio-Actor-Proof": proof},
                                    json={"runtime_id": owner["runtime_id"],
                                          "previous": previous}, timeout=30)
        response.raise_for_status()
        return response.json()
    except (requests.RequestException, ValueError, KeyError) as exc:
        raise TransportError("Panky scoped subscription provisioning unavailable") from exc


def decommission_transport(workspace: Path) -> None:
    """Remove only this runtime's owned subscription and local transport grant."""
    metadata = _metadata(workspace)
    owner = _read_yaml(workspace / ".panky" / "owner.yaml")
    if not owner:
        raise TransportError("runtime owner is unavailable")
    if metadata.get("schema_version") == 2:
        _scoped_broker_request(workspace, "DELETE", previous=metadata["subscriptions"])
    else:
        _broker_request(workspace, "DELETE")
    keyring.delete_password(transport_profile(workspace).keyring_service, owner["runtime_id"])
    (workspace / ".panky" / "sync" / "transport.yaml").unlink(missing_ok=True)
    set_sync_state(workspace, "NOT_ENROLLED")


def reconcile_transport(workspace: Path) -> None:
    """Idempotently repair a broker-owned subscription; legacy candidates stay untouched."""
    metadata = _metadata(workspace)
    if metadata.get("provisioner") != transport_profile(workspace).provisioner_name:
        return
    mode_path = workspace / ".panky/gateway-auth-mode"
    if mode_path.is_symlink():
        raise TransportError("Gateway authentication mode path is unsafe")
    oidc_mode = mode_path.is_file() and mode_path.read_text(encoding="utf-8").strip() == "oidc"
    if oidc_mode and metadata.get("schema_version") != 2:
        response = _scoped_broker_request(workspace, "POST", previous={})
        owner = _read_yaml(workspace / ".panky/owner.yaml")
        manifest = _read_yaml(workspace / ".panky/context-manifest.yaml")
        expected = _expected_repositories(workspace, manifest)
        selected = {repo: scoped_subscription_id(owner["runtime_id"], repo)
                    for repo in expected}
        if (response.get("actor_id") != owner["actor_id"]
                or response.get("release") != manifest["core_commit"]
                or response.get("subscriptions") != selected):
            raise TransportError("scoped provisioner differs from active context")
        _broker_request(workspace, "DELETE")
        metadata.pop("subscription", None)
        metadata["schema_version"] = 2
        metadata["subscriptions"] = selected
        _write_yaml_atomic(workspace / ".panky/sync/transport.yaml", metadata)
        return
    if metadata.get("schema_version") == 2:
        response = _scoped_broker_request(workspace, "POST",
                                          previous=metadata["subscriptions"])
        owner = _read_yaml(workspace / ".panky/owner.yaml")
        manifest = _read_yaml(workspace / ".panky/context-manifest.yaml")
        expected = _expected_repositories(workspace, manifest)
        selected = {repo: scoped_subscription_id(owner["runtime_id"], repo)
                    for repo in expected}
        if (response.get("actor_id") != owner["actor_id"]
                or response.get("release") != manifest["core_commit"]
                or response.get("subscriptions") != selected):
            raise TransportError("scoped provisioner differs from active context")
        metadata["subscriptions"] = selected
        _write_yaml_atomic(workspace / ".panky/sync/transport.yaml", metadata)
        return
    response = _broker_request(workspace, "POST")
    if (response.get("subscription") != metadata["subscription"]
            or not _identity_snapshot_matches(workspace / "domains" / "core",
                                              response.get("core_commit"))):
        raise TransportError("provisioner response differs from protected runtime policy")


def _access_token(workspace: Path) -> str:
    data = _metadata(workspace)
    cached = _TOKEN_CACHE.get(data["runtime_id"])
    if cached and cached[1] > time.monotonic():
        return cached[0]
    try:
        access_token, lifetime = _federated_access_token(workspace, _fresh_google_id_token(workspace))
        _TOKEN_CACHE[data["runtime_id"]] = (access_token, time.monotonic() + max(30, lifetime - 120))
        return access_token
    except (requests.RequestException, ValueError, KeyError) as exc:
        raise TransportError("Pancracio keyless transport grant unavailable") from exc


def pull(workspace: Path, *, max_messages: int = 10) -> list[dict[str, Any]]:
    data = _metadata(workspace)
    try:
        names = (tuple(data["subscriptions"].values()) if data.get("schema_version") == 2
                 else (data["subscription"],))
        messages = []
        for name in names:
            url = f"https://pubsub.googleapis.com/v1/projects/{transport_profile(workspace).project_id}/subscriptions/{name}:pull"
            response = requests.post(url, headers={"Authorization": f"Bearer {_access_token(workspace)}"},
                                     json={"maxMessages": max(1, max_messages // len(names)),
                                           "returnImmediately": True}, timeout=10)
            response.raise_for_status()
            received = response.json().get("receivedMessages", [])
            if not isinstance(received, list):
                raise TransportError("invalid Pub/Sub response")
            for item in received:
                if not isinstance(item, dict):
                    raise TransportError("invalid Pub/Sub message")
                if data.get("schema_version") == 2:
                    item["_panky_subscription"] = name
                messages.append(item)
        return messages
    except (requests.RequestException, ValueError) as exc:
        raise TransportError("Pancracio Pub/Sub pull unavailable") from exc


def _ack_groups(workspace: Path, ack_ids: list[str | tuple[str, str]]) -> dict[str, list[str]]:
    data = _metadata(workspace)
    groups: dict[str, list[str]] = {}
    for item in ack_ids:
        if data.get("schema_version") == 2:
            if (not isinstance(item, tuple) or len(item) != 2
                    or item[1] not in data["subscriptions"].values()
                    or not isinstance(item[0], str)):
                raise TransportError("scoped ACK is not bound to this runtime")
            ack_id, name = item
        else:
            if not isinstance(item, str):
                raise TransportError("legacy ACK is invalid")
            ack_id, name = item, data["subscription"]
        groups.setdefault(name, []).append(ack_id)
    return groups


def acknowledge(workspace: Path, ack_ids: list[str | tuple[str, str]]) -> None:
    if not ack_ids:
        return
    try:
        for name, ids in _ack_groups(workspace, ack_ids).items():
            url = f"https://pubsub.googleapis.com/v1/projects/{transport_profile(workspace).project_id}/subscriptions/{name}:acknowledge"
            response = requests.post(url, headers={"Authorization": f"Bearer {_access_token(workspace)}"},
                                     json={"ackIds": ids}, timeout=20)
            response.raise_for_status()
    except requests.RequestException as exc:
        raise TransportError("Pancracio Pub/Sub ACK unavailable") from exc


def extend_ack_deadline(workspace: Path, ack_ids: list[str | tuple[str, str]], *, seconds: int = 120) -> None:
    """Lease pulled hints long enough for bounded remote Git validation."""
    if not ack_ids:
        return
    if not 10 <= seconds <= 600:
        raise TransportError("invalid Pub/Sub ACK deadline")
    try:
        for name, ids in _ack_groups(workspace, ack_ids).items():
            url = (f"https://pubsub.googleapis.com/v1/projects/{transport_profile(workspace).project_id}/subscriptions/"
                   f"{name}:modifyAckDeadline")
            response = requests.post(url, headers={"Authorization": f"Bearer {_access_token(workspace)}"},
                                     json={"ackIds": ids, "ackDeadlineSeconds": seconds}, timeout=20)
            response.raise_for_status()
    except requests.RequestException as exc:
        raise TransportError("Pancracio Pub/Sub ACK lease unavailable") from exc


def decode_message(message: dict[str, Any]) -> bytes:
    try:
        return base64.b64decode(message["message"]["data"], validate=True)
    except (KeyError, TypeError, ValueError) as exc:
        raise TransportError("invalid Pub/Sub payload") from exc
