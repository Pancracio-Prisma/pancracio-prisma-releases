# Panky 2.2 organizational entity offboarding contract

Use the same authenticated Actor, single Seat route, and published Core policy
as the corresponding onboarding. The person describes the outcome in ordinary
language. Resolve names through the scoped Gateway and protected Core; never
ask for IDs, SQL, repository paths, action codes, or a static token. An open
browser page is a clue, not authority. If several objects match, ask which
business object they mean before changing access.

First identify the exact active object and its dependencies. Explain only the
business consequence: who loses access, whether external data will remain,
and when it takes effect. A submission is pending until Core publishes and the
effective decision and object state are read back. Keep prior releases for
audit. Never substitute a direct database edit for a governed retirement.

| Onboarded object | Offboarding request in ordinary language | Required checks and readback |
| --- | --- | --- |
| Actor / occupant | “Esta persona ya no trabajará aquí” | Identify all occupied Seats, Founder or super-admin duties, active grants and in-flight work. Transfer duties first. Submit `panky governance entity_retire` for the Actor through a managing admin Seat whose scope covers every Seat the person occupies; Founder and super admins are excluded from this route. Core removes the Actor's assignments and grants, then publication must deny OIDC and Gateway access. Let the installation's verified revocation path retire organizational mounts and subscriptions. Personal data is not erased. |
| Seat | “Ya no necesitamos este puesto” | Remove occupants, child reporting links and owned resources before requesting `entity_retire` through an admin of that branch. Core retires the Seat and archives its context node while preserving history; publication removes its grants. Verify no active assignment, route or context access remains. Removing an occupant alone does not retire the Seat. |
| Department | “Cierra esta área” | Resolve child departments, Seats, owned and shared resources, context and approvals. Move or retire each intentionally, then request `entity_retire` through an admin of the branch. Core retires the department and archives its context node; backing history remains recoverable. Verify sibling and ancestor access separately. |
| Subcontext | “Quita este espacio compartido” | Identify the exact node and audience; after resolving child dependencies, request `entity_retire` through an admin of its department. Core archives the node and removes its active grants. Verify Context View no longer returns it; Git history may retain prior versions. |
| Role | “Este rol ya no se usa” | Reassign or retire every Seat using it, then a super admin requests `entity_retire` through an active Seat. Core removes the role, its scoped grants and rules. Verify no Seat can regain its former operations from stale policy. |
| Tool | “Ya no usaremos esta herramienta en Panky” | Identify its active resources and role operations. Retire those first or move them with explicit authorization. If `tool.retire` is in the scoped action catalog, submit `panky governance tool_retire` through the active Seat; otherwise use the protected Core path only when authorized. Publish and verify it is absent from the active policy. This does not uninstall the Gateway adapter or delete provider data. |
| Resource | “Quita este recurso de Panky” | Distinguish removing the policy registration from deleting the external object; ask only if intent is unclear. Resolve the resource through Gateway, check that no share or grant request is pending, and submit `panky governance resource_retire` through the owner Seat or an authorized admin Seat. Core removes its grants and department shares with the registration. Verify Gateway access is denied after publication. Delete external content only on a separate, authorized request. |
| Explicit grant or share | “Ya no compartas esto con esa persona/área” | Read current sharing first. If several recipients or department shares exist, clarify the intended scope. Revoke only matching active ALLOW and publish; do not add DENY merely to cancel it. Verify the recipient is denied while unrelated recipients retain access. |
| Super admin / Founder | “Retira esta autoridad” | Founder alone governs super-admin revocation; transfer Founder with successor acceptance before retiring the current Founder. Verify exactly one Founder and the Actor-level flag after publication. A Seat remains only basic or admin. |

For a simple user request, the agent performs the technical checks and protected
edit. If a required operation or connector is unavailable, say which business
outcome is pending; do not claim that the object was removed. Test the inverse
of every onboarding against the same test object, including an expected allow
before publication and denial after. Leave test Actors and objects in place
until their own offboarding flow has passed.
