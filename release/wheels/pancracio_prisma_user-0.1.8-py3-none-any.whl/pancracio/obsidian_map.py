"""Deterministic, repo-local Obsidian navigation for every mounted context."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import subprocess

from .obsidian_graph import related_notes


MAP_NAME = "Panky Context Map.md"


class ObsidianMapError(ValueError):
    pass


@dataclass(frozen=True)
class GraphAudit:
    notes: int
    orphans: int
    map_current: bool
    status: str


def tracked_markdown(root: Path, *, extra: tuple[str, ...] = ()) -> list[str]:
    result = subprocess.run(["git", "-C", str(root), "ls-files", "-z", "--", "*.md"],
                            capture_output=True, timeout=30)
    if result.returncode:
        raise ObsidianMapError("organizational Git inventory unavailable")
    paths = {name for name in result.stdout.decode("utf-8", "surrogateescape").split("\0") if name}
    paths.update(extra)
    safe: list[str] = []
    for name in sorted(paths):
        if name == MAP_NAME:
            continue
        path = root / name
        if (not name.endswith(".md") or path.is_symlink() or
                not path.resolve().is_relative_to(root.resolve()) or
                any(char in name for char in "[]\n\r|")):
            raise ObsidianMapError("organizational Markdown path cannot be linked safely")
        if path.is_file() or name in extra:
            safe.append(name)
    return safe


def render_map(workspace: Path, root: Path, *, extra: tuple[str, ...] = (),
               relative_prefix: str | None = None, scope: str = "organizational") -> str:
    if scope not in {"organizational", "personal"}:
        raise ObsidianMapError("unknown Obsidian map scope")
    notes = tracked_markdown(root, extra=extra)
    prefix = relative_prefix or root.relative_to(workspace).as_posix()
    lines = ["# Panky Context Map", "", f"Navigation for this {scope} context.", ""]
    for name in notes:
        target = (Path(prefix) / name).with_suffix("").as_posix()
        lines.append(f"- [[{target}]]")
    return "\n".join(lines) + "\n"


def audit_map(workspace: Path, root: Path, *, scope: str = "organizational") -> GraphAudit:
    names = tracked_markdown(root)
    tracked = set(names) | ({MAP_NAME} if (root / MAP_NAME).is_file() else set())
    untracked = [path for path in root.rglob("*.md")
                 if ".git" not in path.relative_to(root).parts
                 and path.relative_to(root).as_posix() not in tracked]
    if not names:
        return GraphAudit(0, len(untracked), not (root / MAP_NAME).exists(),
                          "NEEDS_REPAIR" if untracked or (root / MAP_NAME).exists() else "READY")
    map_path = root / MAP_NAME
    current = (map_path.is_file() and not map_path.is_symlink() and
               map_path.read_text(encoding="utf-8") == render_map(workspace, root, scope=scope))
    paths = [root / name for name in names]
    if map_path.is_file() and not map_path.is_symlink():
        paths.append(map_path)
    if len(paths) > 1000:
        return GraphAudit(len(names), len(names), current, "INCOMPLETE")
    graph = related_notes(paths, vault_root=workspace)
    orphans = sum(not graph.get(path.resolve()) for path in paths) + len(untracked)
    return GraphAudit(len(names) + len(untracked), orphans, current,
                      "READY" if current and not orphans else "NEEDS_REPAIR")


def audit_personal_graph(workspace: Path, actor_id: str) -> GraphAudit:
    """Audit only the verified runtime owner's private backing."""
    import yaml
    from .context_manifest14 import validate_graph_manifest
    from .identity import VerifiedActor
    from .personal_topology14 import read_personal_topology

    workspace = workspace.resolve(strict=True)
    manifest = yaml.safe_load((workspace / ".panky/context-manifest.yaml").read_text(encoding="utf-8"))
    validate_graph_manifest(manifest)
    personal = manifest["personal"]
    if (manifest["actor_id"] != actor_id or personal["owner_actor_id"] != actor_id
            or personal["path"] != "domains/actor"):
        raise ObsidianMapError("Personal backing differs from verified Actor")
    root = workspace / "domains/actor"
    if root.is_symlink() or not (root / ".git").is_dir():
        raise ObsidianMapError("Personal backing unavailable")
    read_personal_topology(workspace, VerifiedActor(actor_id, manifest["role"],
                                                    "inspection-only", "inspection-only"))
    return audit_map(workspace, root, scope="personal")


def audit_mounted_graph(workspace: Path) -> dict[str, GraphAudit]:
    """Audit only organizational backings in the validated runtime manifest."""
    import yaml
    from .context_manifest14 import validate_graph_manifest
    from .materialization14 import _local, _verify_binding
    from .node_authority import NodeAuthority
    from .registry import CoreRegistry

    workspace = workspace.resolve(strict=True)
    manifest = yaml.safe_load((workspace / ".panky/context-manifest.yaml").read_text(encoding="utf-8"))
    validate_graph_manifest(manifest)
    registry = CoreRegistry.load(workspace / "domains/core")
    authority = NodeAuthority(registry)
    reports: dict[str, GraphAudit] = {}
    for store_id, row in manifest["materialized_bindings"].items():
        binding = authority.bindings.get(store_id)
        if (binding is None or binding.node_id != row["node_id"]
                or binding.local_path != row["path"] or binding.repository != row["repository"]):
            raise ObsidianMapError("organizational manifest differs from protected Core")
        root = _local(workspace, binding.local_path)
        _verify_binding(root, binding)
        reports[binding.repository.split("/", 1)[1]] = audit_map(workspace, root)
    return reports
