"""Current Actor's organizational Seat scope from the active governed release."""

from __future__ import annotations

import json
from pathlib import Path

from .composition import _git
from .context_catalog20 import ContextCatalogError, fetch_catalog, verify_catalog
from .identity import VerifiedActor
from .registry import CoreRegistry


def active_actor_scope(workspace: Path, actor: VerifiedActor) -> list[dict[str, str]]:
    """Use OIDC catalog release plus protected Core; never infer authority from a name."""
    workspace = workspace.resolve()
    catalog = fetch_catalog(workspace / ".panky")
    release = catalog.get("release")
    if not isinstance(release, str):
        raise ContextCatalogError("active policy release is unavailable")
    core_root = workspace / "domains" / "core"
    registry = CoreRegistry.load_at_trusted_commit(core_root, release)
    verify_catalog(catalog, actor, registry, core_commit=release)
    try:
        policy = json.loads(_git(core_root, "show", f"{release}:policy/prisma-policy.json"))
    except (ValueError, KeyError) as exc:
        raise ContextCatalogError("active Seat policy is unavailable") from exc
    if policy.get("schema_version") != 3 or not isinstance(policy.get("seats"), list):
        raise ContextCatalogError("active Seat policy is invalid")
    departments = {row["code"]: row["name"] for row in policy.get("departments", [])}
    result = []
    for seat in policy["seats"]:
        if actor.actor_id not in seat.get("occupants", []):
            continue
        department = seat.get("department")
        seat_type = seat.get("seat_type")
        if department not in departments or seat_type not in ("admin", "basic", None):
            raise ContextCatalogError("active Seat assignment is invalid")
        if actor.role != "super_admin" and seat_type is None:
            raise ContextCatalogError("active Seat type is missing")
        result.append({"seat": seat["code"], "department": departments[department],
                       "seat_type": seat_type or "unassigned"})
    if not result:
        raise ContextCatalogError("authenticated Actor has no active Seat")
    return result
