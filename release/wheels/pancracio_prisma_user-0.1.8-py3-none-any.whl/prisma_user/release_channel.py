"""Discover the central Prisma release without trusting GitHub as publisher."""

from __future__ import annotations

from contextlib import contextmanager
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
from tempfile import TemporaryDirectory
from typing import Callable, Iterator

from packaging.version import Version

from prisma_common.installed_binding import load_installed_binding, runtime_directory
from prisma_common.intake import SetupInputError
from prisma_common.release import verify_release
from prisma_common.trusted_binding import public_key_fingerprint
from .release_install import install_release, recover_release


_TAG = re.compile(r"prisma-(macos|windows)-v(\d+\.\d+\.\d+)\Z")
_WHEEL = re.compile(r"[A-Za-z0-9][A-Za-z0-9_.+-]{5,199}\.whl\Z")
_RUNNER = Callable[[list[str]], str]
_PRODUCT_REPOSITORY = "Pancracio-Prisma/pancracio-prisma-releases"


def _run_gh(arguments: list[str]) -> str:
    try:
        result = subprocess.run(["gh", *arguments], capture_output=True, text=True,
                                timeout=180, check=False)
    except (OSError, subprocess.SubprocessError) as exc:
        raise SetupInputError("GitHub release channel is unavailable") from exc
    if result.returncode:
        # GitHub CLI diagnostics can include private repository information.
        raise SetupInputError("GitHub release channel is unavailable")
    return result.stdout


def _json_array(raw: str) -> list[dict]:
    try:
        value = json.loads(raw)
    except ValueError as exc:
        raise SetupInputError("GitHub release listing is invalid") from exc
    if not isinstance(value, list) or not all(isinstance(item, dict) for item in value):
        raise SetupInputError("GitHub release listing is invalid")
    return value


def _release_assets(raw: str, tag: str) -> set[str]:
    try:
        value = json.loads(raw)
    except ValueError as exc:
        raise SetupInputError("GitHub release metadata is invalid") from exc
    if (not isinstance(value, dict) or value.get("tagName") != tag
            or value.get("isDraft") is not False or value.get("isPrerelease") is not False
            or not isinstance(value.get("assets"), list)):
        raise SetupInputError("GitHub release metadata is invalid")
    assets = value["assets"]
    names = [item.get("name") for item in assets if isinstance(item, dict)]
    if (len(names) != len(assets) or len(names) != len(set(names)) or len(names) > 102
            or any(not isinstance(name, str) for name in names)):
        raise SetupInputError("GitHub release asset list is invalid")
    expected = {"release.json", "publisher-public-key.raw"}
    wheels = set(names) - expected
    if (not expected.issubset(names) or not wheels or
            any(not _WHEEL.fullmatch(name) for name in wheels)):
        raise SetupInputError("GitHub release asset list is invalid")
    for item in assets:
        size = item.get("size")
        name = item["name"]
        maximum = 64 * 1024 if name == "release.json" else 32 if name == "publisher-public-key.raw" else 100 * 1024 * 1024
        if not isinstance(size, int) or isinstance(size, bool) or not 0 < size <= maximum:
            raise SetupInputError("GitHub release asset size is invalid")
    return set(names)


@contextmanager
def approved_release(workspace: Path, *, home: Path | None = None,
                     local_appdata: Path | None = None, platform: str | None = None,
                     runner: _RUNNER = _run_gh) -> Iterator[tuple[Path, str, str]]:
    """Fetch the latest stable product release and verify the pinned publisher."""
    load_installed_binding(workspace, home=home, local_appdata=local_appdata,
                           platform=platform)
    _, runtime = runtime_directory(workspace, home=home, local_appdata=local_appdata,
                                   platform=platform)
    key_path = runtime / "release-publisher.raw"
    if key_path.is_symlink() or not key_path.is_file() or key_path.stat().st_size != 32:
        raise SetupInputError("publisher trust pin is unavailable; install the first signed release")
    fingerprint = public_key_fingerprint(key_path.read_bytes())
    system = platform or ("windows" if os.name == "nt" else "macos")
    if system not in {"macos", "windows"}:
        raise SetupInputError("unsupported Prisma release platform")
    repo = _PRODUCT_REPOSITORY
    releases = _json_array(runner(["release", "list", "-R", repo, "--json",
                                   "tagName,isDraft,isPrerelease", "--limit", "100"]))
    choices: list[tuple[Version, str]] = []
    for item in releases:
        tag = item.get("tagName")
        match = _TAG.fullmatch(tag) if isinstance(tag, str) else None
        if (match and match.group(1) == system and item.get("isDraft") is False
                and item.get("isPrerelease") is False):
            choices.append((Version(match.group(2)), tag))
    if not choices:
        raise SetupInputError("no approved Prisma release for this platform")
    version, tag = max(choices)
    names = _release_assets(runner(["release", "view", tag, "-R", repo, "--json",
                                    "tagName,isDraft,isPrerelease,assets"]), tag)
    with TemporaryDirectory(prefix="prisma-release-") as temporary:
        root = Path(temporary)
        runner(["release", "download", tag, "-R", repo, "-D", str(root)])
        if {item.name for item in root.iterdir()} != names or any(item.is_symlink() or not item.is_file() for item in root.iterdir()):
            raise SetupInputError("downloaded release differs from GitHub asset list")
        wheels = root / "wheels"
        wheels.mkdir(mode=0o700)
        for name in names - {"release.json", "publisher-public-key.raw"}:
            shutil.move(str(root / name), str(wheels / name))
        verified = verify_release(root, expected_fingerprint=fingerprint)
        if verified["version"] != str(version):
            raise SetupInputError("release tag differs from signed version")
        yield root, fingerprint, str(version)


def upgrade_from_channel(workspace: Path, *, check_only: bool = False,
                         home: Path | None = None, local_appdata: Path | None = None,
                         platform: str | None = None, runner: _RUNNER = _run_gh,
                         installer=None, postflight=None) -> dict:
    """Use the existing governed installer after verified channel discovery."""
    with approved_release(workspace, home=home, local_appdata=local_appdata,
                          platform=platform, runner=runner) as (release, fingerprint, version):
        _, runtime = runtime_directory(workspace, home=home, local_appdata=local_appdata,
                                       platform=platform)
        recovery = runtime / "release-recovery.json"
        if recovery.is_file():
            try:
                pending = json.loads(recovery.read_text(encoding="utf-8"))
            except (OSError, ValueError) as exc:
                raise SetupInputError("release recovery state is invalid") from exc
            if isinstance(pending, dict) and pending.get("target") == version and not check_only:
                return recover_release(workspace, home=home, local_appdata=local_appdata,
                                       platform=platform, **({"postflight": postflight} if postflight else {}))
        options = {"trusted_fingerprint": fingerprint, "home": home,
                   "local_appdata": local_appdata, "platform": platform,
                   "check_only": check_only}
        if installer is not None:
            options["installer"] = installer
        if postflight is not None:
            options["postflight"] = postflight
        return install_release(workspace, release, **options)
