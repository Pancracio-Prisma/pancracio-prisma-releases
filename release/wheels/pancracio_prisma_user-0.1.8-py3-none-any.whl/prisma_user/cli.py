"""End-user entry point bound to one enrolled Prisma instance."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import subprocess
import sys

from prisma_common.installed_binding import load_installed_binding
from prisma_common.oauth_profile import load_desktop_oauth
from prisma_common.bundle import verify_bundle
from prisma_common.release import verify_release
from .enrollment import enroll_bundle
from .release_install import install_release, mark_worker_unregistered, recover_release
from .release_channel import upgrade_from_channel


def main(argv: list[str] | None = None) -> int:
    arguments = list(sys.argv[1:] if argv is None else argv)
    local_commands = {"verify-local", "verify-bundle", "enroll-bundle", "verify-release", "upgrade"}
    if arguments and arguments[0] not in local_commands:
        if arguments[0] != "version":
            selected = Path.cwd()
            for index, argument in enumerate(arguments):
                if argument == "--workspace" and index + 1 < len(arguments):
                    selected = Path(arguments[index + 1])
                elif argument.startswith("--workspace="):
                    selected = Path(argument.split("=", 1)[1])
            try:
                load_installed_binding(selected)
            except (OSError, ValueError):
                print(json.dumps({"status": "LOCAL_BINDING_UNVERIFIED", "ready": False}), file=sys.stderr)
                return 4
        from pancracio.cli import main as runtime_main
        result = runtime_main(arguments)
        if result == 0 and arguments[:2] == ["sync-worker", "unregister"]:
            try:
                mark_worker_unregistered(selected)
            except (OSError, ValueError):
                print(json.dumps({"status": "WORKER_UNREGISTER_RECEIPT_FAILED", "ready": False}),
                      file=sys.stderr)
                return 4
        return result
    parser = argparse.ArgumentParser(prog="panky-prisma")
    commands = parser.add_subparsers(dest="command", required=True)
    verify = commands.add_parser("verify-local", help="verify this instance's signed binding and OAuth client")
    verify.add_argument("--workspace", type=Path, required=True)
    handoff = commands.add_parser("verify-bundle", help="verify a technician's handoff before installation")
    handoff.add_argument("--bundle", type=Path, required=True)
    handoff.add_argument("--trusted-fingerprint", required=True)
    enroll = commands.add_parser("enroll-bundle", help="pin a verified handoff in an unused local instance")
    enroll.add_argument("--bundle", type=Path, required=True)
    enroll.add_argument("--trusted-fingerprint", required=True)
    release = commands.add_parser("verify-release", help="verify an offline publisher-signed release")
    release.add_argument("--release", type=Path, required=True)
    release.add_argument("--trusted-publisher-fingerprint", required=True)
    upgrade = commands.add_parser("upgrade", help="activate a signed release in this instance only")
    upgrade.add_argument("--workspace", type=Path, required=True)
    upgrade.add_argument("--release", type=Path)
    upgrade.add_argument("--trusted-publisher-fingerprint")
    upgrade_mode = upgrade.add_mutually_exclusive_group()
    upgrade_mode.add_argument("--check", action="store_true")
    upgrade_mode.add_argument("--recover", action="store_true")
    args = parser.parse_args(arguments)
    if args.command == "verify-release":
        try:
            print(json.dumps(verify_release(args.release,
                  expected_fingerprint=args.trusted_publisher_fingerprint), sort_keys=True))
            return 0
        except (OSError, ValueError):
            print(json.dumps({"status": "RELEASE_UNVERIFIED", "ready": False}), file=sys.stderr)
            return 4
    if args.command == "upgrade":
        try:
            if args.recover:
                result = recover_release(args.workspace)
            else:
                if args.release is None and args.trusted_publisher_fingerprint is None:
                    result = upgrade_from_channel(args.workspace, check_only=args.check)
                elif args.release is not None and args.trusted_publisher_fingerprint is not None:
                    result = install_release(args.workspace, args.release,
                        trusted_fingerprint=args.trusted_publisher_fingerprint,
                        check_only=args.check)
                else:
                    raise ValueError("release and publisher fingerprint must be supplied together")
            print(json.dumps(result, sort_keys=True))
            return 0
        except (OSError, ValueError, subprocess.SubprocessError):
            print(json.dumps({"status": "RELEASE_INSTALLATION_FAILED", "ready": False}), file=sys.stderr)
            return 4
    if args.command == "enroll-bundle":
        try:
            print(json.dumps(enroll_bundle(args.bundle,
                                           trusted_fingerprint=args.trusted_fingerprint), sort_keys=True))
            return 0
        except (OSError, ValueError):
            print(json.dumps({"status": "BUNDLE_ENROLLMENT_REJECTED", "ready": False}), file=sys.stderr)
            return 4
    if args.command == "verify-bundle":
        try:
            print(json.dumps(verify_bundle(args.bundle,
                                           expected_fingerprint=args.trusted_fingerprint), sort_keys=True))
            return 0
        except (OSError, ValueError):
            print(json.dumps({"status": "BUNDLE_UNVERIFIED", "ready": False}), file=sys.stderr)
            return 4
    try:
        binding = load_installed_binding(args.workspace)
        load_desktop_oauth(args.workspace)
    except (OSError, ValueError):
        print(json.dumps({"status": "LOCAL_BINDING_UNVERIFIED", "ready": False}), file=sys.stderr)
        return 4
    print(json.dumps({"status": "LOCAL_BINDING_VERIFIED_ONLY", "ready": False,
                      "tenant_slug": binding["tenant_slug"], "instance_id": binding["instance_id"]},
                     sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
