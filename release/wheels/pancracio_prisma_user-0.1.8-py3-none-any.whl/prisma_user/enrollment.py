"""Pin an independently verified handoff in an unused instance namespace.

Enrollment creates no Core, worker, OAuth session or service registration.
"""

from __future__ import annotations

import os
from pathlib import Path
import shutil
from typing import Any

from prisma_common.bundle import verify_bundle
from prisma_common.instance import instance_id, local_preflight
from prisma_common.installed_binding import load_installed_binding, runtime_directory
from prisma_common.intake import SetupInputError, load_json
from prisma_common.oauth_profile import load_desktop_oauth


def enroll_bundle(bundle: Path, *, trusted_fingerprint: str,
                  home: Path | None = None, local_appdata: Path | None = None,
                  platform: str | None = None) -> dict[str, Any]:
    verified = verify_bundle(bundle, expected_fingerprint=trusted_fingerprint)
    envelope = load_json(bundle / "binding.json")
    intake = envelope["payload"]["intake"]
    identity = instance_id(intake)
    base_home = home or Path.home()
    preflight = local_preflight(intake, home=base_home, local_appdata=local_appdata,
                                platform=platform)
    if preflight["status"] != "LOCAL_PATHS_AVAILABLE_SERVICE_UNVERIFIED":
        raise SetupInputError("instance namespace is occupied")
    workspace = base_home / "Pancracio Prisma" / "instances" / identity / "workspace"
    _, runtime = runtime_directory(workspace, home=base_home, local_appdata=local_appdata,
                                   platform=platform)
    workspace_instance = workspace.parent
    runtime_instance = runtime.parent
    created: list[Path] = []
    written: list[Path] = []
    try:
        for target in (workspace_instance, runtime_instance):
            target.parent.mkdir(parents=True, exist_ok=True)
            target.mkdir(mode=0o700)
            created.append(target)
        runtime.mkdir(mode=0o700)
        for name in ("trust-public-key.raw", "binding.json", "desktop_oauth.json"):
            destination = runtime / name
            with destination.open("xb") as sink, (bundle / name).open("rb") as source:
                written.append(destination)
                shutil.copyfileobj(source, sink)
            if os.name != "nt":
                destination.chmod(0o600)
        # Read back the exact pinned namespace before reporting enrollment.
        load_installed_binding(workspace, home=base_home, local_appdata=local_appdata,
                               platform=platform)
        load_desktop_oauth(workspace, home=base_home, local_appdata=local_appdata,
                           platform=platform)
    except Exception:
        # Remove only bytes this call could have written. A concurrent writer's
        # unexpected files must never be swept up by rollback.
        for path in written:
            path.unlink(missing_ok=True)
        for target in (runtime, *reversed(created)):
            try:
                target.rmdir()
            except OSError:
                pass
        raise
    return {"status": "BUNDLE_ENROLLED_RUNTIME_NOT_INSTALLED",
            "tenant_slug": verified["tenant_slug"], "instance_id": identity,
            "workspace": str(workspace), "authority_granted": False,
            "runtime_installed": False}
