"""Install one signed Prisma release in one enrolled instance, without global paths."""

from __future__ import annotations

import json
import hashlib
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
from typing import Any, Callable
from uuid import uuid4
import venv

from filelock import FileLock, Timeout
from packaging.version import Version

from prisma_common.installed_binding import load_installed_binding, runtime_directory
from prisma_common.instance import layouts
from prisma_common.intake import SetupInputError
from prisma_common.release import verify_release
from prisma_common.trusted_binding import public_key_fingerprint


Installer = Callable[[Path, Path, str], None]


def _runtime_executable(slot: Path) -> Path:
    return slot / "venv" / ("Scripts/panky-prisma.exe" if os.name == "nt" else "bin/panky-prisma")


def _run_runtime(executable: Path, *arguments: str) -> str:
    result = subprocess.run([str(executable), *arguments], capture_output=True,
                            text=True, timeout=180, check=False)
    if result.returncode:
        # A child diagnostic can contain private context. Keep it out of the
        # release receipt and report only the failing operation.
        raise SetupInputError(f"Prisma runtime health step failed: {arguments[0]}")
    return result.stdout


def _postflight(workspace: Path, slot: Path) -> None:
    """Reconcile the new product rules before considering a composed Actor ready."""
    if not (workspace / ".panky" / "context-manifest.yaml").is_file():
        return  # first installation still needs the Actor's OIDC bootstrap
    executable = _runtime_executable(slot)
    _run_runtime(executable, "reconcile", "--workspace", str(workspace))
    _run_runtime(executable, "obsidian-repair", "--workspace", str(workspace), "--apply")
    health = _run_runtime(executable, "doctor", "--workspace", str(workspace))
    required = (f"Product CLI: {slot.name}", "Sync: READY", "Sync worker: RUNNING",
                "Personal topology: READY")
    if (any(value not in health for value in required)
            or not any(value in health for value in ("Gateway: READY", "Gateway: NOT_CONFIGURED"))
            or "Obsidian graph " not in health):
        raise SetupInputError("updated runtime did not become READY")


def _write_state(path: Path, payload: dict[str, Any]) -> None:
    if path.is_symlink():
        raise SetupInputError("instance release state is unsafe")
    temporary = path.with_name(f".{path.name}-{uuid4().hex}")
    try:
        with temporary.open("x", encoding="utf-8") as stream:
            json.dump(payload, stream, sort_keys=True)
            stream.write("\n")
        if os.name != "nt":
            temporary.chmod(0o600)
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def _remove_incomplete_slot(slot: Path) -> bool:
    marker = slot / ".installing"
    if (slot.is_symlink() or not slot.is_dir() or marker.is_symlink()
            or not marker.is_file() or marker.read_text(encoding="utf-8") !=
            "Prisma release installation in progress\n"):
        return False
    if {child.name for child in slot.iterdir()} - {".installing", "venv", "wheels"}:
        return False
    if any((slot / name).is_symlink() for name in ("venv", "wheels")):
        return False
    shutil.rmtree(slot)
    return True


def _install_wheels(staging: Path, wheelhouse: Path, version: str) -> None:
    environment = staging / "venv"
    venv.EnvBuilder(with_pip=True, clear=False).create(environment)
    python = environment / ("Scripts/python.exe" if os.name == "nt" else "bin/python")
    command = [str(python), "-m", "pip", "install", "--no-index", "--find-links", str(wheelhouse),
               f"pancracio-prisma-user=={version}"]
    result = subprocess.run(command, capture_output=True, text=True, timeout=300,
                            check=False, env={**os.environ, "PIP_NO_INDEX": "1"})
    if result.returncode:
        raise SetupInputError("offline Prisma wheel installation failed")
    executable = environment / ("Scripts/panky-prisma.exe" if os.name == "nt" else "bin/panky-prisma")
    check = subprocess.run([str(executable), "version"], capture_output=True, text=True,
                           timeout=30, check=False)
    if check.returncode or f"panky-prisma {version}" not in check.stdout:
        raise SetupInputError("installed Prisma release failed its version check")


def mark_worker_unregistered(workspace: Path, *, home: Path | None = None,
                             local_appdata: Path | None = None,
                             platform: str | None = None) -> None:
    """Record an explicit successful unregister for the current active version."""
    load_installed_binding(workspace, home=home, local_appdata=local_appdata, platform=platform)
    _, runtime = runtime_directory(workspace, home=home, local_appdata=local_appdata,
                                    platform=platform)
    active = runtime / "active-release.json"
    marker = runtime / "worker-unregistered.json"
    if active.is_symlink() or not active.is_file() or marker.is_symlink():
        raise SetupInputError("active release or worker receipt is unsafe")
    try:
        version = json.loads(active.read_text(encoding="utf-8"))["version"]
        if not isinstance(version, str) or not re.fullmatch(r"[0-9]+\.[0-9]+\.[0-9]+", version):
            raise ValueError
    except (OSError, ValueError, KeyError, TypeError) as exc:
        raise SetupInputError("active release pointer is invalid") from exc
    temporary = runtime / f".worker-unregistered-{uuid4().hex}.json"
    try:
        with temporary.open("x", encoding="utf-8") as stream:
            json.dump({"schema_version": 1, "version": version}, stream)
            stream.write("\n")
        if os.name != "nt":
            temporary.chmod(0o600)
        os.replace(temporary, marker)
    finally:
        temporary.unlink(missing_ok=True)


def _registered_worker(workspace: Path, *, home: Path | None,
                       local_appdata: Path | None, platform: str | None,
                       previous: str) -> bool:
    """Fail closed before replacing an executable referenced by a local worker."""
    binding = load_installed_binding(workspace, home=home, local_appdata=local_appdata,
                                     platform=platform)
    layout = layouts(binding["intake"])
    system = platform or ("windows" if os.name == "nt" else "macos" if sys.platform == "darwin" else "other")
    if system == "macos":
        label = layout["macos"]["launch_agent_label"]
        path = (home or Path.home()) / "Library" / "LaunchAgents" / f"{label}.plist"
        if path.exists() or path.is_symlink():
            return True
        if sys.platform == "darwin" and home is None:
            result = subprocess.run(["launchctl", "print", f"gui/{os.getuid()}/{label}"],
                                    capture_output=True, timeout=10, check=False)
            return result.returncode == 0
        return False
    if system == "windows":
        if os.name != "nt":
            raise SetupInputError("Windows worker state cannot be checked on this platform")
        name = layout["windows"]["task_name"]
        result = subprocess.run(["schtasks", "/Query", "/TN", name],
                                capture_output=True, timeout=10, check=False)
        if result.returncode == 0:
            return True
        marker = runtime_directory(workspace, home=home, local_appdata=local_appdata,
                                   platform=platform)[1] / "worker-unregistered.json"
        if marker.is_symlink() or not marker.is_file():
            raise SetupInputError("Windows worker absence is unverified; unregister it first")
        try:
            receipt = json.loads(marker.read_text(encoding="utf-8"))
        except (OSError, ValueError) as exc:
            raise SetupInputError("Windows worker unregister receipt is invalid") from exc
        if receipt != {"schema_version": 1, "version": previous}:
            raise SetupInputError("Windows worker unregister receipt is stale")
        return False
    raise SetupInputError("unsupported platform for Prisma release upgrade")


def install_release(workspace: Path, release: Path, *, trusted_fingerprint: str,
                    home: Path | None = None, local_appdata: Path | None = None,
                    platform: str | None = None, installer: Installer = _install_wheels,
                    check_only: bool = False,
                    postflight: Callable[[Path, Path], None] = _postflight) -> dict[str, Any]:
    """Prepare a version and atomically select it after an offline health check."""
    load_installed_binding(workspace, home=home, local_appdata=local_appdata, platform=platform)
    identity, runtime = runtime_directory(workspace, home=home, local_appdata=local_appdata,
                                          platform=platform)
    lock_path = runtime / "release.lock"
    if lock_path.is_symlink():
        raise SetupInputError("instance release lock is unsafe")
    try:
        with FileLock(str(lock_path), timeout=20):
            return _install_release_locked(identity, runtime, release, trusted_fingerprint,
                                           installer, check_only, workspace, home,
                                           local_appdata, platform, postflight)
    except Timeout as exc:
        raise SetupInputError("instance release operation is busy") from exc


def _install_release_locked(identity: str, runtime: Path, release: Path,
                            trusted_fingerprint: str, installer: Installer,
                            check_only: bool, workspace: Path, home: Path | None,
                            local_appdata: Path | None, platform: str | None,
                            postflight: Callable[[Path, Path], None]) -> dict[str, Any]:
    verified = verify_release(release, expected_fingerprint=trusted_fingerprint)
    key = (release / "publisher-public-key.raw").read_bytes()
    pinned_key = runtime / "release-publisher.raw"
    if pinned_key.is_symlink() or (pinned_key.exists() and pinned_key.read_bytes() != key):
        raise SetupInputError("instance publisher key differs from installed trust pin")
    version = verified["version"]
    active = runtime / "active-release.json"
    recovery = runtime / "release-recovery.json"
    if recovery.is_symlink():
        raise SetupInputError("release recovery state is unsafe")
    pending = json.loads(recovery.read_text(encoding="utf-8")) if recovery.is_file() else None
    if pending is not None and (not isinstance(pending, dict)
                                or pending.get("status") != "RECOVERY_REQUIRED"
                                or not isinstance(pending.get("target"), str)
                                or not isinstance(pending.get("previous"), (str, type(None)))):
        raise SetupInputError("release recovery state is invalid")
    if active.is_symlink():
        raise SetupInputError("active release pointer is unsafe")
    previous = None
    if active.exists():
        try:
            pointer_data = json.loads(active.read_text(encoding="utf-8"))
            if (not isinstance(pointer_data, dict)
                    or set(pointer_data) != {"schema_version", "version"}
                    or pointer_data["schema_version"] != 1
                    or not isinstance(pointer_data["version"], str)
                    or not re.fullmatch(r"[0-9]+\.[0-9]+\.[0-9]+", pointer_data["version"])):
                raise ValueError
            previous = pointer_data["version"]
        except (OSError, ValueError, KeyError) as exc:
            raise SetupInputError("active release pointer is invalid") from exc
    if previous == version and pending is None:
        if check_only or not (workspace / ".panky/context-manifest.yaml").is_file():
            return {"status": "RELEASE_ALREADY_ACTIVE", "version": version, "instance_id": identity}
        slot = runtime / "versions" / version
        if slot.is_symlink() or not (slot / "venv").is_dir():
            raise SetupInputError("active release runtime is unavailable")
        if _registered_worker(workspace, home=home, local_appdata=local_appdata,
                              platform=platform, previous=version):
            _run_runtime(_runtime_executable(slot), "sync-worker", "unregister",
                         "--workspace", str(workspace))
        try:
            postflight(workspace, slot)
        except (OSError, ValueError, subprocess.SubprocessError) as exc:
            _write_state(recovery, {"status": "RECOVERY_REQUIRED", "target": version,
                                    "previous": version})
            raise SetupInputError("active release health recovery is required") from exc
        return {"status": "RELEASE_READY", "version": version, "instance_id": identity}
    if pending is not None and Version(version) <= Version(pending["target"]):
        raise SetupInputError("pending release requires recovery or a newer approved release")
    if previous is not None and Version(version) < Version(previous):
        raise SetupInputError("signed release is older than the active instance version")
    if check_only:
        return {"status": "RELEASE_VERIFIED_NOT_INSTALLED", "version": version,
                "current_version": previous, "instance_id": identity}
    versions = runtime / "versions"
    if versions.is_symlink():
        raise SetupInputError("instance version directory is unsafe")
    versions.mkdir(mode=0o700, exist_ok=True)
    target = versions / version
    if target.exists() or target.is_symlink():
        raise SetupInputError("release version slot is occupied")
    # Virtual environments embed absolute interpreter paths, so they must be
    # built in the final version slot. Only the active pointer changes atomically.
    target.mkdir(mode=0o700)
    selected = False
    worker_was_registered = False
    worker_unregistered = False
    pointer: Path | None = None
    try:
        if previous is not None and pending is None:
            worker_was_registered = _registered_worker(workspace, home=home,
                                                       local_appdata=local_appdata,
                                                       platform=platform,
                                                       previous=previous)
            if worker_was_registered:
                _run_runtime(_runtime_executable(versions / previous), "sync-worker", "unregister",
                             "--workspace", str(workspace))
                worker_unregistered = True
        (target / ".installing").write_text("Prisma release installation in progress\n", encoding="utf-8")
        wheel_snapshot = target / "wheels"
        shutil.copytree(release / "wheels", wheel_snapshot)
        manifest = json.loads((release / "release.json").read_text(encoding="utf-8"))["payload"]["wheels"]
        if {path.name for path in wheel_snapshot.iterdir()} != set(manifest):
            raise SetupInputError("copied release wheel set differs from signed manifest")
        for name, expected in manifest.items():
            with (wheel_snapshot / name).open("rb") as stream:
                actual = hashlib.file_digest(stream, "sha256").hexdigest()
            if actual != expected:
                raise SetupInputError("copied release wheel differs from signed manifest")
        installer(target, wheel_snapshot, version)
        if not (target / "venv").is_dir():
            raise SetupInputError("installer did not create an instance runtime")
        shutil.rmtree(wheel_snapshot)
        if not pinned_key.exists():
            with pinned_key.open("xb") as stream:
                stream.write(key)
            if os.name != "nt":
                pinned_key.chmod(0o600)
        pointer = runtime / f".active-{uuid4().hex}.json"
        with pointer.open("x", encoding="utf-8") as stream:
            json.dump({"schema_version": 1, "version": version}, stream)
            stream.write("\n")
        if os.name != "nt":
            pointer.chmod(0o600)
        os.replace(pointer, active)
        selected = True
        try:
            postflight(workspace, target)
        except (OSError, ValueError, subprocess.SubprocessError) as exc:
            _write_state(recovery, {"status": "RECOVERY_REQUIRED", "target": version,
                                    "previous": pending["previous"] if pending else previous})
            raise SetupInputError("release installed but health recovery is required") from exc
        recovery.unlink(missing_ok=True)
        try:
            (runtime / "worker-unregistered.json").unlink(missing_ok=True)
        except OSError:
            # A stale receipt cannot authorize another version and does not
            # undo an already selected, healthy release.
            pass
    finally:
        if not selected:
            if pointer is not None:
                pointer.unlink(missing_ok=True)
            # A failed install must leave the prior active release untouched.
            if target.exists() and previous != version:
                _remove_incomplete_slot(target)
            if worker_unregistered:
                try:
                    _run_runtime(_runtime_executable(versions / previous), "sync-worker", "install",
                                 "--workspace", str(workspace))
                except (OSError, ValueError, subprocess.SubprocessError):
                    _write_state(recovery, {"status": "RECOVERY_REQUIRED", "target": previous,
                                            "previous": previous})
                    raise SetupInputError("previous worker could not be restored")
    try:
        (target / ".installing").unlink(missing_ok=True)
    except OSError:
        # The pointer already selected this healthy version. Recovery can
        # remove the stale marker without changing the active release.
        pass
    return {"status": "RELEASE_ACTIVE", "version": version, "previous_version": previous,
            "instance_id": identity, "runtime": str(target / "venv")}


def recover_release(workspace: Path, *, home: Path | None = None,
                    local_appdata: Path | None = None,
                    platform: str | None = None,
                    postflight: Callable[[Path, Path], None] = _postflight) -> dict[str, Any]:
    """Finish an installed release's health checks; clean only incomplete slots."""
    load_installed_binding(workspace, home=home, local_appdata=local_appdata, platform=platform)
    identity, runtime = runtime_directory(workspace, home=home, local_appdata=local_appdata,
                                          platform=platform)
    lock_path = runtime / "release.lock"
    if lock_path.is_symlink():
        raise SetupInputError("instance release lock is unsafe")
    try:
        with FileLock(str(lock_path), timeout=20):
            active = runtime / "active-release.json"
            if active.is_symlink():
                raise SetupInputError("active release pointer is unsafe")
            current = None
            if active.exists():
                try:
                    current = json.loads(active.read_text(encoding="utf-8"))["version"]
                except (OSError, ValueError, KeyError) as exc:
                    raise SetupInputError("active release pointer is invalid") from exc
            recovery = runtime / "release-recovery.json"
            if recovery.is_symlink():
                raise SetupInputError("release recovery state is unsafe")
            pending = json.loads(recovery.read_text(encoding="utf-8")) if recovery.is_file() else None
            if pending is not None:
                if (not isinstance(pending, dict) or pending.get("status") != "RECOVERY_REQUIRED"
                        or pending.get("target") != current or not isinstance(current, str)):
                    raise SetupInputError("release recovery state differs from the active version")
                slot = runtime / "versions" / current
                if slot.is_symlink() or not (slot / "venv").is_dir():
                    raise SetupInputError("pending release runtime is unavailable")
                try:
                    postflight(workspace, slot)
                except (OSError, ValueError, subprocess.SubprocessError) as exc:
                    raise SetupInputError("release recovery remains pending") from exc
                recovery.unlink()
                (slot / ".installing").unlink(missing_ok=True)
            versions = runtime / "versions"
            if versions.is_symlink():
                raise SetupInputError("instance version directory is unsafe")
            removed = []
            if versions.is_dir():
                for slot in versions.iterdir():
                    marker = slot / ".installing"
                    if slot.is_symlink() or not slot.is_dir() or marker.is_symlink() or not marker.is_file():
                        continue
                    if slot.name == current:
                        marker.unlink()
                    elif re.fullmatch(r"[0-9]+\.[0-9]+\.[0-9]+", slot.name):
                        if _remove_incomplete_slot(slot):
                            removed.append(slot.name)
            return {"status": "RELEASE_RECOVERED", "instance_id": identity,
                    "active_version": current, "removed_incomplete": sorted(removed)}
    except Timeout as exc:
        raise SetupInputError("instance release operation is busy") from exc
