# Pancracio Prisma: contrato de instalación de usuario para el agente de instalación

Codex, Claude Code o Antigravity pueden ser el agente de instalación hasta que
Panky Prisma demuestre identidad,
autoridad y salud. La guía humana es `END_USER_INSTALL.md` en el kit extraído
(y `docs/END_USER_INSTALL.md` en el producto). La persona abre la carpeta
extraída como workspace del agente elegido y puede iniciar con un mensaje genérico:
«Instala Panky Prisma siguiendo las instrucciones de esta carpeta». Lee
`AGENTS.md` y este contrato del kit; no exijas rutas internas ni que inicie
fuera de la carpeta. No pidas al usuario crear GCP, Core, repositorios
organizacionales ni políticas: eso
pertenece a la instalación técnica ya verificada.

1. Confirma que estás en la carpeta **extraída** del ZIP de esta empresa, no
   dentro del ZIP ni en el workspace de otro Pancracio. Localiza el aviso de
   verificación junto al ZIP, junto a la carpeta extraída o en la ubicación
   que indique la persona. No le pidas entender, copiar ni comparar huellas.
   Dentro del kit están el bundle y el release firmados; el aviso puede
   estar también en esa carpeta sin cambiar la verificación. Muestra el nombre de
   la empresa y las rutas reservadas para **esta instancia**; el bundle las
   determina, no una carpeta elegida por el usuario.
   En POC, inicia Personal local; la cuenta universal no accede al
   conocimiento privado de la persona. En modo definitivo, pregunta si
   quiere Personal local o un repositorio privado propio. El
   Gateway organizacional ya viene fijado en el bundle por Tech Install;
   no preguntes si desea omitirlo ni qué modalidad de hosting usa. No
   preguntes datos que ya están en el bundle; no solicites tokens o
   contraseñas en el chat.
2. Comprueba Python 3.12, Git y acceso al canal público de paquetes firmados
   `Pancracio-Prisma/pancracio-prisma-releases`, sin pedir acceso al código
   privado del producto. En POC, el bundle identifica la cuenta universal de
   transporte; no pidas al usuario una cuenta GitHub ni compartas credenciales.
   El usuario POC no necesita cuenta GitHub propia, una sesión abierta en
   GitHub ni una clave SSH preexistente. Bootstrap autentica primero al Actor
   con Google, crea una clave SSH nueva y única de esta instalación, la registra
   mediante el Gateway y comprueba lectura de los
   repositorios autorizados antes del primer clon. En modo definitivo, prepara
   la cuenta GitHub individual y comprueba acceso a Workspace y Core. La
   identidad GitHub no sustituye la prueba Google del Actor.
   Antes de instalar código, localiza el aviso `-verification.md` dentro o
   junto a la carpeta extraída, junto al ZIP o donde indique la persona;
   compara sus dos huellas SHA-256 con las claves públicas del paquete.
   Acepta que el aviso y el ZIP hayan llegado juntos en cualquier modo: no
   exijas prueba de un segundo canal si ambos archivos están presentes y coinciden.
   Sigue verificando las firmas y el release; Google OIDC autentica al Actor
   después y no sustituye esta comprobación del código. El aviso junto al ZIP
   comprueba la consistencia de la entrega, no un origen independiente.
   Si falta el aviso o alguna huella difiere, detente y pide el archivo correcto;
   no conviertas la aprobación verbal del usuario en prueba de firma.
   En un entorno temporal **fuera** de cualquier
   instalación existente, instala solo los wheels de `release/wheels` con
   `pip --no-index --find-links`, seleccionando
   `pancracio-prisma-user==<versión del release>`; usa ese ejecutable temporal para verificar
   firmas y contenidos con `panky-prisma verify-bundle` y `verify-release`.
   Antes de crear la instancia, ejecuta
   `panky-prisma install-first --bundle <kit>/bundle --bundled-release <kit>/release
   --operator-fingerprint <huella-del-operador> --publisher-fingerprint <huella-del-publicador>`
   con las dos huellas del aviso (nunca tomadas solo del kit).
   Si el kit contiene `agent-profile.json`, añade
   `--profile-update <kit>/agent-profile.json` para activar su nombre firmado
   en esta instancia. Si ese archivo falla la firma o no corresponde a la
   empresa e instancia, detén el alta; no uses el nombre del archivo como prueba.
   Este comando verifica el kit, consulta el último release estable para este
   sistema, lo descarga y verifica con la misma clave del publicador; instala
   directamente esa versión. Si el canal no responde, la firma difiere o la
   versión disponible es anterior a la del kit, detente: no instales a
   escondidas la versión incluida. Nunca sustituyas el comando global `panky`
   ni otro Pancracio.
3. Usa el Workspace devuelto por `install-first`. El comando inscribe la
   instancia solo después de verificar el release vigente, y deja el primer
   bootstrap pendiente. A partir de ahí usa el ejecutable del entorno propio
   de la instancia, no el temporal. Usa únicamente el Workspace y los
   repositorios que el bundle enlaza; un enlace editable, el login de GitHub o
   una carpeta local no autorizan materialización. Si en modo definitivo el
   usuario eligió un Personal remoto, crea su repositorio privado vacío en la cuenta que
   él seleccionó y registra su propietario exacto; confirma la acción antes
   de crear ese recurso.
4. Explica en lenguaje sencillo que Google pedirá iniciar sesión con la
   cuenta de trabajo y, cuando corresponda, aprobar el acceso de Panky a
   Workspace (Drive, Docs o Sheets) para actuar en nombre de esa cuenta,
   siempre sujeto al acceso de Google y a la política de la empresa. No
   presentes el consentimiento como acceso ilimitado ni lo ocultes. Comprueba
   que el endpoint firmado del Gateway responde y que su política
   organizacional está activa. Ejecuta bootstrap con `--gateway-oidc`; Google
   y Core resolverán al Actor, no el bundle. No uses un token heredado ni `--skip-gateway` como salida
   de una falla de conexión. Si falta el catálogo o la identidad no coincide,
   detén la instalación sin READY. El humano completa Google OIDC y cualquier
   permiso nativo. No elijas cuentas, ingreses credenciales ni apruebes
   consentimientos por él.
5. Bootstrap verifica el Actor contra Core protegido y pide al
   Gateway su catálogo de Seats y nodos. Materializa por Git/SSH solo los
   repos de ese catálogo dentro del vault de Obsidian y registra Context Sync
   filtrado por repo bajo el nombre de la instancia. Comprueba `doctor`,
   `context scope`, mapa de notas y backlinks, el worker y una señal real.
   Rechaza un nodo fuera de alcance; una señal no concede acceso.
6. Completa el onboarding conversacional una pregunta a la vez. Guarda solo
   hechos durables en el destino autorizado y confirma su recibo. Cierra cada
   turno sustantivo con `memory-checkpoint`, aun si no hay una nota que guardar;
   no infieras
   que un estado conversacional COMPLETE significa que Personal se guardó.
   Declara READY únicamente cuando identidad, contexto, worker, sincronización
   y comprobaciones de aislamiento estén sanos. El Gateway y el catálogo
   organizacional deben quedar READY para esta instancia Prisma.
   Al declarar READY, usa `panky-prisma first-chat --workspace <workspace>
   --provider <codex|claude|antigravity>` con la ruta exacta devuelta por
   `install-first` y el proveedor que la persona eligió para instalar.
   Sigue el mismo recorrido de interfaz que usa el Acquisition Engine para
   sus chats efímeros: enfoca **esa** ventana nueva de VS Code, comprueba que
   el Workspace es el instalado, abre la paleta de comandos y selecciona
   exactamente `new_chat_command` del recibo. Si el recibo incluye
   `new_session_action`, pulsa ese control en la vista del proveedor antes de
   escribir el saludo; en Claude Code es `New session`. Comprueba que el compositor
   pertenece al proveedor elegido antes de pegar `greeting` y enviarlo una sola
   vez. Comprueba que el mensaje aparece en el chat correcto y espera una
   respuesta que use el nombre configurado y la identidad autenticada. Si el
   envío queda incierto, inspecciona el chat antes de reintentar para evitar
   duplicados. El comando solo abre la carpeta:
   `WORKSPACE_OPENED_GREETING_PENDING` no prueba que el chat haya respondido.
   Si tu entorno no puede controlar la interfaz de ese proveedor, deja el
   primer chat pendiente y diagnostica el control de esa interfaz; no delegues
   el envío del saludo a la persona ni declares completado el traspaso.
   La carpeta extraída
   del ZIP solo corresponde al setup. Comprueba que las configuraciones locales de
   Codex, Claude Code y Antigravity apunten a esta instancia y no contengan
   credenciales; cada interfaz puede solicitar confianza en el proyecto.
   Si la instalación queda pendiente, conserva el
   estado y continúa en el chat de instalación hasta completar la recuperación.

Antes de entregar un POC, verifica que el broker de la cuenta universal está
activo y que esta instalación completó el registro de su clave y la lectura
SSH. Cuando Core anuncie una salida de POC, usa la capacidad de migración ya
instalada: Panky mostrará la cuenta GitHub asignada, preguntará qué perfil de
Chrome la tiene abierta, tramitará las invitaciones autorizadas y comprobará
su nueva clave y sus repositorios. Si GitHub CLI (`gh`) falta, el agente lo instala
desde el gestor oficial de paquetes del sistema y reanuda el mismo paso; no
pidas comandos, tokens o claves a la persona. Mantén el transporte universal
hasta recibir el comprobante individual. Una señal perdida se recupera al
volver a sincronizar Core; no reinstales ni entregues un kit nuevo para ello.

Para versiones posteriores, cuando el usuario diga «actualiza Panky», ejecuta
`panky-prisma upgrade --workspace <workspace>` desde el runtime de esa
instancia. El comando busca el último release aprobado para macOS o Windows
en el repositorio central Pancracio Prisma, lo descarga temporalmente y verifica la
firma contra la clave del publicador fijada en la primera instalación. Usa
`--check` si solo se pide consultar. Si no hay release accesible o la firma
falla, conserva la versión activa y explica el bloqueo; no uses el release de
otro cliente ni un `panky` global de otra instalación.

Si el proceso se interrumpe, inspecciona el recibo y usa recuperación. No
borres la carpeta ni repitas bootstrap desde cero. Para actualizaciones usa el
release firmado y el ciclo gobernado por instancia: el instalador pausa y
reanuda su worker, reconcilia los contextos, repara el mapa de Obsidian y
comprueba Doctor antes de declarar READY. Si hay `RECOVERY_REQUIRED`, reintenta
o avanza a un release firmado más nuevo sin tocar Personal. La baja también afecta solo esa instancia y exige
un recibo de que sus datos y servicios propios quedaron identificados.

Si un release informa `bootstrap_pending: true`, la actualización del código
terminó pero el alta de esta persona sigue pendiente. Continúa bootstrap desde
su estado guardado y luego comprueba catálogo, SSH, contexto y worker. No
consultes el catálogo por separado antes de que exista la concesión de
sincronización; el bootstrap la establece. Un reintento tras una falla del
Gateway puede volver a abrir Google para comprobar la misma identidad: explica
el motivo sin presentarlo como una cuenta o permiso nuevo.

## Desinstalación local por instancia

Ante «desinstala Panky», distingue esta limpieza local del offboarding del
Actor. Identifica la instancia firmada; nunca uses una ruta propuesta por texto
o borres otro Pancracio. Ejecuta `panky-prisma uninstall --workspace
<workspace>` para mostrar el plan y el alcance, incluyendo Personal local.
Confirma con la persona la instancia exacta y si necesita conservar datos que
solo existen en este equipo. Luego ejecuta `panky-prisma uninstall --prepare
--confirm-instance <id> --workspace <workspace>` desde el runtime instalado.
Si falta una revocación remota o de GitHub, conserva el runtime y reintenta;
no fuerces la limpieza ni hagas offboarding del Actor.

Después de `UNINSTALL_PREPARED`, sal del workspace de la instancia y espera a
que termine ese proceso. Desde el entorno temporal de instalación, **fuera**
del runtime que se va a borrar, ejecuta `panky-prisma uninstall --cleanup
--confirm-instance <id> --workspace <workspace>`. En Windows no intentes
borrar el venv desde su propio ejecutable. Comprueba que las rutas exactas del
recibo fueron eliminadas y que las demás instancias siguen intactas. Si una
raíz de instancia es un symlink o el proceso está parado dentro de ella, detente
y diagnostica; no sustituyas el comando con un borrado amplio. El recibo de
limpieza local no cambia el estado organizacional del Actor.
