"""Open the installed workspace for a verified first conversation."""

from __future__ import annotations

from pathlib import Path
import os
import shutil
import subprocess

from prisma_common.installed_binding import load_installed_binding
from prisma_common.intake import SetupInputError

from .agent_profile import active_display_name

PROVIDER_CHAT_COMMANDS = {
    "codex": "Codex: New Chat in ChatGPT Sidebar",
    "claude": "Claude Code: Open in Side Bar",
    "antigravity": "Antigravity: New Conversation",
    "gemini": "Terminal: Create New Terminal",
}


def _vscode_command(which) -> str | None:
    found = which("code") or which("code.cmd")
    if found:
        return found
    candidates = [Path("/Applications/Visual Studio Code.app/Contents/Resources/app/bin/code")]
    for parent in (os.environ.get("LOCALAPPDATA"), os.environ.get("ProgramFiles")):
        if parent:
            candidates.append(Path(parent) / "Programs/Microsoft VS Code/bin/code.cmd")
            candidates.append(Path(parent) / "Microsoft VS Code/bin/code.cmd")
    return next((str(path) for path in candidates if path.is_file()), None)


def open_first_chat(workspace: Path, provider: str, *, which=shutil.which, run=subprocess.run) -> dict:
    """Open a new VS Code window with an exact, provider-specific handoff."""
    if provider not in PROVIDER_CHAT_COMMANDS:
        raise SetupInputError("unsupported VS Code chat provider")
    workspace = workspace.resolve(strict=True)
    load_installed_binding(workspace)
    name = active_display_name(workspace)["display_name"]
    executable = _vscode_command(which)
    if not executable:
        raise SetupInputError("VS Code command line is unavailable")
    try:
        completed = run([executable, "--new-window", str(workspace)],
                        capture_output=True, text=True, timeout=30, check=False)
    except (OSError, subprocess.SubprocessError) as exc:
        raise SetupInputError("could not open the installed Workspace in VS Code") from exc
    if completed.returncode:
        raise SetupInputError("could not open the installed Workspace in VS Code")
    # A process exit code cannot prove that an extension opened or replied.
    return {"status": "WORKSPACE_OPENED_GREETING_PENDING", "workspace": str(workspace),
            "provider": provider, "new_chat_command": PROVIDER_CHAT_COMMANDS[provider],
            "new_session_action": "New session" if provider == "claude" else None,
            "greeting": f"Hola, {name}", "ready": False}
