"""Per-instance SSH selection for Git subprocesses."""

from __future__ import annotations

import json
import os
from pathlib import Path
import re
import shlex

from prisma_common.installed_binding import load_installed_binding, runtime_directory
from prisma_common.github_ssh import ensure_github_known_hosts, known_hosts_option


class GitTransportError(ValueError):
    """The active instance SSH transport is unsafe or inconsistent."""


def workspace_for(root: Path) -> Path | None:
    """Find the enrolled Workspace enclosing a repository checkout."""
    root = Path(root).resolve()
    for candidate in (root, *root.parents):
        if (candidate / ".panky" / "owner.yaml").is_file():
            return candidate
        if (candidate.name == "workspace"
                and re.fullmatch(r"[a-z][a-z0-9-]{2,30}", candidate.parent.name)):
            return candidate
    return None


def _repo(remote: str) -> str | None:
    match = re.fullmatch(r"git@github\.com:([^/]+)/([^/]+?)(?:\.git)?", remote)
    if match:
        return f"{match.group(1)}/{match.group(2)}"
    match = re.fullmatch(r"https://github\.com/([^/]+)/([^/]+?)(?:\.git)?", remote)
    return f"{match.group(1)}/{match.group(2)}" if match else None


def _signed_repositories(binding: dict) -> set[str]:
    github = binding["resources"]["github"]
    names = {github[name] for name in ("workspace_repository", "core_repository",
                                       "actor_template_repository", "knowledge_repository")}
    names.update(github["node_repositories"])
    names.update(github["publication_repositories"])
    return {f"{github['owner']}/{name}" for name in names}


def _poc_identity(runtime: Path, instance: str, binding: dict,
                  workspace: Path) -> tuple[Path, Path, list[str]] | None:
    pointer = runtime / "poc-ssh-active.json"
    if pointer.is_symlink():
        raise GitTransportError("POC SSH pointer is unsafe")
    if not pointer.exists():
        return None
    if not pointer.is_file():
        raise GitTransportError("POC SSH pointer is unsafe")
    try:
        active = json.loads(pointer.read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        raise GitTransportError("POC SSH pointer is invalid") from exc
    required = {"schema_version", "instance_id", "actor_id", "runtime_id",
                "private_key", "repositories", "fingerprint"}
    if (not isinstance(active, dict) or set(active) != required
            or active.get("schema_version") != 1 or active.get("instance_id") != instance
            or not isinstance(active.get("actor_id"), str)
            or not re.fullmatch(r"[A-Za-z][A-Za-z0-9_-]{2,63}", active["actor_id"])
            or not isinstance(active.get("runtime_id"), str) or not active["runtime_id"]
            or not isinstance(active.get("private_key"), str)
            or Path(active["private_key"]).name != active["private_key"]
            or not isinstance(active.get("repositories"), list) or not active["repositories"]
            or any(not isinstance(repo, str) or not re.fullmatch(r"[^/]+/[^/]+", repo)
                   for repo in active["repositories"])
            or len(set(active["repositories"])) != len(active["repositories"])
            or not isinstance(active.get("fingerprint"), str)
            or not re.fullmatch(r"SHA256:[A-Za-z0-9+/]{43}", active["fingerprint"])):
        raise GitTransportError("POC SSH pointer does not match this instance")
    owner_path = workspace / ".panky" / "owner.yaml"
    if owner_path.exists():
        if owner_path.is_symlink() or not owner_path.is_file():
            raise GitTransportError("instance Actor binding is unsafe")
        try:
            import yaml
            owner = yaml.safe_load(owner_path.read_text(encoding="utf-8"))
        except (OSError, ValueError) as exc:
            raise GitTransportError("instance Actor binding is invalid") from exc
        if not isinstance(owner, dict) or owner.get("actor_id") != active["actor_id"]:
            raise GitTransportError("POC SSH pointer belongs to another Actor")
        manifest_path = workspace / ".panky" / "context-manifest.yaml"
        if manifest_path.is_symlink():
            raise GitTransportError("Context Manifest path is unsafe")
        if manifest_path.is_file():
            try:
                import yaml
                manifest = yaml.safe_load(manifest_path.read_text(encoding="utf-8"))
            except (OSError, ValueError) as exc:
                raise GitTransportError("Context Manifest is invalid") from exc
            if (isinstance(manifest, dict) and isinstance(manifest.get("personal"), dict)
                    and manifest["personal"].get("mode") == "private"):
                raise GitTransportError("remote Actor Personal stays local until individual SSH migration")
    repositories = active["repositories"]
    if not set(repositories).issubset(_signed_repositories(binding)):
        raise GitTransportError("POC SSH repository scope exceeds the signed instance")
    key = runtime / active["private_key"]
    public = runtime / f"{active['private_key']}.pub"
    if key.is_symlink() or not key.is_file() or public.is_symlink() or not public.is_file():
        raise GitTransportError("POC instance SSH key is unavailable")
    try:
        import base64
        import hashlib
        public_parts = public.read_text(encoding="ascii").strip().split()
        if len(public_parts) < 2 or public_parts[0] != "ssh-ed25519":
            raise ValueError
        public_bytes = public_parts[1]
        actual = "SHA256:" + base64.b64encode(hashlib.sha256(
            base64.b64decode(public_bytes, validate=True)).digest()).decode("ascii").rstrip("=")
    except (OSError, ValueError, IndexError) as exc:
        raise GitTransportError("POC instance SSH public key is invalid") from exc
    if actual != active["fingerprint"]:
        raise GitTransportError("POC SSH pointer fingerprint differs from the key")
    known_hosts = ensure_github_known_hosts(runtime)
    return key, known_hosts, repositories


def ssh_command(workspace: Path | None) -> str:
    """Use the active verified key, or retain the established POC transport."""
    fallback = "ssh -o BatchMode=yes -o ConnectTimeout=10 -o ConnectionAttempts=1"
    if workspace is None:
        return fallback
    try:
        instance, runtime = runtime_directory(workspace)
    except (OSError, ValueError):
        raise GitTransportError("enrolled Workspace has no valid instance runtime")
    pointer = runtime / "github-ssh-active.json"
    if pointer.is_symlink():
        raise GitTransportError("instance SSH active pointer is unsafe")
    if not pointer.exists():
        poc_pointer = runtime / "poc-ssh-active.json"
        if poc_pointer.is_symlink():
            raise GitTransportError("POC SSH pointer is unsafe")
        if not poc_pointer.exists():
            return fallback
        try:
            binding = load_installed_binding(workspace)
            poc = _poc_identity(runtime, instance, binding, workspace)
        except GitTransportError:
            raise
        except (OSError, ValueError) as exc:
            raise GitTransportError("POC SSH identity cannot be verified") from exc
        if poc is None:
            return fallback
        key, known_hosts, _repositories = poc
        return ("ssh -i " + shlex.quote(str(key))
                + " -o IdentitiesOnly=yes -o StrictHostKeyChecking=yes"
                + " -o " + shlex.quote(known_hosts_option(known_hosts))
                + " -o BatchMode=yes -o ConnectTimeout=10 -o ConnectionAttempts=1")
    if not pointer.is_file():
        raise GitTransportError("instance SSH active pointer is unsafe")
    try:
        active = json.loads(pointer.read_text(encoding="utf-8"))
        binding = load_installed_binding(workspace)
    except (OSError, ValueError) as exc:
        raise GitTransportError("instance SSH active pointer cannot be verified") from exc
    owner_path = workspace / ".panky" / "owner.yaml"
    if owner_path.is_symlink() or not owner_path.is_file():
        raise GitTransportError("instance Actor binding is unavailable")
    try:
        import yaml
        owner = yaml.safe_load(owner_path.read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        raise GitTransportError("instance Actor binding is invalid") from exc
    if (not isinstance(active, dict)
            or set(active) != {"schema_version", "instance_id", "actor_id", "login", "core_commit", "repositories", "gateway_mode", "gateway_request_id", "private_key"}
            or active.get("schema_version") != 1
            or active.get("instance_id") != instance
            or active.get("instance_id") != binding.get("instance_id")
            or not isinstance(owner, dict) or active.get("actor_id") != owner.get("actor_id")
            or not isinstance(active.get("login"), str) or not active["login"]
            or not isinstance(active.get("core_commit"), str)
            or not isinstance(active.get("repositories"), list)
            or any(not isinstance(repository, str) for repository in active["repositories"])
            or active.get("gateway_mode") not in {"pending", "individual"}
            or not isinstance(active.get("gateway_request_id"), str)
            or not isinstance(active.get("private_key"), str)
            or Path(active["private_key"]).name != active["private_key"]):
        raise GitTransportError("instance SSH active pointer does not match this instance")
    key = runtime / active["private_key"]
    if key.is_symlink() or not key.is_file() or key.parent.resolve() != runtime.resolve():
        raise GitTransportError("instance SSH private key is unavailable")
    try:
        known_hosts = ensure_github_known_hosts(runtime)
    except (OSError, ValueError) as exc:
        raise GitTransportError("trusted GitHub SSH host key is unavailable") from exc
    if active["gateway_mode"] != "individual":
        try:
            poc = _poc_identity(runtime, instance, binding, workspace)
        except GitTransportError:
            raise
        except (OSError, ValueError) as exc:
            raise GitTransportError("POC SSH identity cannot be verified") from exc
        if poc is None:
            raise GitTransportError("individual GitHub SSH key has not been acknowledged")
        key, known_hosts, _repositories = poc
    return ("ssh -i " + shlex.quote(str(key))
            + " -o IdentitiesOnly=yes -o StrictHostKeyChecking=yes"
            + " -o " + shlex.quote(known_hosts_option(known_hosts))
            + " -o BatchMode=yes -o ConnectTimeout=10 -o ConnectionAttempts=1")


def git_environment(root: Path) -> dict[str, str]:
    environment = {name: value for name, value in os.environ.items()
                   if not name.startswith("GIT_")}
    environment["GIT_TERMINAL_PROMPT"] = "0"
    environment["GIT_SSH_COMMAND"] = ssh_command(workspace_for(root))
    return environment
