"""First POC Git transport, established before any customer repository clone."""

from __future__ import annotations

import base64
import hashlib
import json
import os
from pathlib import Path
import re
import shlex
import subprocess
from typing import Any
from uuid import uuid4

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
import requests

from prisma_common.installed_binding import load_installed_binding, runtime_directory
from .gateway import gateway_api_base
from .identity import BootstrapProof, IdentityError
from prisma_user.ssh_transport import (SSHTransportError, generate_key_pair,
                                       key_specific_ssh_command, secure_private_key)


_ACTOR_ID = re.compile(r"[A-Za-z][A-Za-z0-9_-]{2,63}\Z")
_REPOSITORY = re.compile(r"[A-Za-z0-9][A-Za-z0-9_.-]*/[A-Za-z0-9][A-Za-z0-9_.-]*\Z")


def _post(endpoint: str, access: str | None, data: dict[str, Any]) -> dict[str, Any]:
    headers = {"Authorization": f"Bearer {access}"} if access else {}
    try:
        response = requests.post(endpoint, json=data, headers=headers, timeout=30)
        response.raise_for_status()
        result = response.json()
    except (requests.RequestException, ValueError) as exc:
        raise SSHTransportError("POC Git transport service is unavailable") from exc
    if not isinstance(result, dict):
        raise SSHTransportError("POC Git transport receipt is invalid")
    return result


def _state_path(runtime: Path) -> Path:
    path = runtime / "poc-bootstrap.json"
    if path.is_symlink():
        raise SSHTransportError("POC bootstrap state is unsafe")
    return path


def _state(workspace: Path, claims: dict[str, Any]) -> dict[str, str]:
    _, runtime = runtime_directory(workspace)
    if runtime.is_symlink() or not runtime.is_dir():
        raise SSHTransportError("signed instance runtime is unavailable")
    subject = claims.get("sub")
    if not isinstance(subject, str) or not subject:
        raise IdentityError("verified Google subject is unavailable")
    subject_hash = hashlib.sha256(subject.encode("utf-8")).hexdigest()
    path = _state_path(runtime)
    if path.is_file():
        try:
            record = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError) as exc:
            raise SSHTransportError("POC bootstrap state is invalid") from exc
        if (not isinstance(record, dict)
                or set(record) != {"schema_version", "runtime_id", "subject_hash",
                                   "private_key", "public_key"}
                or record.get("schema_version") != 1
                or record.get("subject_hash") != subject_hash
                or not isinstance(record.get("runtime_id"), str)
                or not isinstance(record.get("private_key"), str)
                or not isinstance(record.get("public_key"), str)):
            raise SSHTransportError("POC bootstrap belongs to another Google identity")
        for name in (record["private_key"], record["public_key"]):
            if Path(name).name != name or (runtime / name).is_symlink() or not (runtime / name).is_file():
                raise SSHTransportError("POC bootstrap key is unavailable")
        secure_private_key(runtime / record["private_key"])
        return record
    key = generate_key_pair(workspace)
    record = {"schema_version": 1, "runtime_id": str(uuid4()),
              "subject_hash": subject_hash,
              "private_key": Path(key["private_key_path"]).name,
              "public_key": Path(key["public_key_path"]).name}
    encoded = (json.dumps(record, sort_keys=True) + "\n").encode("utf-8")
    try:
        with path.open("xb") as handle:
            handle.write(encoded)
        if os.name != "nt":
            path.chmod(0o600)
    except FileExistsError as exc:
        raise SSHTransportError("POC bootstrap was started concurrently") from exc
    return record


def _signed_repository_names(binding: dict[str, Any]) -> set[str]:
    github = binding["resources"]["github"]
    owner = github["owner"]
    names = {github[name] for name in (
        "workspace_repository", "core_repository", "actor_template_repository",
        "knowledge_repository")}
    names.update(github["node_repositories"])
    names.update(github["publication_repositories"])
    return {f"{owner}/{name}" for name in names}


def _bootstrap_repository_names(workspace: Path, binding: dict[str, Any]) -> set[str]:
    """Add repositories authorized by the verified active protected Core.

    A first bootstrap has no Core checkout and retains the signed-kit trust
    boundary. Once Core is present, failure to verify its current graph is a
    hard failure; local manifest contents are never used to widen the list.
    """
    allowed = _signed_repository_names(binding)
    core = workspace / "domains" / "core"
    if core.is_symlink():
        raise SSHTransportError("protected Core checkout is unsafe")
    if not core.exists():
        return allowed
    if not (core / ".git").is_dir():
        raise SSHTransportError("protected Core checkout is unsafe")
    try:
        from .context_sync import authorized_mounts
        mounts = authorized_mounts(workspace)
        owner = binding["resources"]["github"]["owner"]
        dynamic = set()
        for mount in mounts.values():
            if getattr(mount, "kind", None) not in {"graph_node", "graph_publication"}:
                continue
            remote = getattr(mount, "remote", None)
            prefix = f"git@github.com:{owner}/"
            if not isinstance(remote, str) or not remote.startswith(prefix) or not remote.endswith(".git"):
                raise ValueError("graph mount differs from signed tenant")
            dynamic.add(remote[len(prefix):-4])
        allowed.update(f"{owner}/{name}" for name in dynamic)
    except Exception as exc:
        raise SSHTransportError("protected Core repository authorization is unavailable") from exc
    return allowed


def verify_bootstrap_core_inventory(workspace: Path, registry: Any,
                                    receipt: dict[str, Any]) -> None:
    """Confirm a broker-only repository list against the cloned protected Core."""
    from .composition import _git
    from .node_authority import NodeAuthority

    binding = load_installed_binding(workspace)
    core_commit = receipt.get("core_commit")
    if core_commit is None:
        allowed = _signed_repository_names(binding)
    else:
        if (not isinstance(core_commit, str)
                or not re.fullmatch(r"[0-9a-f]{40}", core_commit)
                or _git(workspace / "domains" / "core", "rev-parse",
                        "refs/remotes/origin/main") != core_commit):
            raise SSHTransportError("broker and protected Core release differ")
        owner = binding["resources"]["github"]["owner"]
        allowed = _signed_repository_names(binding) | {
            item.repository for item in NodeAuthority(registry).bindings.values()
            if item.repository.startswith(owner + "/")
        }
    if not set(receipt["repositories"]) <= allowed:
        raise SSHTransportError("broker repository is absent from protected Core")


def _verify_repositories(command: list[str], repositories: list[str]) -> None:
    env = os.environ.copy()
    env["GIT_SSH_COMMAND"] = shlex.join(command)
    env["GIT_TERMINAL_PROMPT"] = "0"
    for repository in repositories:
        try:
            result = subprocess.run(
                ["git", "ls-remote", f"git@github.com:{repository}.git", "HEAD"],
                capture_output=True, text=True, check=False, timeout=30, env=env)
        except (OSError, subprocess.SubprocessError) as exc:
            raise SSHTransportError("POC repository SSH readback failed") from exc
        if result.returncode or not result.stdout.strip():
            raise SSHTransportError("POC repository SSH readback failed")


def prepare_poc_bootstrap(workspace: Path, proof: BootstrapProof) -> dict[str, Any]:
    """Register one Actor-bound key and prove its exact reads before first clone."""
    binding = load_installed_binding(workspace)
    if binding["intake"]["deployment"].get("poc") is not True:
        raise SSHTransportError("this instance is not in POC mode")
    instance, runtime = runtime_directory(workspace)
    state = _state(workspace, proof.claims)
    base = gateway_api_base(workspace / ".panky")
    exchanged = _post(base + "auth/panky/exchange", None,
                      {"google_id_token": proof.id_token})
    access = exchanged.get("access_token")
    if not isinstance(access, str) or not access:
        raise SSHTransportError("Gateway OIDC exchange is invalid")
    receipt = _post(base + "panky/installations/register", access,
                    {"runtime_id": state["runtime_id"], "instance_id": instance})
    actor_id = receipt.get("actor_id")
    if (receipt.get("status") != "registered"
            or receipt.get("runtime_id") != state["runtime_id"]
            or receipt.get("instance_id") != instance
            or receipt.get("transport_mode") != "shared"
            or not isinstance(actor_id, str) or not _ACTOR_ID.fullmatch(actor_id)):
        raise SSHTransportError("Gateway installation identity differs from signed instance")
    public_key = (runtime / state["public_key"]).read_text(encoding="ascii").strip()
    key_receipt = _post(base + "panky/poc-transport/key", access,
                        {"runtime_id": state["runtime_id"],
                         "instance_id": instance, "public_key": public_key})
    repositories = key_receipt.get("authorized_repositories")
    if (key_receipt.get("status") not in {"pending_readback", "client_attested"}
            or key_receipt.get("runtime_id") != state["runtime_id"]
            or not isinstance(key_receipt.get("github_login"), str)
            or key_receipt["github_login"].casefold()
               != binding["intake"]["deployment"]["poc_github_account"].casefold()
            or not isinstance(key_receipt.get("fingerprint"), str)
            or not re.fullmatch(r"SHA256:[A-Za-z0-9+/]{43}", key_receipt["fingerprint"])
            or not isinstance(repositories, list) or not repositories
            or any(not isinstance(repo, str) or not _REPOSITORY.fullmatch(repo)
                   for repo in repositories)
            or len(set(repositories)) != len(repositories)
            or not set(repositories) <= (
                _bootstrap_repository_names(workspace, binding)
                if (workspace / "domains" / "core").exists()
                else (_signed_repository_names(binding) | {
                    repo for repo in repositories
                    if repo.startswith(binding["resources"]["github"]["owner"] + "/")
                })
            ) or (not set(repositories) <= _signed_repository_names(binding)
                  and not re.fullmatch(r"[0-9a-f]{40}",
                                       str(key_receipt.get("core_commit", ""))))):
        raise SSHTransportError("POC broker returned an unauthorized repository list")
    github = binding["resources"]["github"]
    required = {f"{github['owner']}/{github[name]}" for name in
                ("workspace_repository", "core_repository")}
    if not required <= set(repositories):
        raise SSHTransportError("POC broker omitted protected customer repositories")
    private_path = runtime / state["private_key"]
    command = key_specific_ssh_command(private_path)
    _verify_repositories(command, repositories)
    if key_receipt["status"] == "pending_readback":
        nonce, payload = key_receipt.get("readback_nonce"), key_receipt.get("readback_payload")
        if not isinstance(nonce, str) or not isinstance(payload, str):
            raise SSHTransportError("POC readback challenge is invalid")
        try:
            parsed = json.loads(payload)
            if (not isinstance(parsed, dict)
                    or parsed.get("domain") != "panky-poc-shared-key-readback-v1"
                    or parsed.get("instance_id") != instance
                    or not isinstance(parsed.get("github_login"), str)
                    or parsed["github_login"].casefold()
                       != key_receipt["github_login"].casefold()
                    or parsed.get("fingerprint") != key_receipt["fingerprint"]
                    or parsed.get("nonce") != nonce
                    or parsed.get("runtime_id") != state["runtime_id"]
                    or parsed.get("actor_id") != actor_id
                    or parsed.get("repositories") != repositories):
                raise ValueError
            key = serialization.load_ssh_private_key(private_path.read_bytes(), password=None)
            if not isinstance(key, Ed25519PrivateKey):
                raise ValueError
            signature = base64.urlsafe_b64encode(key.sign(payload.encode("utf-8"))).decode().rstrip("=")
        except (OSError, ValueError, TypeError) as exc:
            raise SSHTransportError("POC readback challenge is invalid") from exc
        confirmed = _post(base + "panky/poc-transport/confirm", access,
                          {"runtime_id": state["runtime_id"], "nonce": nonce,
                           "signature": signature})
        if (confirmed.get("status") != "client_attested"
                or confirmed.get("runtime_id") != state["runtime_id"]
                or confirmed.get("authorized_repositories") != repositories):
            raise SSHTransportError("POC repository readback was not recorded")
    pointer = runtime / "poc-ssh-active.json"
    if pointer.is_symlink():
        raise SSHTransportError("POC SSH pointer is unsafe")
    pointer_data = {"schema_version": 1, "instance_id": instance,
                    "actor_id": actor_id, "runtime_id": state["runtime_id"],
                    "private_key": state["private_key"],
                    "repositories": repositories,
                    "fingerprint": key_receipt["fingerprint"]}
    write_pointer = True
    if pointer.is_file():
        try:
            current_pointer = json.loads(pointer.read_text(encoding="utf-8"))
            if not isinstance(current_pointer, dict):
                raise ValueError
            stable_keys = ("schema_version", "instance_id", "actor_id", "runtime_id",
                           "private_key", "fingerprint")
            if any(current_pointer.get(key) != pointer_data[key] for key in stable_keys):
                raise SSHTransportError("POC SSH pointer differs from broker receipt")
            write_pointer = current_pointer != pointer_data
        except (OSError, ValueError) as exc:
            raise SSHTransportError("POC SSH pointer is invalid") from exc
    if write_pointer:
        temporary = runtime / f".poc-ssh-active-{uuid4().hex}"
        try:
            with temporary.open("xb") as handle:
                handle.write((json.dumps(pointer_data, sort_keys=True) + "\n").encode("utf-8"))
            if os.name != "nt":
                temporary.chmod(0o600)
            os.replace(temporary, pointer)
        finally:
            temporary.unlink(missing_ok=True)
    return {"actor_id": actor_id, "runtime_id": state["runtime_id"],
            "subject_hash": state["subject_hash"],
            "private_key_path": private_path, "repositories": repositories,
            "core_commit": key_receipt.get("core_commit"),
            "ssh_command": shlex.join(command)}
