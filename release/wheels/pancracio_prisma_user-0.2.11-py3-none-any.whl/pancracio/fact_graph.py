"""Bounded, source-backed fact links for retrieval inside an authorized view.

This module never decides access and never returns a fact as an answer. The
caller supplies only already-admitted sources and receives source paths.
"""

from __future__ import annotations

from collections import defaultdict, deque
from dataclasses import dataclass
from datetime import date
import json
from pathlib import Path
import re
import subprocess
from typing import Iterable

import yaml

from .processes import background_creationflags


@dataclass(frozen=True)
class FactLink:
    subject: str
    relation: str
    object: str
    source_path: str
    source_commit: str


def _entity(value: str) -> str:
    return " ".join(re.findall(r"[\wáéíóúñ]+", value.casefold()))


def _published_text(path: Path, commit: str) -> str | None:
    """Reject a fact annotation whose local bytes differ from its Git commit."""
    root = next((parent for parent in path.parents if (parent / ".git").exists()), None)
    if root is None or not re.fullmatch(r"[0-9a-f]{40}", commit):
        return None
    try:
        relative = path.relative_to(root).as_posix()
        local = path.read_bytes()
        if len(local) > 65536:
            return None
        committed = subprocess.run(
            ["git", "-C", str(root), "show", f"{commit}:{relative}"],
            capture_output=True, check=True, timeout=10,
            creationflags=background_creationflags(),
        ).stdout
    except (OSError, ValueError, subprocess.CalledProcessError, subprocess.TimeoutExpired):
        return None
    # Git may materialize CRLF on Windows while the commit stores LF. Only
    # canonicalize line endings; any other local edit still fails closed.
    normalized_local = local.replace(b"\r\n", b"\n")
    normalized_commit = committed.replace(b"\r\n", b"\n")
    return normalized_local.decode("utf-8", errors="replace") if normalized_commit == normalized_local else None


def _current(value: dict, today: date) -> bool:
    try:
        since = date.fromisoformat(str(value["valid_from"])) if "valid_from" in value else None
        until = date.fromisoformat(str(value["valid_to"])) if "valid_to" in value else None
    except (TypeError, ValueError):
        return False
    return (since is None or since <= today) and (until is None or today <= until)


def validate_fact_rows(facts: list[dict], body: str) -> list[dict]:
    """Validate explicit links before a governed Knowledge publication."""
    if not isinstance(facts, list) or not 1 <= len(facts) <= 8:
        raise ValueError("fact links must contain one to eight entries")
    validated = []
    for fact in facts:
        if not isinstance(fact, dict) or set(fact) - {
                "subject", "relation", "object", "evidence", "valid_from", "valid_to"}:
            raise ValueError("fact link has unsupported fields")
        values = [fact.get(key) for key in ("subject", "relation", "object", "evidence")]
        if not all(isinstance(value, str) and 2 <= len(value.strip()) <= 300 for value in values):
            raise ValueError("fact link requires bounded subject, relation, object and evidence")
        if values[3] not in body:
            raise ValueError("fact evidence must occur exactly in the Knowledge body")
        try:
            since = date.fromisoformat(str(fact["valid_from"])) if "valid_from" in fact else None
            until = date.fromisoformat(str(fact["valid_to"])) if "valid_to" in fact else None
        except (TypeError, ValueError) as exc:
            raise ValueError("fact dates must use ISO calendar dates") from exc
        if since and until and since > until:
            raise ValueError("fact validity end precedes start")
        validated.append(dict(fact))
    return validated


def links_from_sources(sources: Iterable, *, today: date | None = None,
                       local_index: Path | None = None) -> tuple[FactLink, ...]:
    """Read explicit links only from the clean, authorized Git sources supplied.

    The resolver has already checked binding, path, Actor, catalog and commit.
    An exact supporting sentence in the same note is mandatory. Missing or
    malformed annotations contribute no links.
    """
    today = today or date.today()
    links: list[FactLink] = []
    seen: set[str] = set()
    admitted = tuple(sources)
    for source in admitted:
        if source.path in seen or len(seen) >= 1000:
            continue
        seen.add(source.path)
        path = Path(source.path)
        if path.suffix.casefold() != ".md" or not path.is_file() or path.is_symlink():
            continue
        # Most notes have no explicit links. Avoid a Git subprocess for each
        # ordinary note; only candidate annotations need commit verification.
        try:
            with path.open("r", encoding="utf-8", errors="replace") as handle:
                prefix = handle.read(32768)
            if "panky_facts:" not in prefix:
                continue
        except OSError:
            continue
        # A concurrent local edit cannot make an unpublished fact look like
        # evidence from the source_commit returned by the resolver.
        raw = _published_text(path, source.source_commit)
        if raw is None:
            continue
        if not raw.startswith("---\n") or "panky_facts:" not in raw[:32768]:
            continue
        front, marker, body = raw[4:].partition("\n---\n")
        if not marker or len(front) > 32768:
            continue
        try:
            metadata = yaml.safe_load(front)
        except yaml.YAMLError:
            continue
        if not isinstance(metadata, dict) or not isinstance(metadata.get("panky_facts"), list):
            continue
        facts = metadata["panky_facts"]
        if len(facts) > 8:
            continue
        for fact in facts:
            if not isinstance(fact, dict):
                continue
            subject, relation, object_, evidence = (fact.get(key) for key in
                                                     ("subject", "relation", "object", "evidence"))
            if (not all(isinstance(value, str) and 2 <= len(value.strip()) <= 300
                        for value in (subject, relation, object_, evidence))
                    or evidence not in body or not _current(fact, today)):
                continue
            links.append(FactLink(_entity(subject), relation.strip().casefold(),
                                  _entity(object_), source.path, source.source_commit))
            if len(links) >= 1000:
                return tuple(links)
    # A local derived index may annotate older, already-published notes without
    # editing their governed backing. Treat every entry as an untrusted hint:
    # require the same authorized source, exact commit, and quoted evidence.
    if local_index is not None and local_index.is_file() and not local_index.is_symlink():
        try:
            if local_index.stat().st_size > 262144:
                return tuple(links)
            rows = json.loads(local_index.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return tuple(links)
        if not isinstance(rows, list) or len(rows) > 500:
            return tuple(links)
        by_path = {source.path: source for source in admitted}
        verified: dict[str, str | None] = {}
        for row in rows:
            if not isinstance(row, dict):
                continue
            path, commit, fact = row.get("source_path"), row.get("source_commit"), row.get("fact")
            source = by_path.get(path) if isinstance(path, str) else None
            if source is None or source.source_commit != commit or not isinstance(fact, dict):
                continue
            if path not in verified:
                verified[path] = _published_text(Path(path), commit)
            body = verified[path]
            if body is None:
                continue
            if body.startswith("---\n"):
                _, separator, stripped = body[4:].partition("\n---\n")
                if not separator:
                    continue
                body = stripped
            try:
                validated = validate_fact_rows([fact], body)[0]
            except ValueError:
                continue
            if not _current(validated, today):
                continue
            links.append(FactLink(_entity(validated["subject"]),
                                  validated["relation"].strip().casefold(),
                                  _entity(validated["object"]), path, commit))
            if len(links) >= 1000:
                break
    return tuple(links)


def related_source_paths(query: str, sources: Iterable, *, max_hops: int = 3,
                         today: date | None = None,
                         local_index: Path | None = None) -> tuple[str, ...]:
    """Return bounded evidence sources reachable from a named entity in query."""
    links = links_from_sources(sources, today=today, local_index=local_index)
    if not links:
        return ()
    normalized_query = _entity(query)
    adjacency: dict[str, list[tuple[str, FactLink]]] = defaultdict(list)
    for link in links:
        adjacency[link.subject].append((link.object, link))
        adjacency[link.object].append((link.subject, link))
    anchors = [entity for entity in adjacency if entity and re.search(
        rf"(?<!\w){re.escape(entity)}(?!\w)", normalized_query)]
    if not anchors:
        return ()
    queue = deque((entity, 0) for entity in anchors[:8])
    visited = set(anchors[:8])
    paths: list[str] = []
    while queue and len(paths) < 12:
        entity, depth = queue.popleft()
        if depth >= max_hops:
            continue
        for neighbor, link in adjacency[entity]:
            if link.source_path not in paths:
                paths.append(link.source_path)
            if neighbor not in visited:
                visited.add(neighbor)
                queue.append((neighbor, depth + 1))
    return tuple(paths)
