"""Provider-neutral presentation blocks. No block grants authority or stores context."""

from __future__ import annotations

import json
import re


class BlockError(ValueError):
    pass


_TYPES = {"copy", "checklist", "choice", "callout"}
_LEVELS = {"info", "success", "warning", "error"}


def _text(value: object, field: str, limit: int = 4000) -> str:
    if not isinstance(value, str) or not value.strip() or len(value) > limit:
        raise BlockError(f"{field} must be nonempty text of at most {limit} characters")
    if "\x00" in value:
        raise BlockError(f"{field} contains an invalid character")
    return value.strip()


def _label(value: object, field: str) -> str:
    result = _text(value, field, 160)
    if "\n" in result or "\r" in result:
        raise BlockError(f"{field} must be one line")
    return re.sub(r"([\\`*_{}\[\]()#+.!|>~-])", r"\\\1", result)


def validate(document: object) -> list[dict]:
    if not isinstance(document, dict) or set(document) != {"blocks"}:
        raise BlockError("expected a document with only a blocks list")
    blocks = document["blocks"]
    if not isinstance(blocks, list) or not 1 <= len(blocks) <= 12:
        raise BlockError("blocks must contain 1 to 12 items")
    for block in blocks:
        if not isinstance(block, dict) or block.get("type") not in _TYPES:
            raise BlockError("unknown block type")
        _label(block.get("title"), "title")
        kind = block["type"]
        allowed = {
            "copy": {"type", "title", "content", "language"},
            "checklist": {"type", "title", "items"},
            "choice": {"type", "title", "options"},
            "callout": {"type", "title", "body", "level"},
        }[kind]
        if set(block) - allowed:
            raise BlockError("unknown block field")
        if kind == "copy":
            _text(block.get("content"), "content", 16000)
            if "language" in block and not re.fullmatch(r"[A-Za-z0-9_+-]{1,24}", block["language"]):
                raise BlockError("invalid code language")
        elif kind == "callout":
            _text(block.get("body"), "body")
            if block.get("level", "info") not in _LEVELS:
                raise BlockError("invalid callout level")
        else:
            key = "items" if kind == "checklist" else "options"
            values = block.get(key)
            maximum = 20 if kind == "checklist" else 4
            minimum = 1 if kind == "checklist" else 2
            if not isinstance(values, list) or not minimum <= len(values) <= maximum:
                raise BlockError(f"{key} must contain {minimum} to {maximum} entries")
            for value in values:
                if not isinstance(value, dict) or set(value) != ({"label", "done"} if kind == "checklist" else {"label", "description"}):
                    raise BlockError(f"invalid {key} entry")
                _label(value["label"], "label")
                if kind == "checklist":
                    if not isinstance(value["done"], bool):
                        raise BlockError("done must be boolean")
                else:
                    _text(value["description"], "description", 320)
    return blocks


def render_markdown(document: object) -> str:
    """Render one portable answer; UI controls are deliberately not implied."""
    output: list[str] = []
    for block in validate(document):
        kind = block["type"]
        output.append(f"**{_label(block['title'], 'title')}**")
        if kind == "copy":
            content = block["content"].strip()
            fence = "`" * max(3, max((len(run) for run in re.findall(r"`+", content)), default=0) + 1)
            output.append(f"{fence}{block.get('language', '')}\n{content}\n{fence}")
        elif kind == "checklist":
            output.extend(f"- [{'x' if item['done'] else ' '}] {_label(item['label'], 'label')}" for item in block["items"])
        elif kind == "choice":
            output.extend(f"{i}. **{_label(item['label'], 'label')}** — {item['description'].strip()}" for i, item in enumerate(block["options"], 1))
            output.append("Responde con el número o el nombre de la opción.")
        else:
            output.append(f"> {block.get('level', 'info').upper()}: {block['body'].strip().replace(chr(10), chr(10) + '> ')}")
        output.append("")
    return "\n".join(output).rstrip() + "\n"


def render_json(document: object) -> str:
    validate(document)
    return json.dumps(document, ensure_ascii=False, sort_keys=True)
