"""Prepare a single signed Prisma instance for local removal.

The caller must run cleanup from outside the instance after this process exits:
Windows cannot remove the virtual environment of a running executable.
"""

from __future__ import annotations

import json
import os
from pathlib import Path
import re
import shutil
import sys
from typing import Any

import keyring
import requests

from prisma_common.installed_binding import load_installed_binding, runtime_directory
from pancracio.composition import _read_yaml
from pancracio.gateway import _authorization_token, gateway_api_base
from pancracio.sync_transport import decommission_transport, transport_profile
from pancracio.sync_worker import uninstall_lifecycle


class UninstallBlocked(ValueError):
    pass


def _read_record(path: Path) -> dict[str, Any] | None:
    if path.is_symlink():
        raise UninstallBlocked("instance uninstall state is unsafe")
    if not path.exists():
        return None
    if not path.is_file():
        raise UninstallBlocked("instance uninstall state is invalid")
    try:
        record = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        raise UninstallBlocked("instance uninstall state is invalid") from exc
    if not isinstance(record, dict):
        raise UninstallBlocked("instance uninstall state is invalid")
    return record


def _paths(workspace: Path, *, home: Path | None = None,
           local_appdata: Path | None = None, platform: str | None = None) -> tuple[str, Path, list[Path]]:
    instance, runtime = runtime_directory(workspace, home=home,
                                          local_appdata=local_appdata, platform=platform)
    os_name = platform or ("windows" if os.name == "nt" else "macos" if sys.platform == "darwin" else "unsupported")
    base_home = home or Path.home()
    if os_name == "windows":
        appdata = local_appdata or Path(os.environ["LOCALAPPDATA"])
        logs = appdata / "Pancracio Prisma" / "instances" / instance / "logs"
    elif os_name == "macos":
        logs = base_home / "Library" / "Logs" / "Pancracio Prisma" / "instances" / instance
    else:
        raise UninstallBlocked("unsupported instance platform")
    roots = [workspace.parent, runtime.parent, logs]
    for root in roots:
        if root.is_symlink() or any(parent.is_symlink() for parent in root.parents):
            raise UninstallBlocked("instance uninstall path contains a symlink")
    return instance, runtime, roots


def uninstall_plan(workspace: Path, *, home: Path | None = None,
                   local_appdata: Path | None = None,
                   platform: str | None = None) -> dict[str, Any]:
    binding = load_installed_binding(workspace, home=home,
                                     local_appdata=local_appdata, platform=platform)
    instance, runtime, roots = _paths(workspace, home=home,
                                      local_appdata=local_appdata, platform=platform)
    if binding["instance_id"] != instance:
        raise UninstallBlocked("signed instance identity differs from local namespace")
    return {"status": "UNINSTALL_PLAN", "tenant_slug": binding["tenant_slug"],
            "instance_id": instance, "paths": [str(root) for root in roots],
            "includes_local_context": True, "includes_personal_context": True,
            "organization_actor_offboarding": False,
            "prepared": (runtime / "uninstall-prepared.json").is_file()}


def _runtime_id(workspace: Path, runtime: Path) -> str | None:
    owner = _read_yaml(workspace / ".panky" / "owner.yaml")
    bootstrap = _read_record(runtime / "poc-bootstrap.json")
    ids = [value for value in (owner.get("runtime_id") if owner else None,
                               bootstrap.get("runtime_id") if bootstrap else None) if value]
    if len(set(ids)) > 1 or any(not isinstance(value, str) or
                               not re.fullmatch(r"[0-9a-f-]{36}", value) for value in ids):
        raise UninstallBlocked("instance runtime identities disagree")
    return ids[0] if ids else None


def _gateway_access(workspace: Path, runtime: Path) -> str:
    owner = _read_yaml(workspace / ".panky" / "owner.yaml")
    if owner:
        try:
            access = _authorization_token(workspace / ".panky")
            if access:
                return access
        except ValueError:
            pass
    # An interrupted installation or a retry after subscription removal has no
    # stored refresh grant. Ask Google again, bound to the recorded subject.
    from pancracio.identity import authenticate_bootstrap_proof
    from hashlib import sha256

    bootstrap = _read_record(runtime / "poc-bootstrap.json")
    subject_hash = owner.get("google_subject_sha256") if owner else (
        bootstrap.get("subject_hash") if bootstrap else None)
    if not isinstance(subject_hash, str):
        raise UninstallBlocked("no registered installation identity is available")
    proof = authenticate_bootstrap_proof(workspace)
    if sha256(proof.claims["sub"].encode()).hexdigest() != subject_hash:
        raise UninstallBlocked("Google identity differs from this interrupted installation")
    return _post_gateway(workspace, "auth/panky/exchange", None,
                         {"google_id_token": proof.id_token})["access_token"]


def _post_gateway(workspace: Path, route: str, access: str | None,
                  body: dict[str, Any]) -> dict[str, Any]:
    try:
        response = requests.post(
            gateway_api_base(workspace / ".panky") + route,
            headers={"Authorization": f"Bearer {access}"} if access else {},
            json=body, timeout=30)
        response.raise_for_status()
        data = response.json()
    except (requests.RequestException, ValueError) as exc:
        raise UninstallBlocked("Gateway uninstall operation is unavailable") from exc
    if not isinstance(data, dict):
        raise UninstallBlocked("Gateway uninstall receipt is invalid")
    return data


def _revoke_individual_key(workspace: Path, runtime: Path) -> None:
    pointer = _read_record(runtime / "github-ssh-active.json")
    if pointer is None:
        return
    if pointer.get("gateway_mode") != "individual":
        raise UninstallBlocked("individual Git transport is not fully verified")
    name = pointer.get("private_key")
    login = pointer.get("login")
    if (not isinstance(name, str) or Path(name).name != name
            or not isinstance(login, str)):
        raise UninstallBlocked("individual Git transport pointer is invalid")
    public = runtime / f"{name}.pub"
    if public.is_symlink() or not public.is_file():
        raise UninstallBlocked("individual GitHub public key is unavailable")
    from .github_ssh_migration import GitHubCLIAdapter
    adapter = GitHubCLIAdapter(workspace=workspace)
    if adapter.identity_lookup()["login"].casefold() != login.casefold():
        raise UninstallBlocked("GitHub account differs from this instance")
    adapter.remove_public_key(public.read_text(encoding="ascii").strip())


def prepare_uninstall(workspace: Path, *, confirm_instance: str) -> dict[str, Any]:
    """Revoke remote capabilities before granting permission to delete local bytes."""
    plan = uninstall_plan(workspace)
    if plan["instance_id"] != confirm_instance:
        raise UninstallBlocked("confirm the exact signed instance to uninstall")
    instance, runtime, _roots = _paths(workspace)
    marker = runtime / "uninstall-prepared.json"
    current = _read_record(marker)
    runtime_id = _runtime_id(workspace, runtime)
    if current is not None:
        if (current.get("instance_id") != instance
                or current.get("runtime_id") != runtime_id
                or current.get("status") != "UNINSTALL_PREPARED"):
            raise UninstallBlocked("uninstall receipt differs from this instance")
        return {**plan, "status": "UNINSTALL_PREPARED"}
    if runtime_id is None and (workspace / ".panky" / "owner.yaml").exists():
        raise UninstallBlocked("runtime owner is invalid")
    access = _gateway_access(workspace, runtime) if runtime_id else None
    owner = _read_yaml(workspace / ".panky" / "owner.yaml")
    if owner:
        uninstall_lifecycle(workspace)
        if (workspace / ".panky" / "sync" / "transport.yaml").is_file():
            decommission_transport(workspace)
    _revoke_individual_key(workspace, runtime)
    if runtime_id is not None:
        status = _post_gateway(workspace, "panky/installations/status", access,
                               {"runtime_id": runtime_id, "instance_id": instance})
        if (status.get("status") not in {"not_registered", "active", "retired"}
                or status.get("runtime_id") != runtime_id
                or status.get("instance_id") != instance):
            raise UninstallBlocked("installation status is unverified")
        if status["status"] != "not_registered":
            revoked = _post_gateway(workspace, "panky/poc-transport/revoke", access,
                                    {"runtime_id": runtime_id})
            if revoked.get("status") not in {"revoked", "already_revoked"}:
                raise UninstallBlocked("GitHub POC key revocation is unverified")
            retired = _post_gateway(workspace, "panky/installations/decommission", access,
                                    {"runtime_id": runtime_id, "instance_id": instance})
            if (retired.get("status") != "retired" or retired.get("runtime_id") != runtime_id
                    or retired.get("instance_id") != instance):
                raise UninstallBlocked("installation retirement is unverified")
    if owner:
        keyring.delete_password("pancracio-prisma-gateway-access", owner["runtime_id"])
    record = {"status": "UNINSTALL_PREPARED", "instance_id": instance,
              "runtime_id": runtime_id}
    with marker.open("x", encoding="utf-8") as output:
        json.dump(record, output, sort_keys=True)
        output.write("\n")
    if os.name != "nt":
        marker.chmod(0o600)
    return {**plan, "status": "UNINSTALL_PREPARED"}


def cleanup_prepared(workspace: Path, *, confirm_instance: str,
                     home: Path | None = None, local_appdata: Path | None = None,
                     platform: str | None = None) -> dict[str, Any]:
    """Called by the setup agent from outside the instance after its CLI exits."""
    plan = uninstall_plan(workspace, home=home, local_appdata=local_appdata,
                          platform=platform)
    if plan["instance_id"] != confirm_instance:
        raise UninstallBlocked("confirm the exact signed instance to uninstall")
    _instance, runtime, roots = _paths(workspace, home=home,
                                      local_appdata=local_appdata, platform=platform)
    marker = _read_record(runtime / "uninstall-prepared.json")
    if (marker is None or marker.get("status") != "UNINSTALL_PREPARED"
            or marker.get("instance_id") != confirm_instance
            or marker.get("runtime_id") != _runtime_id(workspace, runtime)):
        raise UninstallBlocked("verified uninstall preparation is required")
    current_directory = Path.cwd().resolve()
    if any(current_directory == root or root in current_directory.parents for root in roots):
        raise UninstallBlocked("leave the instance directory before local cleanup")
    for root in roots:
        if root.is_symlink():
            raise UninstallBlocked("instance root is a symlink; stop before deleting")
    for root in roots:
        if root.is_dir():
            shutil.rmtree(root)
    return {"status": "UNINSTALLED", "instance_id": confirm_instance,
            "removed_paths": [str(root) for root in roots],
            "organization_actor_offboarding": False}
