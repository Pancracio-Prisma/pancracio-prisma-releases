"""Apply an operator-signed name to one installed Prisma instance."""

from __future__ import annotations

import os
from pathlib import Path
import re
import subprocess
from tempfile import NamedTemporaryFile
from typing import Any

from filelock import FileLock

from prisma_common.agent_profile import verify_agent_profile
from prisma_common.installed_binding import load_installed_binding, runtime_directory
from prisma_common.intake import SetupInputError
from prisma_common.repository_profile import repository_profile


CORE_PROFILE_PATH = "registry/agent-profile.json"
_COMMIT = re.compile(r"[0-9a-f]{40}\Z")


def _state(workspace: Path, *, home: Path | None = None,
           local_appdata: Path | None = None, platform: str | None = None
           ) -> tuple[dict[str, Any], Path, bytes]:
    binding = load_installed_binding(workspace, home=home, local_appdata=local_appdata,
                                     platform=platform)
    _, runtime = runtime_directory(workspace, home=home, local_appdata=local_appdata,
                                   platform=platform)
    key_path = runtime / "trust-public-key.raw"
    return binding, runtime, key_path.read_bytes()


def active_display_name(workspace: Path, *, home: Path | None = None,
                        local_appdata: Path | None = None,
                        platform: str | None = None) -> dict[str, Any]:
    binding, runtime, key = _state(workspace, home=home, local_appdata=local_appdata,
                                   platform=platform)
    path = runtime / "agent-profile.json"
    if not path.exists() and not path.is_symlink():
        return {"display_name": binding["intake"]["product"]["display_name"], "revision": 0}
    profile = verify_agent_profile(path, pinned_public_key=key,
                                   tenant_slug=binding["tenant_slug"],
                                   instance_id=binding["instance_id"])
    return {"display_name": profile["display_name"], "revision": profile["revision"]}


def apply_agent_profile(workspace: Path, source: Path, *, home: Path | None = None,
                        local_appdata: Path | None = None,
                        platform: str | None = None) -> dict[str, Any]:
    """A repeated revision is idempotent; stale or conflicting revisions fail."""
    binding, runtime, key = _state(workspace, home=home, local_appdata=local_appdata,
                                   platform=platform)
    profile = verify_agent_profile(source, pinned_public_key=key,
                                   tenant_slug=binding["tenant_slug"],
                                   instance_id=binding["instance_id"])
    target = runtime / "agent-profile.json"
    lock = runtime / "agent-profile.lock"
    if target.is_symlink() or lock.is_symlink():
        raise SetupInputError("agent profile state is unsafe")
    with FileLock(str(lock), timeout=20):
        current = active_display_name(workspace, home=home,
                                      local_appdata=local_appdata, platform=platform)
        if profile["revision"] < current["revision"]:
            raise SetupInputError("agent profile revision is older than installed revision")
        if profile["revision"] == current["revision"]:
            if profile["display_name"] != current["display_name"]:
                raise SetupInputError("agent profile revision conflicts with installed revision")
            return {"status": "AGENT_PROFILE_ALREADY_ACTIVE", **current}
        # Re-verified bytes are copied into a private temporary file, then
        # selected atomically. The original installation binding is immutable.
        data = source.read_bytes()
        with NamedTemporaryFile(dir=runtime, prefix=".agent-profile-", delete=False) as stream:
            temporary = Path(stream.name)
            stream.write(data)
        try:
            if os.name != "nt":
                temporary.chmod(0o600)
            verify_agent_profile(temporary, pinned_public_key=key,
                                 tenant_slug=binding["tenant_slug"],
                                 instance_id=binding["instance_id"])
            os.replace(temporary, target)
        finally:
            temporary.unlink(missing_ok=True)
        result = active_display_name(workspace, home=home,
                                     local_appdata=local_appdata, platform=platform)
        return {"status": "AGENT_PROFILE_ACTIVE", **result}


def _git(core: Path, *args: str) -> str:
    try:
        from pancracio.processes import background_creationflags
        result = subprocess.run(["git", "-C", str(core), *args], capture_output=True,
                                text=True, timeout=30, check=False,
                                creationflags=background_creationflags())
    except (OSError, subprocess.SubprocessError) as exc:
        raise SetupInputError("protected Core profile is unavailable") from exc
    if result.returncode:
        raise SetupInputError("protected Core profile is unavailable")
    return result.stdout.strip()


def refresh_agent_profile_from_core(workspace: Path, *, home: Path | None = None,
                                    local_appdata: Path | None = None,
                                    platform: str | None = None) -> dict[str, Any]:
    """Read only an operator-signed profile at the current fetched Core head."""
    core = workspace / "domains" / "core"
    if not core.is_dir():
        return {"status": "CORE_NOT_ENROLLED"}
    profile = repository_profile(workspace)
    origin = _git(core, "remote", "get-url", "origin")
    if origin not in {profile.core_remote,
                      profile.core_remote.replace("git@github.com:", "https://github.com/")}:
        raise SetupInputError("Core origin differs from installed binding")
    head = _git(core, "rev-parse", "refs/remotes/origin/main")
    remote = _git(core, "ls-remote", "origin", "refs/heads/main").split()
    if not _COMMIT.fullmatch(head) or len(remote) != 2 or remote[0] != head:
        raise SetupInputError("Core profile is not at the current remote head")
    listing = _git(core, "ls-tree", "--name-only", head, CORE_PROFILE_PATH)
    if not listing:
        return {"status": "NO_AGENT_PROFILE"}
    if listing != CORE_PROFILE_PATH:
        raise SetupInputError("Core profile entry is invalid")
    raw = _git(core, "show", f"{head}:{CORE_PROFILE_PATH}").encode("utf-8")
    if len(raw) > 64 * 1024:
        raise SetupInputError("Core profile is too large")
    _, runtime, _ = _state(workspace, home=home, local_appdata=local_appdata,
                           platform=platform)
    with NamedTemporaryFile(dir=runtime, prefix=".core-profile-", delete=False) as stream:
        temporary = Path(stream.name)
        stream.write(raw)
    try:
        result = apply_agent_profile(workspace, temporary, home=home,
                                     local_appdata=local_appdata, platform=platform)
    finally:
        temporary.unlink(missing_ok=True)
    return {**result, "core_commit": head}
