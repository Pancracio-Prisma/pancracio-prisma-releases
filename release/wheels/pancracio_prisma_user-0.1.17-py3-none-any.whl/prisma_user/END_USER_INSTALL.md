# Instala Panky Prisma en tu computadora

Esta guía es para cada persona de la empresa. La empresa ya preparó Panky;
Codex te ayudará a instalar tu copia y comprobar que quedó lista.

## Lo que necesitas recibir

El administrador te entregará dos cosas por canales distintos:

1. **El ZIP de instalación** para tu empresa y tu sistema (`macos` o
   `windows`). Su nombre empieza con `Pancracio-Prisma-`.
2. **Un aviso de verificación** enviado por otro canal de la empresa. Su
   nombre termina en `-verification.md`. Codex lo comprobará; tú no necesitas
   interpretar sus números. El aviso no viene dentro del ZIP.

Si solo recibiste el ZIP, pide el aviso al administrador antes de instalar.
No basta con que te diga por chat que el paquete es correcto.

## Cómo empezar

Descarga el ZIP y extráelo en tu computadora. Abre **la carpeta extraída**
`Pancracio-Prisma-<empresa>-<macos|windows>-v<versión>` como carpeta de trabajo
en Codex. No abras una carpeta de otro Panky que ya uses. Comparte con Codex
el aviso de verificación recibido por el otro canal, o indícale dónde puede
leerlo si tiene acceso a ese canal.

Dile a Codex:

> Instala Panky Prisma en esta computadora siguiendo las instrucciones de
> esta carpeta. Comprueba el aviso de verificación que recibí por separado,
> guíame hasta que quede listo y conserva cualquier otro Pancracio que ya
> tenga.

Este mensaje sirve para cualquier empresa: la carpeta contiene su
configuración firmada. Codex lee `AGENT_END_USER_INSTALL.md` dentro de ella,
comprueba el paquete y se encarga de los pasos técnicos. No tienes que
ejecutar comandos ni proporcionar identificadores de la empresa.

## Lo que te pedirá la instalación

Codex te guiará para iniciar sesión con **tu cuenta Google de trabajo**. Si
Google muestra una pantalla de permisos, revisarás y aprobarás allí el acceso
que Panky solicita para trabajar con Google Workspace, como Drive, Docs o
Sheets. Panky actúa con tu cuenta dentro de lo que Google te permite y de los
permisos que tu empresa haya configurado. Esta aprobación no le da acceso a
otras cuentas tuyas. Escribe contraseñas y códigos solo en la página de
Google; nunca los pegues en el chat.

Si tu empresa está en **modo POC**, no necesitas cuenta GitHub, una sesión
abierta en GitHub ni una llave SSH preparada en tu computadora. El kit ya
indica la cuenta de transporte de la empresa. Durante la instalación, Codex
crea una llave distinta para esta computadora, el Gateway la registra y
comprueba que la instalación trae los repositorios autorizados para tu
cuenta de trabajo. No te pedirá esa llave ni un token en el chat. Si la
comprobación falla, no declarará la instalación lista.

Fuera del POC, Codex te guiará para conectar tu cuenta GitHub individual y
verificará sus accesos antes de traer información de la empresa.

## Al terminar

Panky traerá el contexto de trabajo que te corresponde. Tu espacio personal
quedará separado. Durante el POC permanecerá en esta computadora; cuando la
empresa pase a modo definitivo podrás elegir una copia privada.

Codex te dirá cuándo la instalación esté **lista** y Panky te hará unas pocas
preguntas para empezar a trabajar contigo. Si falta el aviso, la autorización
de Google o algún acceso, Codex te dirá exactamente qué necesita del
administrador y no dará por terminado el proceso.

Para futuras actualizaciones, basta decir: **«Panky, actualízate»**.

Si la empresa termina el POC, Panky te avisará cuando llegue el cambio desde
Core. Te mostrará la cuenta GitHub asignada y te preguntará qué perfil de
Chrome la tiene abierta. Codex preparará la conexión, la llave y los accesos;
GitHub puede pedirte aprobar una invitación. No tendrás que reinstalar Panky
ni escribir comandos o compartir claves en el chat.
