"""Detect a published Core POC transition for one enrolled Actor."""

from __future__ import annotations

import json
import os
from pathlib import Path
import subprocess
from typing import Any

from prisma_common.installed_binding import load_installed_binding
from prisma_common.poc_transition import actor_transition, read_poc_transition

from .composition import _read_yaml
from .context_catalog20 import fetch_catalog
from .registry import CoreRegistry, RegistryError


class PocExitError(ValueError):
    pass


def _verified_core_transition(core: Path, commit: str) -> str | None:
    """Read only the current protected Core commit, never the working tree."""
    CoreRegistry.load(core)
    try:
        head = subprocess.run(
            ["git", "-C", str(core), "rev-parse", "refs/remotes/origin/main"],
            capture_output=True, text=True, check=True, timeout=10)
        if head.stdout.strip() != commit:
            raise PocExitError("protected Core commit differs from synchronized Core")
        listed = subprocess.run(
            ["git", "-C", str(core), "ls-tree", "--name-only", commit,
             "registry/deployment-transition.json"],
            capture_output=True, text=True, check=True, timeout=10)
        if not listed.stdout.strip():
            return None
        result = subprocess.run(
            ["git", "-C", str(core), "show",
             f"{commit}:registry/deployment-transition.json"],
            capture_output=True, text=True, check=False, timeout=10)
    except (OSError, subprocess.SubprocessError, RegistryError) as exc:
        raise PocExitError("protected Core transition is unavailable") from exc
    if result.returncode:
        raise PocExitError("protected Core transition is unavailable")
    return result.stdout


def refresh_pending(workspace: Path, *, verified_core_commit: str | None = None) -> dict[str, Any]:
    """Persist a prompt only after live Policy agrees with the fetched Core."""
    binding = load_installed_binding(workspace)
    if binding["intake"]["deployment"].get("poc") is not True:
        return {"status": "NOT_POC"}
    owner = _read_yaml(workspace / ".panky" / "owner.yaml") or {}
    actor_id = owner.get("actor_id")
    runtime_id = owner.get("runtime_id")
    if not isinstance(actor_id, str) or not isinstance(runtime_id, str):
        raise PocExitError("enrolled Actor is unavailable")
    core = workspace / "domains" / "core"
    if verified_core_commit is None:
        try:
            result = subprocess.run(["git", "-C", str(core), "rev-parse", "refs/remotes/origin/main"],
                                    capture_output=True, text=True, check=True, timeout=10)
            verified_core_commit = result.stdout.strip()
        except (OSError, subprocess.SubprocessError) as exc:
            raise PocExitError("protected Core is unavailable") from exc
    contents = _verified_core_transition(core, verified_core_commit)
    catalog = fetch_catalog(workspace / ".panky")
    if (catalog.get("status") != "ready" or catalog.get("actor_id") != actor_id):
        raise PocExitError("Gateway Actor catalog is unavailable")
    transition = (read_poc_transition(
        core, tenant_slug=binding["tenant_slug"],
        verified_core_commit=verified_core_commit,
        verified_contents=contents) if contents is not None else None)
    target = workspace / ".panky" / "sync" / "poc-exit-pending.json"
    if transition is None:
        if target.is_symlink():
            raise PocExitError("transition state path is unsafe")
        target.unlink(missing_ok=True)
        return {"status": "POC"}
    state = actor_transition(
        transition, actor_id=actor_id,
        verified_release_commit=catalog.get("release", ""),
        verified_core_commit=verified_core_commit)
    if state["status"] == "POC":
        if target.is_symlink():
            raise PocExitError("transition state path is unsafe")
        target.unlink(missing_ok=True)
        return state
    if target.is_symlink() or not target.parent.is_dir():
        raise PocExitError("transition state path is unsafe")
    payload = {"schema_version": 1, "actor_id": actor_id,
               "runtime_id": runtime_id, "core_commit": verified_core_commit,
               "status": state["status"], "github_login": state["github_login"]}
    temporary = target.with_name(target.name + ".tmp")
    if temporary.is_symlink():
        raise PocExitError("transition staging path is unsafe")
    descriptor = os.open(temporary, os.O_CREAT | os.O_WRONLY | os.O_TRUNC, 0o600)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8") as stream:
            json.dump(payload, stream, sort_keys=True)
            stream.write("\n")
        os.replace(temporary, target)
    finally:
        temporary.unlink(missing_ok=True)
    return payload
